-- HMS DATABASE BACKUP UTILITY 
--
-- Host: localhost	Database: smartchurch_neno
--------------------------------------------------------
-- Server version 	5.5.50
-- Backup By:  Super (1) ***** Date: Mon, 28 Nov 2016 14:35:27 +0300

-- Current Database: `smartchurch_neno`
--
/*!40000 DROP DATABASE IF EXISTS `smartchurch_neno`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `smartchurch_neno` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci*/;

USE `smartchurch_neno`;

-- Table structure for table `account_types`
DROP TABLE IF EXISTS `account_types`;
CREATE TABLE `account_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `campus_id` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table `account_types`
LOCK TABLES `account_types` WRITE;
/*!40000 ALTER TABLE `account_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_types` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `accounts`
DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` blob NOT NULL,
  `code` blob NOT NULL,
  `account_type` blob NOT NULL,
  `tax` blob NOT NULL,
  `balance` blob NOT NULL,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table `accounts`
LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `address_book`
DROP TABLE IF EXISTS `address_book`;
CREATE TABLE `address_book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address_book` varchar(256) NOT NULL DEFAULT '',
  `category` varchar(32) NOT NULL DEFAULT '',
  `contact_person` varchar(256) NOT NULL DEFAULT '',
  `business_name` varchar(256) NOT NULL DEFAULT '',
  `phone` varchar(256) NOT NULL DEFAULT '',
  `email` varchar(256) NOT NULL DEFAULT '',
  `address` text,
  `additional_info` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `address_book`
LOCK TABLES `address_book` WRITE;
/*!40000 ALTER TABLE `address_book` DISABLE KEYS */;
/*!40000 ALTER TABLE `address_book` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `address_book_category`
DROP TABLE IF EXISTS `address_book_category`;
CREATE TABLE `address_book_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `address_book_category`
LOCK TABLES `address_book_category` WRITE;
/*!40000 ALTER TABLE `address_book_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `address_book_category` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `advance_salary`
DROP TABLE IF EXISTS `advance_salary`;
CREATE TABLE `advance_salary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee` varchar(256) NOT NULL DEFAULT '',
  `advance_date` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `amount` varchar(256) NOT NULL DEFAULT '',
  `comment` text NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `advance_salary`
LOCK TABLES `advance_salary` WRITE;
/*!40000 ALTER TABLE `advance_salary` DISABLE KEYS */;
/*!40000 ALTER TABLE `advance_salary` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `allocations`
DROP TABLE IF EXISTS `allocations`;
CREATE TABLE `allocations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `ministry` varchar(32) NOT NULL DEFAULT '',
  `amount` double DEFAULT NULL,
  `approved_by` varchar(32) NOT NULL DEFAULT '',
  `confirmed_by` varchar(32) NOT NULL DEFAULT '',
  `expenditure` double DEFAULT NULL,
  `balance` double DEFAULT NULL,
  `description` text,
  `comment` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `allocations`
LOCK TABLES `allocations` WRITE;
/*!40000 ALTER TABLE `allocations` DISABLE KEYS */;
/*!40000 ALTER TABLE `allocations` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `allowances`
DROP TABLE IF EXISTS `allowances`;
CREATE TABLE `allowances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `amount` varchar(256) NOT NULL DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `allowances`
LOCK TABLES `allowances` WRITE;
/*!40000 ALTER TABLE `allowances` DISABLE KEYS */;
/*!40000 ALTER TABLE `allowances` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `announcements`
DROP TABLE IF EXISTS `announcements`;
CREATE TABLE `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `title` varchar(256) NOT NULL DEFAULT '',
  `status` varchar(32) NOT NULL DEFAULT '',
  `file` varchar(32) NOT NULL,
  `brief_description` text,
  `upload_announcements` varchar(256) NOT NULL DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `announcements`
LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `asset_category`
DROP TABLE IF EXISTS `asset_category`;
CREATE TABLE `asset_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `asset_category`
LOCK TABLES `asset_category` WRITE;
/*!40000 ALTER TABLE `asset_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `asset_category` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `asset_items`
DROP TABLE IF EXISTS `asset_items`;
CREATE TABLE `asset_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `asset_items`
LOCK TABLES `asset_items` WRITE;
/*!40000 ALTER TABLE `asset_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `asset_items` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `asset_stock`
DROP TABLE IF EXISTS `asset_stock`;
CREATE TABLE `asset_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `supplier` varchar(32) NOT NULL DEFAULT '',
  `item` varchar(32) NOT NULL DEFAULT '',
  `quantity` varchar(256) NOT NULL DEFAULT '',
  `unit_price` varchar(256) NOT NULL DEFAULT '',
  `total` varchar(256) NOT NULL DEFAULT '',
  `person_responsible` varchar(32) NOT NULL DEFAULT '',
  `file` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `asset_stock`
LOCK TABLES `asset_stock` WRITE;
/*!40000 ALTER TABLE `asset_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `asset_stock` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `bank_accounts`
DROP TABLE IF EXISTS `bank_accounts`;
CREATE TABLE `bank_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(256) NOT NULL DEFAULT '',
  `account_name` varchar(256) NOT NULL DEFAULT '',
  `account_number` varchar(256) NOT NULL DEFAULT '',
  `branch` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `bank_accounts`
LOCK TABLES `bank_accounts` WRITE;
/*!40000 ALTER TABLE `bank_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `bank_accounts` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `baptism`
DROP TABLE IF EXISTS `baptism`;
CREATE TABLE `baptism` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `member` varchar(32) NOT NULL DEFAULT '',
  `ff_name` varchar(256) NOT NULL DEFAULT '',
  `fl_name` varchar(256) NOT NULL DEFAULT '',
  `father_religion` varchar(256) NOT NULL DEFAULT '',
  `father_phone` varchar(256) NOT NULL DEFAULT '',
  `father_email` varchar(256) NOT NULL DEFAULT '',
  `father_address` text,
  `mf_name` varchar(256) NOT NULL DEFAULT '',
  `ml_name` varchar(256) NOT NULL DEFAULT '',
  `mother_religion` varchar(256) NOT NULL DEFAULT '',
  `mother_phone` varchar(256) NOT NULL DEFAULT '',
  `mother_email` varchar(256) NOT NULL DEFAULT '',
  `mother_address` text,
  `gff_name` varchar(256) NOT NULL DEFAULT '',
  `gfl_name` varchar(256) NOT NULL DEFAULT '',
  `gf_age` varchar(256) NOT NULL DEFAULT '',
  `gf_phone` varchar(256) NOT NULL DEFAULT '',
  `gf_address` text,
  `gmf_name` varchar(256) NOT NULL DEFAULT '',
  `gml_name` varchar(256) NOT NULL DEFAULT '',
  `gm_age` varchar(256) NOT NULL DEFAULT '',
  `gm_phone` varchar(256) NOT NULL DEFAULT '',
  `gm_address` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `baptism`
LOCK TABLES `baptism` WRITE;
/*!40000 ALTER TABLE `baptism` DISABLE KEYS */;
/*!40000 ALTER TABLE `baptism` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `bible_quotes`
DROP TABLE IF EXISTS `bible_quotes`;
CREATE TABLE `bible_quotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL DEFAULT '',
  `status` varchar(32) NOT NULL DEFAULT '',
  `content` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `bible_quotes`
LOCK TABLES `bible_quotes` WRITE;
/*!40000 ALTER TABLE `bible_quotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `bible_quotes` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `cfd_parents`
DROP TABLE IF EXISTS `cfd_parents`;
CREATE TABLE `cfd_parents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `child_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(256) NOT NULL DEFAULT '',
  `first_name` varchar(256) NOT NULL DEFAULT '',
  `last_name` varchar(256) NOT NULL DEFAULT '',
  `phone` varchar(256) NOT NULL DEFAULT '',
  `email` varchar(256) NOT NULL DEFAULT '',
  `address` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `cfd_parents`
LOCK TABLES `cfd_parents` WRITE;
/*!40000 ALTER TABLE `cfd_parents` DISABLE KEYS */;
/*!40000 ALTER TABLE `cfd_parents` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `church_projects`
DROP TABLE IF EXISTS `church_projects`;
CREATE TABLE `church_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `county` varchar(32) NOT NULL DEFAULT '',
  `location` varchar(256) NOT NULL DEFAULT '',
  `status` varchar(32) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `church_projects`
LOCK TABLES `church_projects` WRITE;
/*!40000 ALTER TABLE `church_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `church_projects` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `collections_log`
DROP TABLE IF EXISTS `collections_log`;
CREATE TABLE `collections_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collection_id` blob,
  `type` blob,
  `amount` blob,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table `collections_log`
LOCK TABLES `collections_log` WRITE;
/*!40000 ALTER TABLE `collections_log` DISABLE KEYS */;
INSERT INTO `collections_log` VALUES (1,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x1200f53aa19a76ac97cffa5a3880d04f,0xb60a11bc1479d6ea3a771e2ef2de261e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x046d4bb491944a59284865f26da11488,NULL);
/*!40000 ALTER TABLE `collections_log` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `contribution_types`
DROP TABLE IF EXISTS `contribution_types`;
CREATE TABLE `contribution_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `contribution_types`
LOCK TABLES `contribution_types` WRITE;
/*!40000 ALTER TABLE `contribution_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `contribution_types` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `core_settings`
DROP TABLE IF EXISTS `core_settings`;
CREATE TABLE `core_settings` (
  `slug` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `default` text COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`slug`),
  UNIQUE KEY `unique - slug` (`slug`),
  KEY `index - slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Stores settings for the multi-site interface';

-- Dumping data for table `core_settings`
LOCK TABLES `core_settings` WRITE;
/*!40000 ALTER TABLE `core_settings` DISABLE KEYS */;
INSERT INTO `core_settings` VALUES ('date_format','g:ia -- m/d/y','g:ia -- m/d/y'),('lang_direction','ltr','ltr'),('status_message','This site has been disabled by a super-administrator.','This site has been disabled by a super-administrator.');
/*!40000 ALTER TABLE `core_settings` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `core_sites`
DROP TABLE IF EXISTS `core_sites`;
CREATE TABLE `core_sites` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `ref` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `domain` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` int(11) NOT NULL DEFAULT '0',
  `updated_on` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `Unique ref` (`ref`),
  UNIQUE KEY `Unique domain` (`domain`),
  KEY `ref` (`ref`),
  KEY `domain` (`domain`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table `core_sites`
LOCK TABLES `core_sites` WRITE;
/*!40000 ALTER TABLE `core_sites` DISABLE KEYS */;
INSERT INTO `core_sites` VALUES (1,'Default Site','default','localhost',1,1361856990,0);
/*!40000 ALTER TABLE `core_sites` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `core_users`
DROP TABLE IF EXISTS `core_users`;
CREATE TABLE `core_users` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `salt` varchar(6) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `group_id` int(11) DEFAULT NULL,
  `ip_address` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` int(1) DEFAULT NULL,
  `activation_code` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_on` int(11) NOT NULL,
  `last_login` int(11) NOT NULL,
  `username` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `forgotten_password_code` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_code` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Super User Information';

-- Dumping data for table `core_users`
LOCK TABLES `core_users` WRITE;
/*!40000 ALTER TABLE `core_users` DISABLE KEYS */;
INSERT INTO `core_users` VALUES (1,'evansogola@digitalvision.co.ke','2a7a93fb841e8d17217f56895ccc93f38f2f9114','acf67',1,'',1,'',1361856990,1361856990,'evans',NULL,NULL);
/*!40000 ALTER TABLE `core_users` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `current`
DROP TABLE IF EXISTS `current`;
CREATE TABLE `current` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` blob NOT NULL,
  `total` blob NOT NULL,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `current`
LOCK TABLES `current` WRITE;
/*!40000 ALTER TABLE `current` DISABLE KEYS */;
/*!40000 ALTER TABLE `current` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `daily_inspirations`
DROP TABLE IF EXISTS `daily_inspirations`;
CREATE TABLE `daily_inspirations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL DEFAULT '',
  `message` text,
  `status` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `daily_inspirations`
LOCK TABLES `daily_inspirations` WRITE;
/*!40000 ALTER TABLE `daily_inspirations` DISABLE KEYS */;
/*!40000 ALTER TABLE `daily_inspirations` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `dedications`
DROP TABLE IF EXISTS `dedications`;
CREATE TABLE `dedications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `first_name` varchar(256) NOT NULL DEFAULT '',
  `middle_name` varchar(256) NOT NULL DEFAULT '',
  `last_name` varchar(256) NOT NULL DEFAULT '',
  `gender` varchar(256) NOT NULL DEFAULT '',
  `dob` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `location` varchar(256) NOT NULL DEFAULT '',
  `country` varchar(256) NOT NULL DEFAULT '',
  `city` varchar(256) NOT NULL DEFAULT '',
  `expected_dedication_date` int(11) DEFAULT NULL,
  `service_type` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `type` int(11) DEFAULT NULL,
  `father` int(11) DEFAULT NULL,
  `mother` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `dedications`
LOCK TABLES `dedications` WRITE;
/*!40000 ALTER TABLE `dedications` DISABLE KEYS */;
/*!40000 ALTER TABLE `dedications` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `deductions`
DROP TABLE IF EXISTS `deductions`;
CREATE TABLE `deductions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `amount` varchar(256) NOT NULL DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `deductions`
LOCK TABLES `deductions` WRITE;
/*!40000 ALTER TABLE `deductions` DISABLE KEYS */;
/*!40000 ALTER TABLE `deductions` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `donations`
DROP TABLE IF EXISTS `donations`;
CREATE TABLE `donations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `donor` varchar(256) NOT NULL DEFAULT '',
  `phone` varchar(256) NOT NULL DEFAULT '',
  `email` varchar(256) NOT NULL DEFAULT '',
  `address` text,
  `country` varchar(32) NOT NULL DEFAULT '',
  `city` varchar(256) NOT NULL DEFAULT '',
  `donation_type` varchar(256) NOT NULL DEFAULT '',
  `pledged_amount` varchar(256) NOT NULL DEFAULT '',
  `value` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `donations`
LOCK TABLES `donations` WRITE;
/*!40000 ALTER TABLE `donations` DISABLE KEYS */;
/*!40000 ALTER TABLE `donations` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `email_recipients`
DROP TABLE IF EXISTS `email_recipients`;
CREATE TABLE `email_recipients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` varchar(256) NOT NULL DEFAULT '',
  `email_id` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `email_recipients`
LOCK TABLES `email_recipients` WRITE;
/*!40000 ALTER TABLE `email_recipients` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_recipients` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `email_templates`
DROP TABLE IF EXISTS `email_templates`;
CREATE TABLE `email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) DEFAULT NULL,
  `slug` varchar(250) DEFAULT NULL,
  `description` text,
  `content` text,
  `status` enum('draft','live') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'draft',
  `created_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Dumping data for table `email_templates`
LOCK TABLES `email_templates` WRITE;
/*!40000 ALTER TABLE `email_templates` DISABLE KEYS */;
INSERT INTO `email_templates` VALUES (1,'Meetings Template','meetings','This is meetings template','<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\r\n<meta name=\"viewport\" content=\"initial-scale=1.0\"> \r\n<meta name=\"format-detection\" content=\"telephone=no\">\r\n<title>Metric : Responsive Email Templates</title>\r\n<style type=\"text/css\">\r\n\r\n/* Resets: see reset.css for details */\r\n.ReadMsgBody { width: 100%; background-color: #ffffff;}\r\n.ExternalClass {width: 100%; background-color: #ffffff;}\r\n.ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {line-height:100%;}\r\nhtml{width: 100%; }\r\nbody {-webkit-text-size-adjust:none; -ms-text-size-adjust:none; }\r\nbody {margin:0; padding:0;}\r\ntable {border-spacing:0;}\r\nimg{display:block !important;}\r\n\r\ntable td {border-collapse:collapse;}\r\n.yshortcuts a {border-bottom: none !important;}\r\n\r\n\r\n/* \r\n\r\nmain color = #2f9bbe\r\n\r\nother color = #186e8a\r\n\r\n\r\n*/\r\n\r\n\r\nimg{height:auto !important;}\r\n\r\n\r\n@media only screen and (max-width: 640px){\r\n  body{\r\n    width:auto!important;\r\n  }\r\n\r\n  table[class=\"container\"]{\r\n    width: 100%!important;\r\n    padding-left: 20px!important; \r\n    padding-right: 20px!important; \r\n  }\r\n\r\n  img[class=\"image-100-percent\"]{\r\n    width:100% !important;\r\n    height:auto !important;\r\n    max-width:100% !important;\r\n  }\r\n\r\n  img[class=\"small-image-100-percent\"]{\r\n    width:100% !important;\r\n    height:auto !important;\r\n  }\r\n\r\n  table[class=\"full-width\"]{\r\n    width:100% !important;\r\n  }\r\n\r\n  table[class=\"full-width-text\"]{\r\n    width:100% !important;\r\n     background-color:#186e8a;\r\n     padding-left:20px !important;\r\n     padding-right:20px !important;\r\n  }\r\n\r\n  table[class=\"full-width-text2\"]{\r\n    width:100% !important;\r\n     background-color:#f3f3f3;\r\n     padding-left:20px !important;\r\n     padding-right:20px !important; \r\n  }\r\n\r\n  table[class=\"col-2-3img\"]{\r\n    width:50% !important;\r\n    margin-right: 20px !important;\r\n  }\r\n    table[class=\"col-2-3img-last\"]{\r\n    width:50% !important;\r\n  }\r\n\r\n  table[class=\"col-2\"]{\r\n    width:47% !important;\r\n    margin-right:20px !important;\r\n  }\r\n\r\n  table[class=\"col-2-last\"]{\r\n    width:47% !important;\r\n  }\r\n\r\n  table[class=\"col-3\"]{\r\n    width:29% !important;\r\n    margin-right:20px !important;\r\n  }\r\n\r\n  table[class=\"col-3-last\"]{\r\n    width:29% !important;\r\n  }\r\n\r\n  table[class=\"row-2\"]{\r\n    width:50% !important;\r\n  }\r\n\r\n  td[class=\"text-center\"]{\r\n     text-align: center !important;\r\n   }\r\n\r\n  /* start clear and remove*/\r\n  table[class=\"remove\"]{\r\n    display:none !important;\r\n  }\r\n\r\n  td[class=\"remove\"]{\r\n    display:none !important;\r\n  }\r\n  /* end clear and remove*/\r\n\r\n  table[class=\"fix-box\"]{\r\n    padding-left:20px !important;\r\n    padding-right:20px !important;\r\n  }\r\n  td[class=\"fix-box\"]{\r\n    padding-left:20px !important;\r\n    padding-right:20px !important;\r\n  }\r\n\r\n  td[class=\"font-resize\"]{\r\n    font-size: 18px !important;\r\n    line-height: 22px !important;\r\n  }\r\n\r\n\r\n}\r\n\r\n\r\n\r\n@media only screen and (max-width: 479px){\r\n  body{\r\n    font-size:10px !important;\r\n  }\r\n\r\n   table[class=\"container2\"]{\r\n    width: 100%!important; \r\n    float:none !important;\r\n  }\r\n\r\n  img[class=\"image-100-percent\"]{\r\n    width:100% !important;\r\n    height:auto !important;\r\n    max-width:100% !important;\r\n    min-width:124px !important;\r\n  }\r\n    img[class=\"small-image-100-percent\"]{\r\n    width:100% !important;\r\n    height:auto !important;\r\n    max-width:100% !important;\r\n    min-width:124px !important;\r\n  }\r\n\r\n  table[class=\"full-width\"]{\r\n    width:100% !important;\r\n  }\r\n\r\n  table[class=\"full-width-text\"]{\r\n    width:100% !important;\r\n     background-color:#186e8a;\r\n     padding-left:20px !important;\r\n     padding-right:20px !important;\r\n  }\r\n\r\n  table[class=\"full-width-text2\"]{\r\n    width:100% !important;\r\n     background-color:#f3f3f3;\r\n     padding-left:20px !important;\r\n     padding-right:20px !important;\r\n  }\r\n\r\n\r\n\r\n  table[class=\"col-2\"]{\r\n    width:100% !important;\r\n    margin-right:0px !important;\r\n  }\r\n\r\n  table[class=\"col-2-last\"]{\r\n    width:100% !important;\r\n   \r\n  }\r\n\r\n  table[class=\"col-3\"]{\r\n    width:100% !important;\r\n    margin-right:0px !important;\r\n  }\r\n\r\n  table[class=\"col-3-last\"]{\r\n    width:100% !important;\r\n   \r\n  }\r\n\r\n    table[class=\"row-2\"]{\r\n    width:100% !important;\r\n  }\r\n\r\n\r\n  table[id=\"col-underline\"]{\r\n    float: none !important;\r\n    width: 100% !important;\r\n    border-bottom: 1px solid #eee;\r\n  }\r\n\r\n  td[id=\"col-underline\"]{\r\n    float: none !important;\r\n    width: 100% !important;\r\n    border-bottom: 1px solid #eee;\r\n  }\r\n\r\n  td[class=\"col-underline\"]{\r\n    float: none !important;\r\n    width: 100% !important;\r\n    border-bottom: 1px solid #eee;\r\n  }\r\n\r\n\r\n\r\n   /*start text center*/\r\n  td[class=\"text-center\"]{\r\n    text-align: center !important;\r\n\r\n  }\r\n\r\n  div[class=\"text-center\"]{\r\n    text-align: center !important;\r\n  }\r\n   /*end text center*/\r\n\r\n\r\n\r\n  /* start  clear and remove */\r\n\r\n  table[id=\"clear-padding\"]{\r\n    padding:0 !important;\r\n  }\r\n  td[id=\"clear-padding\"]{\r\n    padding:0 !important;\r\n  }\r\n  td[class=\"clear-padding\"]{\r\n    padding:0 !important;\r\n  }\r\n  table[class=\"remove-479\"]{\r\n    display:none !important;\r\n  }\r\n  td[class=\"remove-479\"]{\r\n    display:none !important;\r\n  }\r\n  table[class=\"clear-align\"]{\r\n    float:none !important;\r\n  }\r\n  /* end  clear and remove */\r\n\r\n  table[class=\"width-small\"]{\r\n    width:100% !important;\r\n  }\r\n\r\n  table[class=\"fix-box\"]{\r\n    padding-left:0px !important;\r\n    padding-right:0px !important;\r\n  }\r\n  td[class=\"fix-box\"]{\r\n    padding-left:0px !important;\r\n    padding-right:0px !important;\r\n  }\r\n    td[class=\"font-resize\"]{\r\n    font-size: 14px !important;\r\n  }\r\n\r\n}\r\n@media only screen and (max-width: 320px){\r\n  table[class=\"width-small\"]{\r\n    width:125px !important;\r\n  }\r\n  img[class=\"image-100-percent\"]{\r\n    width:100% !important;\r\n    height:auto !important;\r\n    max-width:100% !important;\r\n    min-width:124px !important;\r\n  }\r\n\r\n}\r\n</style>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<!--start 100% wrapper (white background) -->\r\n<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"background-color:#ececec;\">\r\n\r\n  <!-- START TAB TOP -->\r\n    <tbody><tr>\r\n      <td valign=\"top\">\r\n        <table width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"height:6px; background-color:#2f9bbe;\">\r\n          <tbody><tr>\r\n            <td valign=\"top\" height=\"6\">\r\n              <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\" style=\"height:6px;\">\r\n                <tbody><tr>\r\n                  <td valign=\"top\" align=\"center\"> \r\n                    <table width=\"150\" align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"clear-align\" style=\"height:6px; background-color:#186e8a;\">\r\n                      <tbody><tr>\r\n                        <td valign=\"top\" height=\"6\"></td>\r\n                      </tr>\r\n                    </tbody></table>\r\n                  </td>\r\n                </tr>\r\n              </tbody></table>\r\n            </td>\r\n          </tr>\r\n        </tbody></table>\r\n      </td>\r\n    </tr>\r\n  <!-- END TAB TOP -->\r\n\r\n  <!--START TOP NAVIGATION ?LAYOUT-->\r\n  <tr>\r\n    <td align=\"center\" valign=\"top\" class=\"fix-box\">\r\n      \r\n      <!-- start top navigation container -->\r\n      <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"container\" bgcolor=\"#ffffff\" style=\"background-color:#ffffff;\">\r\n      \r\n        <tbody><tr>\r\n          <td valign=\"top\">\r\n              \r\n\r\n            <!-- start top navigaton -->\r\n            <table width=\"560\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\">\r\n              <tbody><tr>\r\n                <td valign=\"top\">\r\n                \r\n                <table align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"container2\">\r\n                 \r\n                  <tbody><tr>\r\n                    <td align=\"center\" valign=\"middle\">\r\n                       <a href=\"#\"><img src=\"http://localhost/sikul/assets/themes/admin/img/logo-sm.png\" width=\"124\" style=\"max-width:124px;\" alt=\"Logo\" border=\"0\" hspace=\"0\" vspace=\"0\"></a>\r\n                    </td>\r\n                  </tr>\r\n\r\n                </tbody></table>\r\n\r\n                <!--start content nav -->\r\n                <table border=\"0\" align=\"right\" cellpadding=\"0\" cellspacing=\"0\" class=\"container2\">\r\n\r\n                   <tbody><tr>\r\n                    <td height=\"20\" valign=\"top\" class=\"remove-479\"></td>\r\n                  </tr>\r\n\r\n                   <!--start call us -->\r\n                  <tr>\r\n                     <td valign=\"top\" align=\"center\">\r\n                    \r\n                    <table align=\"right\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"clear-align\">\r\n                      <tbody><tr>\r\n                      \r\n\r\n                        <td style=\"font-size: 13px;  line-height: 18px; color: #555555;  font-weight:normal; text-align: center; font-family:Arail,Tahoma, Helvetica, Arial, sans-serif;\">\r\n\r\n                          <span style=\"color: #2f9bbe;\">CALL US</span>\r\n                          +254 721 341 214\r\n                        </td>\r\n                      </tr>\r\n\r\n                    </tbody></table>\r\n                    </td>\r\n                  </tr>\r\n                  <!--end call us -->\r\n\r\n                  <!-- start space height -->\r\n                   <tr>\r\n                    <td height=\"10\" valign=\"top\"></td>\r\n                  </tr>\r\n                  <!-- start space height -->\r\n\r\n\r\n                  <!--start view online -->\r\n                  <tr>\r\n                    <td valign=\"top\" align=\"center\">\r\n                    \r\n                    <table align=\"right\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"clear-align\">\r\n\r\n                      <tbody><tr>\r\n                      \r\n                        <td align=\"center\" style=\"font-size: 13px;  line-height: 18px; color: #555555;  font-weight:normal; text-align: center; font-family:Arail,Tahoma, Helvetica, Arial, sans-serif;\">\r\n\r\n                          <span style=\"color: #2f9bbe;\">View online</span>\r\n                          \r\n                        </td>\r\n                      </tr>\r\n\r\n                    </tbody></table>\r\n                    </td>\r\n                  </tr>\r\n                  <!--end view online -->\r\n                  \r\n                \r\n                   <tr>\r\n                    <td height=\"20\" valign=\"top\"></td>\r\n                  </tr>\r\n\r\n                </tbody></table>\r\n                <!--end content nav -->\r\n\r\n               </td>\r\n             </tr>\r\n			 <tr>\r\n		   <td align=\"center\" valign=\"top\" class=\"fix-box\">\r\n			 <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"container\" style=\"background-color:#ffffff;\">\r\n			   <tbody>\r\n			   <tr>\r\n				 <td valign=\"top\" align=\"center\" style=\"background-color:#ffffff;\">\r\n				   <a href=\"#\">\r\n					 <img class=\"image-100-percent\" src=\"http://localhost/sikul/assets/themes/admin/img/email/Divider.png\" height=\"9\" alt=\"Divider\" style=\"display:block; max-height:9px; \" border=\"0\" hspace=\"0\" vspace=\"0\"> \r\n				   </a>\r\n				 </td>\r\n               </tr>\r\n     </tbody></table>\r\n   </td>\r\n </tr>\r\n           </tbody></table>\r\n           <!-- end top navigaton -->\r\n          </td>\r\n        </tr>\r\n      </tbody></table>\r\n      <!-- end top navigation container -->\r\n\r\n    </td>\r\n  </tr>\r\n   <!--END TOP NAVIGATION ?LAYOUT-->\r\n\r\n   \r\n <!-- START LAYOUT 11 --> \r\n<tr>\r\n <td align=\"center\" valign=\"top\" class=\"fix-box\">\r\n  <table width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\">\r\n    <tbody><tr>\r\n      <td valign=\"top\">\r\n        \r\n\r\n      \r\n\r\n   <!-- start layout-11 container width 600px --> \r\n   <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"container\" bgcolor=\"#ffffff\" style=\"background-color: #ffffff; \">\r\n\r\n\r\n     <tbody><tr>\r\n       <td valign=\"top\">\r\n\r\n         <!-- start layout-11 container width 560px --> \r\n         <table width=\"560\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\" bgcolor=\"#ffffff\" style=\"background-color: #ffffff;\">\r\n\r\n\r\n           <!-- start image content --> \r\n           <tbody><tr>\r\n             <td valign=\"top\" width=\"100%\">\r\n\r\n\r\n\r\n\r\n              <!-- start content left -->                      \r\n              <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"left\" class=\"full-width\">\r\n\r\n               <!--start space height --> \r\n               <tbody><tr>\r\n                 <td height=\"20\"></td>\r\n               </tr>\r\n               <!--end space height --> \r\n\r\n                \r\n\r\n                <!--start space height -->                      \r\n                <tr>\r\n                  <td height=\"20\"></td>\r\n                </tr>\r\n                <!--end space height -->                      \r\n\r\n                <tr>\r\n                  <td valign=\"top\">\r\n\r\n                    <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"left\">\r\n                      <tbody><tr>\r\n\r\n                        <!-- space width -->                      \r\n                        <td valign=\"top\">\r\n                          <table width=\"20\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"left\">\r\n                            <tbody><tr>\r\n                              <td valign=\"top\"></td>\r\n                            </tr>\r\n                          </tbody></table>\r\n                        </td>\r\n                        <!-- space width -->                      \r\n\r\n                         <!-- start text content --> \r\n                         <td valign=\"top\">\r\n                           <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"left\" class=\"width-small\">\r\n                            \r\n                             <tbody><tr>\r\n                               <td style=\"text-align: left;\"><font color=\"#a3a2a2\" face=\"Arial, Tahoma, Helvetica, sans-serif\"><span style=\"line-height: 22px;\">\r\n                                   From: [FROM]</span></font><br><font color=\"#a3a2a2\" face=\"Arial, Tahoma, Helvetica, sans-serif\"><span style=\"line-height: 22px;\"> \r\n								   To: [TO]</span></font><br><font color=\"#a3a2a2\" face=\"Arial, Tahoma, Helvetica, sans-serif\"><span style=\"line-height: 22px;\">\r\n                                  REF: </span></font><b style=\"color: rgb(163, 162, 162); font-family: Arial, Tahoma, Helvetica, sans-serif; font-size: 13px; font-weight: normal; line-height: 22px; text-decoration: underline;\">[SUBJECT]<br></b><font color=\"#a3a2a2\" face=\"Arial, Tahoma, Helvetica, sans-serif\"><span style=\"line-height: 22px;\">Meeting Title: [MEETING TITLE]<br>Start Date: [DATE FROM]</span></font><br><font color=\"#a3a2a2\" face=\"Arial, Tahoma, Helvetica, sans-serif\"><span style=\"line-height: 22px;\">End Date: [DATE TO]</span></font><br><font color=\"#a3a2a2\" face=\"Arial, Tahoma, Helvetica, sans-serif\"><span style=\"line-height: 22px;\">Venue: [VENUE]</span></font><br><font color=\"#a3a2a2\" face=\"Arial, Tahoma, Helvetica, sans-serif\"><span style=\"line-height: 22px;\">Importance: [IMPORTANCE]</span></font><br><font color=\"#a3a2a2\" face=\"Arial, Tahoma, Helvetica, sans-serif\"><span style=\"line-height: 22px;\">\r\n								 \r\n								 \r\n                                  [DESCRIPTION]\r\n                                 \r\n\r\n                               </span></font></td>\r\n                             </tr> \r\n                             <!-- start height -->\r\n                             <tr>\r\n                               <td valign=\"top\" height=\"10\"></td>\r\n                             </tr>\r\n                              <!-- end height -->\r\n\r\n                             <tr>\r\n                               <td style=\"font-size: 13px; line-height: 22px; font-family:Arial,Tahoma, Helvetica, sans-serif; color:#a3a2a2; font-weight:normal; text-align:left; \">\r\n\r\n                                   <span style=\"color: #2f9bbe;\">www.smartshule.com</span> : for more details. \r\n\r\n                               </td>\r\n                             </tr>                               \r\n                           </tbody></table>\r\n                         </td>\r\n                         <!-- end text content --> \r\n\r\n                      </tr>\r\n                    </tbody></table>\r\n\r\n                  </td>\r\n                </tr>\r\n\r\n                <!--start space height -->                      \r\n                <tr>\r\n                  <td height=\"20\"></td>\r\n                </tr>\r\n                <!--end space height --> \r\n              </tbody></table>\r\n              <!-- end content left --> \r\n\r\n             </td>\r\n           </tr>\r\n           <!-- end image content --> \r\n\r\n         </tbody></table>\r\n         <!-- end layout-11 container width 560px --> \r\n       </td>\r\n     </tr>\r\n   </tbody></table>\r\n   <!-- end layout-11 container width 600px --> \r\n    </td>\r\n    </tr>\r\n\r\n  </tbody></table>\r\n </td>\r\n</tr>\r\n\r\n\r\n <!-- END LAYOUT 11 --> \r\n\r\n\r\n\r\n  <!-- start bottom angle finish layout-->\r\n    <tr>\r\n      <td valign=\"top\" class=\"fix-box\">\r\n        <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\">\r\n          <tbody><tr>\r\n            <td valign=\"top\" width=\"20\">\r\n              <table width=\"20\" align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                <tbody><tr>\r\n\r\n                  <td valign=\"top\" align=\"left\">\r\n                    <a href=\"#\">\r\n                      <img src=\"http://localhost/sikul/assets/themes/admin/img/email/Angle-top-left.png\" width=\"20\" alt=\"Angle-top-left\" style=\"display:block; max-width:20px; \" border=\"0\" hspace=\"0\" vspace=\"0\">            \r\n                    </a>\r\n                  </td>\r\n\r\n                </tr>\r\n              </tbody></table>\r\n            </td>\r\n\r\n            <td valign=\"top\">\r\n             <table width=\"560\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\" bgcolor=\"#b4b3b3\" style=\"background-color: #b4b3b3; \">\r\n               <tbody><tr>\r\n\r\n                 <td valign=\"top\" align=\"center\" height=\"20\" bgcolor=\"#b4b3b3\" style=\"background-color: #b4b3b3; \"></td>\r\n\r\n               </tr>\r\n             </tbody></table>\r\n            </td>\r\n\r\n          <td valign=\"top\" width=\"20\">\r\n              <table width=\"20\" align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                <tbody><tr>\r\n\r\n                  <td valign=\"top\" align=\"left\">\r\n                    <a href=\"#\">\r\n                      <img src=\"http://localhost/sikul/assets/themes/admin/img/email/Angle-top-right.png\" width=\"20\" alt=\"Angle-top-left\" style=\"display:block; max-width:20px; \" border=\"0\" hspace=\"0\" vspace=\"0\">            \r\n                    </a>\r\n                  </td>\r\n\r\n                </tr>\r\n              </tbody></table>\r\n            </td>\r\n\r\n          </tr>\r\n        </tbody></table>\r\n      </td>\r\n    </tr>\r\n    <!-- end bottom angle finish layout-->\r\n\r\n\r\n<!-- START FOOTER layout-->\r\n  <tr>\r\n    <td align=\"center\" valign=\"top\" bgcolor=\"#ffffff\" style=\"background-color: #ffffff; \">\r\n\r\n      <!-- start top navigation container -->  \r\n      <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"container\" bgcolor=\"#ffffff\">\r\n        <tbody><tr>\r\n          <td valign=\"top\">\r\n\r\n            <table width=\"560\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\" bgcolor=\"#ffffff\">\r\n              <!--start space height -->                      \r\n              <tbody><tr>\r\n                <td height=\"10\"></td>\r\n              </tr>\r\n              <!--end space height --> \r\n              <tr>\r\n                <td valign=\"top\">\r\n\r\n\r\n                  <!-- start logo footer and address -->  \r\n                  <table width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                    <tbody><tr>\r\n                      <td valign=\"top\">\r\n\r\n                        <table width=\"300\" align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\">\r\n                          <tbody><tr>\r\n                            <td>\r\n                              <table align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\">\r\n\r\n                                <tbody><tr>\r\n                                  <td align=\"center\" valign=\"middle\">\r\n                                    <a href=\"#\">\r\n                                      <img src=\"http://localhost/sikul/assets/themes/admin/img/logo-sm.png\" width=\"124\" style=\"max-width:124px;\" alt=\"Logo\" border=\"0\" hspace=\"0\" vspace=\"0\">                        \r\n                                    </a>\r\n                                  </td>\r\n                                </tr>\r\n\r\n                              </tbody></table>\r\n                            </td>\r\n                          </tr>\r\n\r\n                          <tr>\r\n                            <td valign=\"top\" align=\"center\" style=\"font-size: 13px; line-height: 22px; font-family: Helvetica, sans-serif,Arial,Tahoma; color:#6d6d6d; font-weight:normal; text-align:left;\" class=\"text-center\">\r\n                              \r\n                                Company Name : <span style=\"color: #6d6d6d; font-weight: normal;\">Smart shule</span> <br>                 \r\n                                Mail Us : <span style=\"color: #2f9bbe; font-weight: normal;\"><a href=\"#\" style=\"text-decoration: none; color: #2f9bbe; font-weight: normal;\">info@smartshule.com</a> </span><br>\r\n                               Call Us : (254) 721 341 214\r\n\r\n                            </td>\r\n                          </tr>\r\n\r\n                        </tbody></table>\r\n\r\n                        <!--start icon socail navigation -->  \r\n                        <table border=\"0\" align=\"right\" cellpadding=\"0\" cellspacing=\"0\" class=\"container\">\r\n\r\n                           <!--start space height -->                      \r\n                          <tbody><tr>\r\n                            <td height=\"20\"></td>\r\n                          </tr>\r\n                          <!--end space height --> \r\n\r\n                           <tr>\r\n                            <td style=\"font-size: 22px; line-height: 24px; font-family: Arial,Tahoma,Helvetica, sans-serif; color:#555555; font-weight:normal; text-align:left; \" class=\"text-center\"><span style=\"color: #555555; font-weight: normal;\">Smart<a href=\"#\" style=\"text-decoration: none; color: #555555; font-weight: normal;\">&nbsp;<span style=\"color:#2f9bbe;\">Shule</span><br> \r\n                                    <span style=\"color:#a3a2a2; font-size:12px; line-height: 16px; font-weight: normal;\">FOLLOW US ON SOCAIL</span>\r\n                                 \r\n                                </a>\r\n                              </span>\r\n                            </td>\r\n                          </tr>\r\n\r\n                          <tr>\r\n                            <td valign=\"top\" align=\"left\">\r\n\r\n                              <table border=\"0\" align=\"left\" cellpadding=\"0\" cellspacing=\"0\" class=\"container\">\r\n                                <tbody><tr>\r\n                                  <td height=\"50\" align=\"center\" valign=\"middle\" class=\"clear-padding\">\r\n                                    <a href=\"#\">\r\n                                      <img src=\"http://localhost/sikul/assets/themes/admin/img/email/icon-facebook.jpg\" width=\"30\" alt=\"icon-facebook\" style=\"max-width:33px;\" border=\"0\" hspace=\"0\" vspace=\"0\">  \r\n                                    </a>\r\n                                  </td>\r\n                                  <td style=\"padding-left:5px; \" height=\"50\" align=\"center\" valign=\"middle\" class=\"clear-padding\">\r\n                                    <a href=\"#\">\r\n                                      <img src=\"http://localhost/sikul/assets/themes/admin/img/email/icon-twitter.jpg\" width=\"30\" alt=\"icon-twitter\" style=\"max-width:30px;\" border=\"0\" hspace=\"0\" vspace=\"0\">  \r\n                                    </a>\r\n                                  </td>\r\n                                  <td style=\"padding-left:5px; \" height=\"50\" align=\"center\" valign=\"middle\" class=\"clear-padding\">\r\n                                    <a href=\"#\">\r\n                                      <img src=\"http://localhost/sikul/assets/themes/admin/img/email/icon-googleplus.jpg\" width=\"30\" alt=\"icon-googleplus\" style=\"max-width:30px;\" border=\"0\" hspace=\"0\" vspace=\"0\">  \r\n                                    </a>\r\n                                  </td>\r\n                                  <td style=\"padding-left:5px;\" height=\"50\" align=\"center\" valign=\"middle\" class=\"clear-padding\">\r\n                                    <a href=\"#\">\r\n                                      <img src=\"http://localhost/sikul/assets/themes/admin/img/email/icon-rss.jpg\" width=\"30\" alt=\"icon-rss\" style=\"max-width:30px;\" border=\"0\" hspace=\"0\" vspace=\"0\">  \r\n                                    </a>\r\n                                  </td>\r\n                                  <td style=\"padding-left:5px;\" height=\"50\" align=\"center\" valign=\"middle\" class=\"clear-padding\">\r\n                                    <a href=\"#\">\r\n                                      </a></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table>','live',3,1402070442,NULL,NULL),(2,'General','general','This is General Email template','<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\r\n<meta name=\"viewport\" content=\"initial-scale=1.0\"> \r\n<meta name=\"format-detection\" content=\"telephone=no\">\r\n<title>Church Email</title>\r\n<style type=\"text/css\">\r\n\r\n/* Resets: see reset.css for details */\r\n.ReadMsgBody { width: 100%; background-color: #ffffff;}\r\n.ExternalClass {width: 100%; background-color: #ffffff;}\r\n.ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {line-height:100%;}\r\nhtml{width: 100%; }\r\nbody {-webkit-text-size-adjust:none; -ms-text-size-adjust:none; }\r\nbody {margin:0; padding:0;}\r\ntable {border-spacing:0;}\r\nimg{display:block !important;}\r\n\r\ntable td {border-collapse:collapse;}\r\n.yshortcuts a {border-bottom: none !important;}\r\n\r\n\r\n/* \r\n\r\nmain color = #2f9bbe\r\n\r\nother color = #186e8a\r\n\r\n\r\n*/\r\n\r\n\r\nimg{height:auto !important;}\r\n\r\n\r\n@media only screen and (max-width: 640px){\r\n  body{\r\n    width:auto!important;\r\n  }\r\n\r\n  table[class=\"container\"]{\r\n    width: 100%!important;\r\n    padding-left: 20px!important; \r\n    padding-right: 20px!important; \r\n  }\r\n\r\n  img[class=\"image-100-percent\"]{\r\n    width:100% !important;\r\n    height:auto !important;\r\n    max-width:100% !important;\r\n  }\r\n\r\n  img[class=\"small-image-100-percent\"]{\r\n    width:100% !important;\r\n    height:auto !important;\r\n  }\r\n\r\n  table[class=\"full-width\"]{\r\n    width:100% !important;\r\n  }\r\n\r\n  table[class=\"full-width-text\"]{\r\n    width:100% !important;\r\n     background-color:#186e8a;\r\n     padding-left:20px !important;\r\n     padding-right:20px !important;\r\n  }\r\n\r\n  table[class=\"full-width-text2\"]{\r\n    width:100% !important;\r\n     background-color:#f3f3f3;\r\n     padding-left:20px !important;\r\n     padding-right:20px !important; \r\n  }\r\n\r\n  table[class=\"col-2-3img\"]{\r\n    width:50% !important;\r\n    margin-right: 20px !important;\r\n  }\r\n    table[class=\"col-2-3img-last\"]{\r\n    width:50% !important;\r\n  }\r\n\r\n  table[class=\"col-2\"]{\r\n    width:47% !important;\r\n    margin-right:20px !important;\r\n  }\r\n\r\n  table[class=\"col-2-last\"]{\r\n    width:47% !important;\r\n  }\r\n\r\n  table[class=\"col-3\"]{\r\n    width:29% !important;\r\n    margin-right:20px !important;\r\n  }\r\n\r\n  table[class=\"col-3-last\"]{\r\n    width:29% !important;\r\n  }\r\n\r\n  table[class=\"row-2\"]{\r\n    width:50% !important;\r\n  }\r\n\r\n  td[class=\"text-center\"]{\r\n     text-align: center !important;\r\n   }\r\n\r\n  /* start clear and remove*/\r\n  table[class=\"remove\"]{\r\n    display:none !important;\r\n  }\r\n\r\n  td[class=\"remove\"]{\r\n    display:none !important;\r\n  }\r\n  /* end clear and remove*/\r\n\r\n  table[class=\"fix-box\"]{\r\n    padding-left:20px !important;\r\n    padding-right:20px !important;\r\n  }\r\n  td[class=\"fix-box\"]{\r\n    padding-left:20px !important;\r\n    padding-right:20px !important;\r\n  }\r\n\r\n  td[class=\"font-resize\"]{\r\n    font-size: 18px !important;\r\n    line-height: 22px !important;\r\n  }\r\n\r\n\r\n}\r\n\r\n\r\n\r\n@media only screen and (max-width: 479px){\r\n  body{\r\n    font-size:10px !important;\r\n  }\r\n\r\n   table[class=\"container2\"]{\r\n    width: 100%!important; \r\n    float:none !important;\r\n  }\r\n\r\n  img[class=\"image-100-percent\"]{\r\n    width:100% !important;\r\n    height:auto !important;\r\n    max-width:100% !important;\r\n    min-width:124px !important;\r\n  }\r\n    img[class=\"small-image-100-percent\"]{\r\n    width:100% !important;\r\n    height:auto !important;\r\n    max-width:100% !important;\r\n    min-width:124px !important;\r\n  }\r\n\r\n  table[class=\"full-width\"]{\r\n    width:100% !important;\r\n  }\r\n\r\n  table[class=\"full-width-text\"]{\r\n    width:100% !important;\r\n     background-color:#186e8a;\r\n     padding-left:20px !important;\r\n     padding-right:20px !important;\r\n  }\r\n\r\n  table[class=\"full-width-text2\"]{\r\n    width:100% !important;\r\n     background-color:#f3f3f3;\r\n     padding-left:20px !important;\r\n     padding-right:20px !important;\r\n  }\r\n\r\n\r\n\r\n  table[class=\"col-2\"]{\r\n    width:100% !important;\r\n    margin-right:0px !important;\r\n  }\r\n\r\n  table[class=\"col-2-last\"]{\r\n    width:100% !important;\r\n   \r\n  }\r\n\r\n  table[class=\"col-3\"]{\r\n    width:100% !important;\r\n    margin-right:0px !important;\r\n  }\r\n\r\n  table[class=\"col-3-last\"]{\r\n    width:100% !important;\r\n   \r\n  }\r\n\r\n    table[class=\"row-2\"]{\r\n    width:100% !important;\r\n  }\r\n\r\n\r\n  table[id=\"col-underline\"]{\r\n    float: none !important;\r\n    width: 100% !important;\r\n    border-bottom: 1px solid #eee;\r\n  }\r\n\r\n  td[id=\"col-underline\"]{\r\n    float: none !important;\r\n    width: 100% !important;\r\n    border-bottom: 1px solid #eee;\r\n  }\r\n\r\n  td[class=\"col-underline\"]{\r\n    float: none !important;\r\n    width: 100% !important;\r\n    border-bottom: 1px solid #eee;\r\n  }\r\n\r\n\r\n\r\n   /*start text center*/\r\n  td[class=\"text-center\"]{\r\n    text-align: center !important;\r\n\r\n  }\r\n\r\n  div[class=\"text-center\"]{\r\n    text-align: center !important;\r\n  }\r\n   /*end text center*/\r\n\r\n\r\n\r\n  /* start  clear and remove */\r\n\r\n  table[id=\"clear-padding\"]{\r\n    padding:0 !important;\r\n  }\r\n  td[id=\"clear-padding\"]{\r\n    padding:0 !important;\r\n  }\r\n  td[class=\"clear-padding\"]{\r\n    padding:0 !important;\r\n  }\r\n  table[class=\"remove-479\"]{\r\n    display:none !important;\r\n  }\r\n  td[class=\"remove-479\"]{\r\n    display:none !important;\r\n  }\r\n  table[class=\"clear-align\"]{\r\n    float:none !important;\r\n  }\r\n  /* end  clear and remove */\r\n\r\n  table[class=\"width-small\"]{\r\n    width:100% !important;\r\n  }\r\n\r\n  table[class=\"fix-box\"]{\r\n    padding-left:0px !important;\r\n    padding-right:0px !important;\r\n  }\r\n  td[class=\"fix-box\"]{\r\n    padding-left:0px !important;\r\n    padding-right:0px !important;\r\n  }\r\n    td[class=\"font-resize\"]{\r\n    font-size: 14px !important;\r\n  }\r\n\r\n}\r\n@media only screen and (max-width: 320px){\r\n  table[class=\"width-small\"]{\r\n    width:125px !important;\r\n  }\r\n  img[class=\"image-100-percent\"]{\r\n    width:100% !important;\r\n    height:auto !important;\r\n    max-width:100% !important;\r\n    min-width:124px !important;\r\n  }\r\n\r\n}\r\n</style>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<!--start 100% wrapper (white background) -->\r\n<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"background-color:#ececec;\">\r\n\r\n  <!-- START TAB TOP -->\r\n    <tbody><tr>\r\n      <td valign=\"top\">\r\n        <table width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"height:6px; background-color:#2f9bbe;\">\r\n          <tbody><tr>\r\n            <td valign=\"top\" height=\"6\">\r\n              <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\" style=\"height:6px;\">\r\n                <tbody><tr>\r\n                  <td valign=\"top\" align=\"center\"> \r\n                    <table width=\"150\" align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"clear-align\" style=\"height:6px; background-color:#186e8a;\">\r\n                      <tbody><tr>\r\n                        <td valign=\"top\" height=\"6\"></td>\r\n                      </tr>\r\n                    </tbody></table>\r\n                  </td>\r\n                </tr>\r\n              </tbody></table>\r\n            </td>\r\n          </tr>\r\n        </tbody></table>\r\n      </td>\r\n    </tr>\r\n  <!-- END TAB TOP -->\r\n\r\n  <!--START TOP NAVIGATION ?LAYOUT-->\r\n  <tr>\r\n    <td align=\"center\" valign=\"top\" class=\"fix-box\">\r\n      \r\n      <!-- start top navigation container -->\r\n      <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"container\" bgcolor=\"#ffffff\" style=\"background-color:#ffffff;\">\r\n      \r\n        <tbody><tr>\r\n          <td valign=\"top\">\r\n              \r\n\r\n            <!-- start top navigaton -->\r\n            <table width=\"560\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\">\r\n              <tbody><tr>\r\n                <td valign=\"top\">\r\n                \r\n                <table align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"container2\">\r\n                 \r\n                  <tbody><tr>\r\n                    <td align=\"center\" valign=\"middle\">\r\n                       <a href=\"#\"><img src=\"http://localhost/kanisa/assets/themes/admin/img/logo.png\" width=\"124\" style=\"max-width:124px;\" alt=\"Logo\" border=\"0\" hspace=\"0\" vspace=\"0\"></a>\r\n                    </td>\r\n                  </tr>\r\n\r\n                </tbody></table>\r\n\r\n                <!--start content nav -->\r\n                <table border=\"0\" align=\"right\" cellpadding=\"0\" cellspacing=\"0\" class=\"container2\">\r\n\r\n                   <tbody><tr>\r\n                    <td height=\"20\" valign=\"top\" class=\"remove-479\"></td>\r\n                  </tr>\r\n\r\n                   <!--start call us -->\r\n                  <tr>\r\n                     <td valign=\"top\" align=\"center\">\r\n                    \r\n                    <table align=\"right\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"clear-align\">\r\n                      <tbody><tr>\r\n                      \r\n\r\n                        <td style=\"font-size: 13px;  line-height: 18px; color: #555555;  font-weight:normal; text-align: center; font-family:Arail,Tahoma, Helvetica, Arial, sans-serif;\">\r\n\r\n                          <span style=\"color: #2f9bbe;\">CALL US</span>\r\n                          +254 721 341 214\r\n                        </td>\r\n                      </tr>\r\n\r\n                    </tbody></table>\r\n                    </td>\r\n                  </tr>\r\n                  <!--end call us -->\r\n\r\n                  <!-- start space height -->\r\n                   <tr>\r\n                    <td height=\"10\" valign=\"top\"></td>\r\n                  </tr>\r\n                  <!-- start space height -->\r\n\r\n\r\n                  <!--start view online -->\r\n                  <tr>\r\n                    <td valign=\"top\" align=\"center\">\r\n                    \r\n                    <table align=\"right\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"clear-align\">\r\n\r\n                      <tbody><tr>\r\n                      \r\n                        <td align=\"center\" style=\"font-size: 13px;  line-height: 18px; color: #555555;  font-weight:normal; text-align: center; font-family:Arail,Tahoma, Helvetica, Arial, sans-serif;\">\r\n\r\n                          <span style=\"color: #2f9bbe;\">View online</span>\r\n                          \r\n                        </td>\r\n                      </tr>\r\n\r\n                    </tbody></table>\r\n                    </td>\r\n                  </tr>\r\n                  <!--end view online -->\r\n                  \r\n                \r\n                   <tr>\r\n                    <td height=\"20\" valign=\"top\"></td>\r\n                  </tr>\r\n\r\n                </tbody></table>\r\n                <!--end content nav -->\r\n\r\n               </td>\r\n             </tr>\r\n			 <tr>\r\n		   <td align=\"center\" valign=\"top\" class=\"fix-box\">\r\n			 <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"container\" style=\"background-color:#ffffff;\">\r\n			   <tbody>\r\n			   <tr>\r\n				 <td valign=\"top\" align=\"center\" style=\"background-color:#ffffff;\">\r\n				   <a href=\"#\">\r\n					 <img class=\"image-100-percent\" src=\"http://localhost/church/assets/themes/admin/img/email/Divider.png\" height=\"9\" alt=\"Divider\" style=\"display:block; max-height:9px; \" border=\"0\" hspace=\"0\" vspace=\"0\"> \r\n				   </a>\r\n				 </td>\r\n               </tr>\r\n     </tbody></table>\r\n   </td>\r\n </tr>\r\n           </tbody></table>\r\n           <!-- end top navigaton -->\r\n          </td>\r\n        </tr>\r\n      </tbody></table>\r\n      <!-- end top navigation container -->\r\n\r\n    </td>\r\n  </tr>\r\n   <!--END TOP NAVIGATION ?LAYOUT-->\r\n\r\n   \r\n <!-- START LAYOUT 11 --> \r\n<tr>\r\n <td align=\"center\" valign=\"top\" class=\"fix-box\">\r\n  <table width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\">\r\n    <tbody><tr>\r\n      <td valign=\"top\">\r\n        \r\n\r\n      \r\n\r\n   <!-- start layout-11 container width 600px --> \r\n   <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"container\" bgcolor=\"#ffffff\" style=\"background-color: #ffffff; \">\r\n\r\n\r\n     <tbody><tr>\r\n       <td valign=\"top\">\r\n\r\n         <!-- start layout-11 container width 560px --> \r\n         <table width=\"560\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\" bgcolor=\"#ffffff\" style=\"background-color: #ffffff;\">\r\n\r\n\r\n           <!-- start image content --> \r\n           <tbody><tr>\r\n             <td valign=\"top\" width=\"100%\">\r\n\r\n\r\n\r\n\r\n              <!-- start content left -->                      \r\n              <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"left\" class=\"full-width\">\r\n\r\n               <!--start space height --> \r\n               <tbody><tr>\r\n                 <td height=\"20\"></td>\r\n               </tr>\r\n               <!--end space height --> \r\n\r\n                \r\n\r\n                <!--start space height -->                      \r\n                <tr>\r\n                  <td height=\"20\"></td>\r\n                </tr>\r\n                <!--end space height -->                      \r\n\r\n                <tr>\r\n                  <td valign=\"top\">\r\n\r\n                    <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"left\">\r\n                      <tbody><tr>\r\n\r\n                        <!-- space width -->                      \r\n                        <td valign=\"top\">\r\n                          <table width=\"20\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"left\">\r\n                            <tbody><tr>\r\n                              <td valign=\"top\"></td>\r\n                            </tr>\r\n                          </tbody></table>\r\n                        </td>\r\n                        <!-- space width -->                      \r\n\r\n                         <!-- start text content --> \r\n                         <td valign=\"top\">\r\n                           <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"left\" class=\"width-small\">\r\n                            \r\n                             <tbody><tr>\r\n                               <td style=\"font-size: 13px; line-height: 22px; font-family:Arial,Tahoma, Helvetica, sans-serif; color:#a3a2a2; font-weight:normal; text-align:left; \">\r\n                                   From: [FROM]<br> \r\n								   To: [TO]<br>\r\n                                  REF: <b style=\"text-decoration:underline\">[SUBJECT]</b><br>\r\n								 \r\n								 \r\n                                  [DESCRIPTION]\r\n                                 \r\n\r\n                               </td>\r\n                             </tr> \r\n                             <!-- start height -->\r\n                             <tr>\r\n                               <td valign=\"top\" height=\"10\"></td>\r\n                             </tr>\r\n                              <!-- end height -->\r\n\r\n                             <tr>\r\n                               <td style=\"font-size: 13px; line-height: 22px; font-family:Arial,Tahoma, Helvetica, sans-serif; color:#a3a2a2; font-weight:normal; text-align:left; \">\r\n\r\n                                   <span style=\"color: #2f9bbe;\">www.smartchurch.com</span> : for more details. \r\n\r\n                               </td>\r\n                             </tr>                               \r\n                           </tbody></table>\r\n                         </td>\r\n                         <!-- end text content --> \r\n\r\n                      </tr>\r\n                    </tbody></table>\r\n\r\n                  </td>\r\n                </tr>\r\n\r\n                <!--start space height -->                      \r\n                <tr>\r\n                  <td height=\"20\"></td>\r\n                </tr>\r\n                <!--end space height --> \r\n              </tbody></table>\r\n              <!-- end content left --> \r\n\r\n             </td>\r\n           </tr>\r\n           <!-- end image content --> \r\n\r\n         </tbody></table>\r\n         <!-- end layout-11 container width 560px --> \r\n       </td>\r\n     </tr>\r\n   </tbody></table>\r\n   <!-- end layout-11 container width 600px --> \r\n    </td>\r\n    </tr>\r\n\r\n  </tbody></table>\r\n </td>\r\n</tr>\r\n\r\n\r\n <!-- END LAYOUT 11 --> \r\n\r\n\r\n\r\n  <!-- start bottom angle finish layout-->\r\n    <tr>\r\n      <td valign=\"top\" class=\"fix-box\">\r\n        <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\">\r\n          <tbody><tr>\r\n            <td valign=\"top\" width=\"20\">\r\n              <table width=\"20\" align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                <tbody><tr>\r\n\r\n                  <td valign=\"top\" align=\"left\">\r\n                    <a href=\"#\">\r\n                      <img src=\"http://localhost/church/assets/themes/admin/img/email/Angle-top-left.png\" width=\"20\" alt=\"Angle-top-left\" style=\"display:block; max-width:20px; \" border=\"0\" hspace=\"0\" vspace=\"0\">            \r\n                    </a>\r\n                  </td>\r\n\r\n                </tr>\r\n              </tbody></table>\r\n            </td>\r\n\r\n            <td valign=\"top\">\r\n             <table width=\"560\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\" bgcolor=\"#b4b3b3\" style=\"background-color: #b4b3b3; \">\r\n               <tbody><tr>\r\n\r\n                 <td valign=\"top\" align=\"center\" height=\"20\" bgcolor=\"#b4b3b3\" style=\"background-color: #b4b3b3; \"></td>\r\n\r\n               </tr>\r\n             </tbody></table>\r\n            </td>\r\n\r\n          <td valign=\"top\" width=\"20\">\r\n              <table width=\"20\" align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                <tbody><tr>\r\n\r\n                  <td valign=\"top\" align=\"left\">\r\n                    <a href=\"#\">\r\n                      <img src=\"http://localhost/church/assets/themes/admin/img/email/Angle-top-right.png\" width=\"20\" alt=\"Angle-top-left\" style=\"display:block; max-width:20px; \" border=\"0\" hspace=\"0\" vspace=\"0\">            \r\n                    </a>\r\n                  </td>\r\n\r\n                </tr>\r\n              </tbody></table>\r\n            </td>\r\n\r\n          </tr>\r\n        </tbody></table>\r\n      </td>\r\n    </tr>\r\n    <!-- end bottom angle finish layout-->\r\n\r\n\r\n<!-- START FOOTER layout-->\r\n  <tr>\r\n    <td align=\"center\" valign=\"top\" bgcolor=\"#ffffff\" style=\"background-color: #ffffff; \">\r\n\r\n      <!-- start top navigation container -->  \r\n      <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"container\" bgcolor=\"#ffffff\">\r\n        <tbody><tr>\r\n          <td valign=\"top\">\r\n\r\n            <table width=\"560\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\" bgcolor=\"#ffffff\">\r\n              <!--start space height -->                      \r\n              <tbody><tr>\r\n                <td height=\"10\"></td>\r\n              </tr>\r\n              <!--end space height --> \r\n              <tr>\r\n                <td valign=\"top\">\r\n\r\n\r\n                  <!-- start logo footer and address -->  \r\n                  <table width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                    <tbody><tr>\r\n                      <td valign=\"top\">\r\n\r\n                        <table width=\"300\" align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\">\r\n                          <tbody><tr>\r\n                            <td>\r\n                              <table align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\">\r\n\r\n                                <tbody><tr>\r\n                                  <td align=\"center\" valign=\"middle\">\r\n                                    <a href=\"#\">\r\n                                      <img src=\"http://localhost/kanisa/assets/themes/admin/img/logo.png\" width=\"124\" style=\"max-width:124px;\" alt=\"Logo\" border=\"0\" hspace=\"0\" vspace=\"0\">                        \r\n                                    </a>\r\n                                  </td>\r\n                                </tr>\r\n\r\n                              </tbody></table>\r\n                            </td>\r\n                          </tr>\r\n\r\n                          <tr>\r\n                            <td valign=\"top\" align=\"center\" style=\"font-size: 13px; line-height: 22px; font-family: Helvetica, sans-serif,Arial,Tahoma; color:#6d6d6d; font-weight:normal; text-align:left;\" class=\"text-center\">\r\n                              \r\n                                Company Name : <span style=\"color: #6d6d6d; font-weight: normal;\">Smart church</span> <br>                 \r\n                                Mail Us : <span style=\"color: #2f9bbe; font-weight: normal;\"><a href=\"#\" style=\"text-decoration: none; color: #2f9bbe; font-weight: normal;\">info@smartchurch.com</a> </span><br>\r\n                               Call Us : (254) 721 341 214\r\n\r\n                            </td>\r\n                          </tr>\r\n\r\n                        </tbody></table>\r\n\r\n                        <!--start icon socail navigation -->  \r\n                        <table border=\"0\" align=\"right\" cellpadding=\"0\" cellspacing=\"0\" class=\"container\">\r\n\r\n                           <!--start space height -->                      \r\n                          <tbody><tr>\r\n                            <td height=\"20\"></td>\r\n                          </tr>\r\n                          <!--end space height --> \r\n\r\n                           <tr>\r\n                            <td style=\"font-size: 22px; line-height: 24px; font-family: Arial,Tahoma,Helvetica, sans-serif; color:#555555; font-weight:normal; text-align:left; \" class=\"text-center\"><span style=\"color: #555555; font-weight: normal;\">Smart<a href=\"#\" style=\"text-decoration: none; color: #555555; font-weight: normal;\">&nbsp;<span style=\"color:#2f9bbe;\">Church</span><br> \r\n                                    <span style=\"color:#a3a2a2; font-size:12px; line-height: 16px; font-weight: normal;\">FOLLOW US ON SOCAIL</span>\r\n                                 \r\n                                </a>\r\n                              </span>\r\n                            </td>\r\n                          </tr>\r\n\r\n                          <tr>\r\n                            <td valign=\"top\" align=\"left\">\r\n\r\n                              <table border=\"0\" align=\"left\" cellpadding=\"0\" cellspacing=\"0\" class=\"container\">\r\n                                <tbody><tr>\r\n                                  <td height=\"50\" align=\"center\" valign=\"middle\" class=\"clear-padding\">\r\n                                    <a href=\"#\">\r\n                                      <img src=\"http://localhost/church/assets/themes/admin/img/email/icon-facebook.jpg\" width=\"30\" alt=\"icon-facebook\" style=\"max-width:33px;\" border=\"0\" hspace=\"0\" vspace=\"0\">  \r\n                                    </a>\r\n                                  </td>\r\n                                  <td style=\"padding-left:5px; \" height=\"50\" align=\"center\" valign=\"middle\" class=\"clear-padding\">\r\n                                    <a href=\"#\">\r\n                                      <img src=\"http://localhost/church/assets/themes/admin/img/email/icon-twitter.jpg\" width=\"30\" alt=\"icon-twitter\" style=\"max-width:30px;\" border=\"0\" hspace=\"0\" vspace=\"0\">  \r\n                                    </a>\r\n                                  </td>\r\n                                  <td style=\"padding-left:5px; \" height=\"50\" align=\"center\" valign=\"middle\" class=\"clear-padding\">\r\n                                    <a href=\"#\">\r\n                                      <img src=\"http://localhost/church/assets/themes/admin/img/email/icon-googleplus.jpg\" width=\"30\" alt=\"icon-googleplus\" style=\"max-width:30px;\" border=\"0\" hspace=\"0\" vspace=\"0\">  \r\n                                    </a>\r\n                                  </td>\r\n                                  <td style=\"padding-left:5px;\" height=\"50\" align=\"center\" valign=\"middle\" class=\"clear-padding\">\r\n                                    <a href=\"#\">\r\n                                      <img src=\"http://localhost/church/assets/themes/admin/img/email/icon-rss.jpg\" width=\"30\" alt=\"icon-rss\" style=\"max-width:30px;\" border=\"0\" hspace=\"0\" vspace=\"0\">  \r\n                                    </a>\r\n                                  </td>\r\n                                  <td style=\"padding-left:5px;\" height=\"50\" align=\"center\" valign=\"middle\" class=\"clear-padding\">\r\n                                    <a href=\"#\">\r\n                                      </a></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table>','live',3,1402070603,NULL,NULL);
/*!40000 ALTER TABLE `email_templates` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `emails`
DROP TABLE IF EXISTS `emails`;
CREATE TABLE `emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` blob,
  `sent_to` blob,
  `recipient` blob,
  `cc` blob,
  `description` blob,
  `attachment` blob,
  `type` blob,
  `status` blob,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `emails`
LOCK TABLES `emails` WRITE;
/*!40000 ALTER TABLE `emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `emails` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `employee_allowances`
DROP TABLE IF EXISTS `employee_allowances`;
CREATE TABLE `employee_allowances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_id` int(11) DEFAULT NULL,
  `allowance_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `employee_allowances`
LOCK TABLES `employee_allowances` WRITE;
/*!40000 ALTER TABLE `employee_allowances` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_allowances` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `employee_deductions`
DROP TABLE IF EXISTS `employee_deductions`;
CREATE TABLE `employee_deductions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_id` int(11) DEFAULT NULL,
  `deduction_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `employee_deductions`
LOCK TABLES `employee_deductions` WRITE;
/*!40000 ALTER TABLE `employee_deductions` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_deductions` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `events`
DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL DEFAULT '',
  `start_date` int(11) DEFAULT NULL,
  `end_date` int(11) DEFAULT NULL,
  `venue` varchar(256) NOT NULL DEFAULT '',
  `file` varchar(256) NOT NULL DEFAULT '',
  `status` varchar(32) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `events`
LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `expenses`
DROP TABLE IF EXISTS `expenses`;
CREATE TABLE `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `item` int(11) DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `person_responsible` varchar(32) NOT NULL DEFAULT '',
  `file` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `expenses`
LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `expenses_category`
DROP TABLE IF EXISTS `expenses_category`;
CREATE TABLE `expenses_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Dumping data for table `expenses_category`
LOCK TABLES `expenses_category` WRITE;
/*!40000 ALTER TABLE `expenses_category` DISABLE KEYS */;
INSERT INTO `expenses_category` VALUES (1,'Electricity','0',1,NULL,1421242519,NULL),(2,'Kitchen','0',1,NULL,1421243203,NULL),(3,'Water','0',1,NULL,1423131305,NULL),(4,'Cleaning','0',1,NULL,1423131365,NULL);
/*!40000 ALTER TABLE `expenses_category` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `expenses_items`
DROP TABLE IF EXISTS `expenses_items`;
CREATE TABLE `expenses_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- Dumping data for table `expenses_items`
LOCK TABLES `expenses_items` WRITE;
/*!40000 ALTER TABLE `expenses_items` DISABLE KEYS */;
INSERT INTO `expenses_items` VALUES (1,'test','',1,NULL,1421169935,NULL),(2,'Rice','0',1,NULL,1421170331,NULL),(3,'Mangose','0',1,NULL,1421170377,NULL),(4,'Electricity','0',1,NULL,1421242276,NULL),(5,'Water','0',1,NULL,1421848704,NULL),(6,'Carpet','0',1,NULL,1423131374,NULL),(7,'Soap','0',1,NULL,1432634684,NULL);
/*!40000 ALTER TABLE `expenses_items` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `files`
DROP TABLE IF EXISTS `files`;
CREATE TABLE `files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL DEFAULT '',
  `type` varchar(32) NOT NULL DEFAULT '',
  `file` varchar(256) NOT NULL DEFAULT '',
  `fpath` varchar(256) NOT NULL DEFAULT '',
  `Column 6` varchar(256) NOT NULL DEFAULT '',
  `filesize` varchar(256) NOT NULL DEFAULT '',
  `folder` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `files`
LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `folders`
DROP TABLE IF EXISTS `folders`;
CREATE TABLE `folders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `folders`
LOCK TABLES `folders` WRITE;
/*!40000 ALTER TABLE `folders` DISABLE KEYS */;
/*!40000 ALTER TABLE `folders` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `group_permissions`
DROP TABLE IF EXISTS `group_permissions`;
CREATE TABLE `group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `resource_id` int(11) NOT NULL,
  `campus_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table `group_permissions`
LOCK TABLES `group_permissions` WRITE;
/*!40000 ALTER TABLE `group_permissions` DISABLE KEYS */;
INSERT INTO `group_permissions` VALUES (1,4,1,NULL,1,1,1431426075,1431599246),(2,4,2,NULL,1,1,1431426211,1431599246),(3,4,5,NULL,1,NULL,1431426211,NULL),(4,4,10,NULL,1,NULL,1431426211,NULL),(5,4,11,NULL,1,NULL,1431426211,NULL),(6,4,15,NULL,1,NULL,1431426211,NULL),(7,4,16,NULL,1,NULL,1431426212,NULL),(8,4,19,NULL,1,NULL,1431426212,NULL),(9,4,21,NULL,1,NULL,1431426212,NULL),(10,4,27,NULL,1,NULL,1431426212,NULL),(11,4,28,NULL,1,NULL,1431426212,NULL),(12,4,29,NULL,1,NULL,1431426212,NULL),(13,4,30,NULL,1,NULL,1431426212,NULL),(14,4,31,NULL,1,NULL,1431426212,NULL),(15,4,32,NULL,1,NULL,1431426212,NULL),(16,4,33,NULL,1,NULL,1431426212,NULL),(17,4,39,NULL,1,NULL,1431426212,NULL),(18,4,42,NULL,1,NULL,1431426212,NULL),(19,4,47,NULL,1,NULL,1431426212,NULL),(20,4,3,NULL,1,NULL,1431599246,NULL);
/*!40000 ALTER TABLE `group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `groups`
DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table `groups`
LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES (1,'admin','Administrator',NULL,NULL,NULL,NULL),(2,'members','General Users',NULL,1,NULL,1379858359),(3,'committee','Committee Members',1,1,1379858307,1422967213),(4,'pastor','Church Pastors',1,1,1422970174,1422970198);
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `hbc_meetings`
DROP TABLE IF EXISTS `hbc_meetings`;
CREATE TABLE `hbc_meetings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `hbc` varchar(32) NOT NULL DEFAULT '',
  `host` varchar(256) NOT NULL DEFAULT '',
  `hosts_phone_no` varchar(256) NOT NULL DEFAULT '',
  `house_number` varchar(256) NOT NULL DEFAULT '',
  `service_leader` varchar(32) NOT NULL DEFAULT '',
  `preacher` varchar(256) NOT NULL DEFAULT '',
  `brief_description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `hbc_meetings`
LOCK TABLES `hbc_meetings` WRITE;
/*!40000 ALTER TABLE `hbc_meetings` DISABLE KEYS */;
/*!40000 ALTER TABLE `hbc_meetings` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `hbcs`
DROP TABLE IF EXISTS `hbcs`;
CREATE TABLE `hbcs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `estate` varchar(256) NOT NULL DEFAULT '',
  `meeting_day` varchar(32) NOT NULL DEFAULT '',
  `meeting_time` varchar(50) DEFAULT NULL,
  `overall_leader` varchar(32) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Dumping data for table `hbcs`
LOCK TABLES `hbcs` WRITE;
/*!40000 ALTER TABLE `hbcs` DISABLE KEYS */;
INSERT INTO `hbcs` VALUES (1,'Central','Church Ground','monday','07:00 PM','35','',1,NULL,1479810545,NULL),(2,'Nyamweru','Nyamweru Kitengela','monday','07:15 PM','80','',1,NULL,1479978911,NULL),(3,'Ashut','Ashut Kitengela','tuesday','07:30 PM','103','',1,NULL,1479994820,NULL);
/*!40000 ALTER TABLE `hbcs` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `hymns_manager`
DROP TABLE IF EXISTS `hymns_manager`;
CREATE TABLE `hymns_manager` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hymn_title` varchar(256) NOT NULL DEFAULT '',
  `composer` varchar(256) NOT NULL DEFAULT '',
  `category` varchar(32) NOT NULL DEFAULT '',
  `lyrics` text,
  `file` varchar(256) NOT NULL DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `hymns_manager`
LOCK TABLES `hymns_manager` WRITE;
/*!40000 ALTER TABLE `hymns_manager` DISABLE KEYS */;
/*!40000 ALTER TABLE `hymns_manager` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `meetings`
DROP TABLE IF EXISTS `meetings`;
CREATE TABLE `meetings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL DEFAULT '',
  `start_date` int(11) DEFAULT NULL,
  `end_date` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `venue` varchar(256) NOT NULL DEFAULT '',
  `others` varchar(256) DEFAULT NULL,
  `importance` varchar(256) NOT NULL DEFAULT '',
  `guests` varchar(32) NOT NULL DEFAULT '',
  `sms_alert` varchar(32) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `meetings`
LOCK TABLES `meetings` WRITE;
/*!40000 ALTER TABLE `meetings` DISABLE KEYS */;
/*!40000 ALTER TABLE `meetings` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `member_groups`
DROP TABLE IF EXISTS `member_groups`;
CREATE TABLE `member_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Dumping data for table `member_groups`
LOCK TABLES `member_groups` WRITE;
/*!40000 ALTER TABLE `member_groups` DISABLE KEYS */;
INSERT INTO `member_groups` VALUES (1,28,3,NULL,1,NULL,1424772418),(2,28,2,NULL,1,NULL,1424772418),(3,30,4,NULL,1,NULL,1433246304),(4,27,2,NULL,1,NULL,1433246342);
/*!40000 ALTER TABLE `member_groups` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `member_ministries`
DROP TABLE IF EXISTS `member_ministries`;
CREATE TABLE `member_ministries` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` varchar(20) NOT NULL,
  `ministry_id` varchar(100) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table `member_ministries`
LOCK TABLES `member_ministries` WRITE;
/*!40000 ALTER TABLE `member_ministries` DISABLE KEYS */;
INSERT INTO `member_ministries` VALUES (1,'43','4',1,NULL,1479825834,NULL),(2,'52','4',1,NULL,1479829182,NULL),(3,'56','4',1,NULL,1479831057,NULL),(4,'58','4',1,NULL,1479832937,NULL),(5,'59','4',1,NULL,1479833136,NULL),(6,'71','4',1,NULL,1479970916,NULL),(7,'72','6',1,NULL,1479971692,NULL),(8,'73','4',1,NULL,1479973399,NULL),(9,'73','4',1,NULL,1479973559,NULL),(10,'76','6',1,NULL,1479976557,NULL),(11,'80','6',1,NULL,1479979012,NULL),(12,'85','5',1,NULL,1479981249,NULL),(13,'87','4',1,NULL,1479987343,NULL),(14,'88','4',1,NULL,1479987616,NULL),(15,'96','4',1,NULL,1479989966,NULL),(16,'99','4',1,NULL,1479993009,NULL),(17,'106','1',1,NULL,1479997601,NULL);
/*!40000 ALTER TABLE `member_ministries` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `members`
DROP TABLE IF EXISTS `members`;
CREATE TABLE `members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_joined` blob,
  `hbc_id` blob,
  `title` blob NOT NULL,
  `member_code` blob NOT NULL,
  `first_name` blob NOT NULL,
  `last_name` blob NOT NULL,
  `gender` blob NOT NULL,
  `dob` blob,
  `phone1` blob NOT NULL,
  `phone2` blob NOT NULL,
  `email` blob NOT NULL,
  `id_no` blob NOT NULL,
  `country` blob NOT NULL,
  `county` blob NOT NULL,
  `location` blob NOT NULL,
  `address` blob,
  `marital_status` blob NOT NULL,
  `member_status` blob NOT NULL,
  `status` blob NOT NULL,
  `passport` blob NOT NULL,
  `occupation` blob NOT NULL,
  `education_level` blob NOT NULL,
  `employer` blob NOT NULL,
  `how_joined` blob NOT NULL,
  `baptised` blob NOT NULL,
  `confirmed` blob NOT NULL,
  `description` blob,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8;

-- Dumping data for table `members`
LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES (35,0x8a34475aae3c8c4d5775497ebf77cf4c,0xa545acd59a5c75d85e429545b1b87e8a,0xc17f7181ee21c635ac5cf6b98efda0ac,0xdefd2e50bda88296d4d62e8d220a475b,0xe1ba24bb298a44551148d3023ae0f538,0xa585547cfcc3b627a99ea200fbfaf360,0xf68f4736ee0732d51d036bf82f77824c,0x14ed7a5c038284fba27fe7d6c73df31a,0xb4cb80ff24959373797aa51935f4a453,0xa545acd59a5c75d85e429545b1b87e8a,0x8ceaa33d0f5297ce8a51bed899ac0f4020fe5530c98d211d05a417c5575cb7d3,0xa545acd59a5c75d85e429545b1b87e8a,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x0f7311fb267411c79f6b1c04c36292e3,0x71311904b464223f0e3fdd225daf85b0,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x3d32226690d9049de49c689ca46a9f6d,0xd5b48dec692930d9516dbc64455c9b8a,0xd5b48dec692930d9516dbc64455c9b8a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x73e2a64fdd1c0b2a2f2df1db01761918,NULL),(36,0xbf17be78e24bee5af1ae7ac8c5b98015,0xa545acd59a5c75d85e429545b1b87e8a,0x11450daafe9c9d319b69367444d6e356,0x4a759563516f3a5b01f5353fc76884d5,0xccea4ef774b65fbe211d479373973d2c,0x0bb707e523729eb8083726da96006ddb,0xf68f4736ee0732d51d036bf82f77824c,0x4d5dcfba89f3cadeb0caee4dac6ae1ea,0x8dd23ff19a155d9cdb5d36e769626dcc,0xa545acd59a5c75d85e429545b1b87e8a,0x61f861538452a7c65f070d2adf20a8dea3f9b6b4b811d8808669adcb8260aee6,0x9ff4f9998660a907b60266b72d9f9c91,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x71311904b464223f0e3fdd225daf85b0,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x00c8e042cd1c0a4212cdbd17dcadd7b9,NULL),(37,0x7cba6416b1f338dc67f1b7b315a1c4cc,0xa545acd59a5c75d85e429545b1b87e8a,0x11450daafe9c9d319b69367444d6e356,0x7d29fe89df146278d775fe9614b15268,0x22886686b0a940c46deda51721fe6f0f,0xdf1d21e09b96e2bcbc0f454e188dfadd,0xf68f4736ee0732d51d036bf82f77824c,0xd23573da80f4373b9fc6d4448aa84b6c,0xd9c5399596603d229f52caa78375aa89,0xa545acd59a5c75d85e429545b1b87e8a,0x27bcb63a6be7610dd5d1cec29f3405a92c54c489f210322c3764b299f161adcf,0x38cdb03a3e6c6d9895668b40dd117da4,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x3fa1b09a489bef722f361794f632d178ac0606cc2ae1412bb41b9a2d6d9486bd,0xb24f4ea3e531550bb847abad670f05e4,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x18acc152098628795874002065915de4,NULL),(38,0xaffd6557b15ee1b97098f1a23cb782bb,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0xa5eca2268b2936a2f40d1ef5289aabb6,0x80b1aa155eb442379b3adae924698db8,0x2610f5f3e304fef75bfbd4088247c328c33b91b6f83d3b97a58caf020aa40838,0xc0e427adbbef8f701a2ed487e9ed94e6,0xf0b22f5a27d7a4264afcab7551ad05b8,0xdd2a9f88262333aeda32781e0d646c78,0xa545acd59a5c75d85e429545b1b87e8a,0x915c691316014788d6dbdd021085d6622c54c489f210322c3764b299f161adcf,0xc0682d5169f56a760d3265e1588ff9ed,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x78c3d0e6b29fdaca18cf529562531e86,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x3f3faa8bcb9b2ef3023085510fe252c8,NULL),(39,0x569f98bef06a162afc665ef68c8d384d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0x4c9770eac65d2df5ec72b15934890bf6,0x99be85ee2cd14ed49c755007e387b63b,0xdbe917c22a6ad8f593b781808c5bd444,0xf68f4736ee0732d51d036bf82f77824c,0xb2459deeb54d919c1c7de801ea344028,0x0b87fbed1d58fb4c18307cc98989bd73,0xa545acd59a5c75d85e429545b1b87e8a,0x24c71b46fa22e3179b1344fd4b4e901ca3f9b6b4b811d8808669adcb8260aee6,0xd19352ce3bd001991bc577429409e194,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x17128e90ec65e26ded2f68db9ec1a5a8,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa62ae085790bbcdf726707be81863be1,NULL),(40,0x6af1c03ce7159e17303aae3d9fbbb217,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0xe064cb7085b902dffe2b6a30b92e6bef,0x467bcd7fdd299e3709a32cb42c09b215,0xbdd8104671b4bdf4a97f67dda037255b,0xc0e427adbbef8f701a2ed487e9ed94e6,0x836a30d2100d3e075ac74a57e62b85a0,0xb9e2a41726e724bbc382d218fbbb4f85,0xa545acd59a5c75d85e429545b1b87e8a,0xe81cac0acea3cf17d29252c770f1d4c3a3f9b6b4b811d8808669adcb8260aee6,0x8599441f7f8104f9417e64f7bc9385ec,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0x1c4bab466ee5d99888d9d3cb2cc4c464,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x86ca79c5bd97dd76e45b7be009ada854317347392477f2f65b1a33c58e4acf04,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xee5717fd91cd28f4f7d7d6d9191b80ff,NULL),(41,0xda862e01ad5ff850dea7bbe0124f6e08,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0x54a2bd7a2e155c768e0128fc76e15766,0x48f4200437ef173ae39fdd30834d59fc,0xb68ac4002d62a62056804093d14bc526,0xf68f4736ee0732d51d036bf82f77824c,0x836a30d2100d3e075ac74a57e62b85a0,0x6aaa3b8eab31c56ccff86ab483099e12,0xa545acd59a5c75d85e429545b1b87e8a,0xb7b78ef84bfe3cb6e2b2c37ac6c5f101e63525ccbb02adba861c7c0076cda2da,0xcc6ba297c42bedf59608814c2d0eb7cd,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xfb589c20f470006b47949581bf7e7923,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0x1c4bab466ee5d99888d9d3cb2cc4c464,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x804827eb2bfec5fc82cada8a1f545e15,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xc012df985f222ab0c93c9c8da3e7f065,NULL),(42,0xa682991e213e0be0f5e194f6dc8f2319,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9efe82a740c9e77885b3f3bfed9ce10e,0x8a8c4342a647f6ac0d1a158811486de6,0x72b09fdddd14af48354b66a4c465ede1,0xecbb95f9c57f47bb19b048f61c8ee3ef,0xc0e427adbbef8f701a2ed487e9ed94e6,0x038853f0fc81d550f74bd8b4a6f13e8d,0xbf07ca516a178a0ed46717d200bc5364,0xa545acd59a5c75d85e429545b1b87e8a,0x763bff28dd195914bd9523a8a81a89b9a3f9b6b4b811d8808669adcb8260aee6,0x4e6f97354a202763028ea3cda5a6a905,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x2a28c19cb380960d15bea7cf9e960edc,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x474e0ec607ffdddad931bbbef0d420b6,NULL),(43,0x3aa620b69994da65e3ad4124f17e76e0,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9efe82a740c9e77885b3f3bfed9ce10e,0x8f3f34460db374b30eadf0440d375fab,0xde15f267b7a9f1289bd34ba46822cc23,0xd87c968b16772bbacd4821edbe0488d0,0xc0e427adbbef8f701a2ed487e9ed94e6,0x03a96bd392f90d2e78854e8e4ec5938b,0xd112e723bd9ea3e8f269c2ec51ba6b37,0xa545acd59a5c75d85e429545b1b87e8a,0xefa0afe2573aa39ba04a0a79f0052d75a3f9b6b4b811d8808669adcb8260aee6,0xa545acd59a5c75d85e429545b1b87e8a,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xdb038a954c03609fb9877befe686ee74,0xd9abb3be52408c29e2c3f6502305e60f,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x596614cdc0e9ec8723aa4846c79445b9,0xb7942b47f7098d08221e4f00ac5b2798),(44,0xa67fffd51e5382b40551faac167bde69,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0x6507ea4bfd2258226ac18f88d261c418,0x7b32f119cff3709ee574f1234b8a9903,0x316dadb1547c02b55cb14c9403cd10f4,0xf68f4736ee0732d51d036bf82f77824c,0x8c61ba2d6553de450f5a9a5ce0583cd3,0xc45c7b8de24c729a4da03b3cda1877d4,0xa545acd59a5c75d85e429545b1b87e8a,0xb98f4a2222b5705823ed52951c10938b1e0619411b601867bc043ca67b3f2fbc,0x59ecd6b1ec20f64f3bd9d0153e43a2d1,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xccf74558754b82c243deab9200464cfd,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x281e32a6ffcc1125da2826419f441f94,NULL),(45,0xc5941f4a10ad7477984e2caef79e4347,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9efe82a740c9e77885b3f3bfed9ce10e,0xbbaffcecf22673fca3c280fbb7a42fe1,0xf19ea78118502636bc3d27d8322d6688,0x985abe05f2aa0560080b37c231bf28d4,0xc0e427adbbef8f701a2ed487e9ed94e6,0xd379da99ca10455ee0cab4314ce1448e,0x0193791f43af368a003309e47674641d,0x42db4f27a803b872399b4407b3c65110,0x712d24d304d7598bd9e4c0aa09ceff7c1e0619411b601867bc043ca67b3f2fbc,0xf4f303ceae7679d656cae4697aca8002,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x6c5ecdcecaaf3f618050bee1d7b0248829a51e350a7b8ff984675301845bc377,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x2a28c19cb380960d15bea7cf9e960edc,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x9b00a4da8a2bb388e9644f5095ba8fed,NULL),(46,0x6af1c03ce7159e17303aae3d9fbbb217,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0xb33b435fe17c6f311f6866c7f72c2b89,0xde15f267b7a9f1289bd34ba46822cc23,0x8a34d453129cef08f58c69dfcc80538b,0xc0e427adbbef8f701a2ed487e9ed94e6,0x476e171eff5ae6e60e598b2700f18bf4,0x5daf35d49f27eb7e28b0c93d19ebbc4f,0xa545acd59a5c75d85e429545b1b87e8a,0x1d55389e51c3fc39510e9e08fbd843021e0619411b601867bc043ca67b3f2fbc,0xab39f301533c3c9241f7040b35717cc0,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xb3998cb8c671dae7f3df2807c2323d4c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xd5b48dec692930d9516dbc64455c9b8a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xaaa5b753df50c22fdfb34786316b03e7,NULL),(47,0x7faaef8bfe4d557d1ad753291a39e778,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0x2dd6dd9bbe763011354a68bd41b2083a,0x555086a8262028ae1a6adbc5f1c564bb,0xe8931ed9c299179fe4992f2bc9caafb3,0xf68f4736ee0732d51d036bf82f77824c,0xb36fb1e38e31d932f4fc95e55bdb3733,0x92a9f4512b1a390d587025f0c3c19269,0xa545acd59a5c75d85e429545b1b87e8a,0x244bd0f55ee74ab076373c9e6eafe45fdbeff435771f73aa50aed15d12221607,0x0854adc28600c6388abd7d1c57abf818,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x3e237ed10d277124d100b46391bc5552,0x6668e8ed4819ca8a01e479790b1b2364,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x8bc504c1a36beb89845f38f695533258,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa41470d0e1655df483794d32e75c0b86,NULL),(48,0x736b2e8669ff95286121478d326a2249,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9efe82a740c9e77885b3f3bfed9ce10e,0x67eda6b4f46ee332507d96d8c3b42c70,0xe1f7d327ae0ac7a572a7b5e6a8b2c7ce,0x4c9184dedd17b2e90cbc2db910480396,0xc0e427adbbef8f701a2ed487e9ed94e6,0x2b7511536352c657acdbcd2c4dde45ec,0x1aa064c102476253ace5035493b778e1,0xa545acd59a5c75d85e429545b1b87e8a,0x495c6c77bbe4c75c50c2f339d617bdceb0d5958fa1a1ddd37b751e7dd087e326,0x83c50efe1a0ee56d46917d38ce16bf39,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xb3998cb8c671dae7f3df2807c2323d4c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x59d875f028f433ce15b5b7ff48f1766e,NULL),(49,0xadf1b43162a4f943169aee707e188105,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0x656a6a292dcb94e7a6759125aa9dbe61,0xa6dba09eb7d9cca0e2a36fc71d3ea67f,0xf5b1d80d3e2b0f057d9aea38f72678d4,0xf68f4736ee0732d51d036bf82f77824c,0x154ea61b1528f4ed420c13ca77b9a401,0xbf7a0f9900d1a256e057178976561db4,0xa545acd59a5c75d85e429545b1b87e8a,0x13e1284a6d08b0c5f4f0a993ba3e8faea3f9b6b4b811d8808669adcb8260aee6,0xc4adc60fad308ee763d5835c5d216c54,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0x3e486c53b828470be88ef1839c02b9e3,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x934dad13701d93802ecc622798c9fe1a38a8de667bc460188c80a368ce4f1b88,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x51b1cad9f71be0aa67114e182bc92b77,NULL),(50,0xadf1b43162a4f943169aee707e188105,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0xba44a43f8ef0fb173e62c675c05423c5,0xa6dba09eb7d9cca0e2a36fc71d3ea67f,0xf5b1d80d3e2b0f057d9aea38f72678d4,0xf68f4736ee0732d51d036bf82f77824c,0x154ea61b1528f4ed420c13ca77b9a401,0xbf7a0f9900d1a256e057178976561db4,0xa545acd59a5c75d85e429545b1b87e8a,0x13e1284a6d08b0c5f4f0a993ba3e8faea3f9b6b4b811d8808669adcb8260aee6,0xc4adc60fad308ee763d5835c5d216c54,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0x3e486c53b828470be88ef1839c02b9e3,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x934dad13701d93802ecc622798c9fe1a38a8de667bc460188c80a368ce4f1b88,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x6a80f52772e9727c98c2b73741a0513e,NULL),(51,0x7115db7f28f143783be1417a59e4c9e8,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9efe82a740c9e77885b3f3bfed9ce10e,0x2788efe856c25631387339930795d19b,0x9fb73d4b6bb5ada4fe47de01c1aab01e,0x1fd56cefa72a96b7f7bbf83aef6b7749,0xf68f4736ee0732d51d036bf82f77824c,0x2fe1145321c00248499e4e90dcc9c0af,0x175c4aedec15f130b7bed5a6f2a1574e,0xa545acd59a5c75d85e429545b1b87e8a,0xfeba1d1f1fd1a9db1f465c286f92a77bdbeff435771f73aa50aed15d12221607,0x8b211afe48407ea0e6a9aa8e56f3939c,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x2a28c19cb380960d15bea7cf9e960edc,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x3eb44b3b824c7723e9895855748fc7a3,NULL),(52,0x736b2e8669ff95286121478d326a2249,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9efe82a740c9e77885b3f3bfed9ce10e,0xaa56ca7100e82251eb877483f65e110b,0x2e41d6c582685d826939b78f18d4c0cb,0xde6f4dc629f2ef1c1ad1afdcdd805646,0xc0e427adbbef8f701a2ed487e9ed94e6,0x111cc3d1380dbf16d64c9d3abfb86027,0x04eebe2c268c1ec9e1f40a738f26a121,0xa545acd59a5c75d85e429545b1b87e8a,0xd9d48717a995d202c63bc691535c8264825f710852daa07035b86c2258a26052,0xe091cf5a851b903e2567ed524897ba74,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x2a28c19cb380960d15bea7cf9e960edc,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xfe83606dbbe76b0c5d8f6258e2eb559d,NULL),(53,0x52fa920f907c47a9192ad327f1858bd4,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0x0cae721d209b1e48d0265abdf37c5909,0x4823f33e5a2ce376bc3d019410398819,0xd8d484c4ca2bff61cc8393b3374b84f3,0xf68f4736ee0732d51d036bf82f77824c,0xb98a1d5097ac2720d5f76d567d516cd7,0x0931d1b747140979b710f61f1a952669,0xa545acd59a5c75d85e429545b1b87e8a,0x40102f40b07f5cb1af9f25acd452c0c41e0619411b601867bc043ca67b3f2fbc,0x6b3c7babd3ba75ea44d4d600f7ec19a8,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x4d6e32b9ba8af019b98357297f4fc0d0,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x5923abf8b56d16efd48e79916ce91a0e,NULL),(54,0xc149e5515ed059b0b33845f5b4618157,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9efe82a740c9e77885b3f3bfed9ce10e,0xe1f48941752a57e4c2902ec21e655c10,0x93710cd6c7c51a2fd4cc15be14cb50c3,0x1987783310fd66b732c543a4d2fc6f11,0xc0e427adbbef8f701a2ed487e9ed94e6,0x8714c8812b0e9e92da5430ebf754e2f3,0x23d404a58561c48ced30978edc0b81b0,0xa545acd59a5c75d85e429545b1b87e8a,0x918ce15f91b9052e522a18a59e7a1ccfa3f9b6b4b811d8808669adcb8260aee6,0xa58454b7d0539abf3561e6dc6d33ef22,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xccf74558754b82c243deab9200464cfd,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xfd3f3a7e94a9075e272fd4b6e3ed6c900f5c29add856eda25c204fb7373e0b9a,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x0a147cf67650a0b2ca3a2fc00141c443,NULL),(55,0x8596015006e8875684d460ea1ae0fee8,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0x3e1d663d8254e897e80a5932060bffb3,0x36b0434c930872ab4008ed33e28113ab,0x587b78406ae643eeebcdb110316495b3,0xc0e427adbbef8f701a2ed487e9ed94e6,0xd09d1ac8e2b25f0521679d467d888e89,0xed6468aaff5ae5f0e55c686bf9dbcb3c,0xa545acd59a5c75d85e429545b1b87e8a,0xe5d58adb27540be9d419f018d107b87edbeff435771f73aa50aed15d12221607,0xe1fc2c5859d9530ad0062da1f01ec516,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x2a28c19cb380960d15bea7cf9e960edc,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x9d25d1ebf94dc640a2d4a1ae1b1f895c,NULL),(56,0xc84c0dc3035b3e738a1c7338ce174c9b,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0xa8acdfdfffd37f28b3ae926a4abec998,0xfe0c330d47ec267896d7789a5596a92d,0x64070b83371a16ecee6c674a6cbd60d8,0xf68f4736ee0732d51d036bf82f77824c,0x6f2a916b9e9b19512059ad31702ceef5,0xfa7f644e4329c80bb78b9da9c9e2ad21,0xa545acd59a5c75d85e429545b1b87e8a,0x5321c3afd2847a2fa2e121d62c0217afef9d08250806a3663d567bc998ece4b3,0x4c917a25c908f05f17d88233a89eb85f,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x17128e90ec65e26ded2f68db9ec1a5a8,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x4a54adbbe027038370c9fd4aca4f5ea4,NULL),(57,0x93a752b723bf93324b51d8d1f7671509,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9efe82a740c9e77885b3f3bfed9ce10e,0x03a7a6df41dac3c966350f31f0c77091,0xb6d1fe58d4bbf96f1f81c012eb3090ec,0xf2aa00389890832ac96e3d684876da88,0xc0e427adbbef8f701a2ed487e9ed94e6,0x82f2767ce1aaa98146755eba799ea707,0xe049225cfc1acf1121ee8b7f4a648690,0xa545acd59a5c75d85e429545b1b87e8a,0xd21f06d21bcf54410816dacb6e852b7979d15507a4b149505d797b725df3a584,0xd21c1dd73b3b39111bd2e02af2843e33,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x6668e8ed4819ca8a01e479790b1b2364,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x2a28c19cb380960d15bea7cf9e960edc,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xca524393eb0cf93471c212b0f436cf9d,NULL),(58,0xadebeb3d40f0d96d7acca710fa4b4964,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0xf609f25cdedaf303a01fe222c8925fa0,0x13ca557ff7377e09c778aa78b9d4de36,0xd3a7d88807088a07d097e9a1a8779fb5,0xf68f4736ee0732d51d036bf82f77824c,0x5c48264595c629df8b89bb882964098a,0x1e7b483b2cf7392ea9586056ae60978c,0xd9360199a16b7a82b41cf48ed51077f8,0xe4530d46a718e5a5fc537c30904c777520fe5530c98d211d05a417c5575cb7d3,0x0748019d5cbf1954183cb92be7ccd72b,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa8ca0dc055ca68aa619c2ea38796f46bc1c0cde1420f4185a23de5593f6880569c8a14c63cb8ed847170acc855d2c0c3,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xce0b712e11a7a4825897bd8565991af7,NULL),(59,0x3be3fb2a434b1f162f1455a4223a48c7,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9efe82a740c9e77885b3f3bfed9ce10e,0x63d9119704d432e827357cd7b1f301d6,0x2e41d6c582685d826939b78f18d4c0cb,0x8ff8e588bb6a39b67013c5f9cd37e116,0xc0e427adbbef8f701a2ed487e9ed94e6,0xe578bf7d2d12693e054ff0a522377af7,0x5209d71a397893b40899905525712c46,0xa545acd59a5c75d85e429545b1b87e8a,0x2f021df099fd30275843122635ea65b6a941df701b0aed6ac43ff6ab5ccfe9d1,0x29a503ee6615643677761c80e0ccea4b,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x74b70b3d2ed441896e94535d0b22efd2,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x2a28c19cb380960d15bea7cf9e960edc,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x80cf608cdbee7435303df96f68b07e0f,NULL),(60,0x9ec4d1dbee1774c58466fa2e7a4a76ab,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xc17f7181ee21c635ac5cf6b98efda0ac,0xa9b55341036b8f9e366468a687e76532,0x0f5ec575c2ceb124b1864e17b9b62727,0xc80ccf72301866d5b35c252b54112609,0xf68f4736ee0732d51d036bf82f77824c,0xbbd2dd0cada0eafe603811f538baf0c7,0x9b53c1c5135d17d995d0f7f05b83ed1c,0xa545acd59a5c75d85e429545b1b87e8a,0xecc34e640ece820b612c1a5bf0254626b0d5958fa1a1ddd37b751e7dd087e326,0xa545acd59a5c75d85e429545b1b87e8a,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa2a22067fc79e9bf4d6b580dcab7222a,NULL),(61,0x736b2e8669ff95286121478d326a2249,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9efe82a740c9e77885b3f3bfed9ce10e,0x3919d7d5eb956c75b8aa9d1b33953901,0xb6d1fe58d4bbf96f1f81c012eb3090ec,0xf91abc3fba8ae940a17b651a28b86dac,0xc0e427adbbef8f701a2ed487e9ed94e6,0x0a9cd3b344841ed071aafa8ebb948058,0xd39cc8719bdb28a9ee6ed89482d5c8bd,0xa545acd59a5c75d85e429545b1b87e8a,0x9725b9818b37cccb0d5a8e1a82219594a3f9b6b4b811d8808669adcb8260aee6,0x844884ca6eabc73ebf1dc95f1b21fdd0,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xad7bae21d8f6036d155361b1d2a5c78e,NULL),(62,0xece4f5c8ea2f11773e819c1b4804f535,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9efe82a740c9e77885b3f3bfed9ce10e,0x9aea684ea0726063abae301fad508c2b,0x2aeefa31190b57675b50ae19e03acf10,0xb55aac27ca7906c207c09798cb78fc12,0xc0e427adbbef8f701a2ed487e9ed94e6,0xcf0604078dca205c3da6bf66598d90b8,0x2e702bdfe82080358fda17fae639392c,0xa545acd59a5c75d85e429545b1b87e8a,0x9e5f0cc4b6ca524291c550adcdfe08eda3f9b6b4b811d8808669adcb8260aee6,0x01af4d03d4da534182dfbabced1450ac,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xb3998cb8c671dae7f3df2807c2323d4c,0xeb63a5a803e61865cd9e3fde6daa2612,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xf81b53fbd3688e768566d16bafb954d4,NULL),(63,0x987d80fb3a03902df0eeaed7e4e03c9a,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9efe82a740c9e77885b3f3bfed9ce10e,0xc581ddf0352b71c5fee5826834ff7542,0xde15f267b7a9f1289bd34ba46822cc23,0x702a9852cc68b9d4e4fee0dfb1bb4e4f,0xc0e427adbbef8f701a2ed487e9ed94e6,0xbccd046cb8bb69e7bd790515db1330ac,0xfa7978b3ec5bc45ad01621b5e73fad4e,0xa545acd59a5c75d85e429545b1b87e8a,0x9370efa6e63667f560a281c4d80619cd20ff032b6ec76a8539cf789ed83b36c8,0x5cf4cdffdb678df7e31e9b7b79930d77,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xd1e26cbe43de9c3cceaa8770499acd59,NULL),(64,0x5b0396e874ec6040375b30b77f3f64ed,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9efe82a740c9e77885b3f3bfed9ce10e,0x1f8a6c181d2f684822c8a35190421054,0xb02f012f2dc7309c8288312024b32478,0x520d22e7db170c4a1091f72ca188ebc9,0xc0e427adbbef8f701a2ed487e9ed94e6,0xa2473d8229315078730460218cd10b2d,0xb2269626fe9760a2e5e1d8881e5e762f,0xa545acd59a5c75d85e429545b1b87e8a,0xde62b8dba304a476e0d41871929766f3a941df701b0aed6ac43ff6ab5ccfe9d1,0xa545acd59a5c75d85e429545b1b87e8a,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x3e237ed10d277124d100b46391bc5552,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xeb989d28296e58d8be1110bddf50f725,NULL),(65,0x154b8f269894c4610c1b7670b9ca096d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9efe82a740c9e77885b3f3bfed9ce10e,0xc731ad1ac6c43c4f3f9188144c11b115,0xec4bd9355db3c6d5be752d61e42e0f28,0xd582fed1f393c1378665542440520948,0xc0e427adbbef8f701a2ed487e9ed94e6,0xb7824f3b0ddda398dfe5c420d6689285,0xfa1486433c63862054534d8cc8a35a8c,0xa545acd59a5c75d85e429545b1b87e8a,0xd41ea11cf49253fedfeed4bf12d59688dbeff435771f73aa50aed15d12221607,0x1c2205d4efc0c850918fd3a1ac789507,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x490786da612e89e0ccfe6f4a7a470a10,NULL),(66,0x45a947d5c525c00fa8640d2a5f9e62af,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9efe82a740c9e77885b3f3bfed9ce10e,0xf7f7775ef8974c8b1bdc3a37c1112c2e,0x990749133266b1a9eb59415dfd6a5b6a,0x526508645e20e7eb23d4b8943bd18ba9,0xc0e427adbbef8f701a2ed487e9ed94e6,0xa2473d8229315078730460218cd10b2d,0x0b99366fa293dc3c6b37557221fbe11a,0xa545acd59a5c75d85e429545b1b87e8a,0x376d6e9447760329ae871cb9c0946fa5ef9d08250806a3663d567bc998ece4b3,0xe62d174f46e41325aa10c4cdbfecec20,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xa609bb9051f253e7c1c690dd3ac9e967,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x400b514b6f1a1c5a3d1c96318a51451c,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x83f6a0d551b6cc5f18f66d1b308bc6a9,NULL),(67,0x28f7fc2bd9600806a7bba09544e2ca86,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9efe82a740c9e77885b3f3bfed9ce10e,0x301b7d53b79b766c40e09747d3cd14eb,0xa5b4a3914496779bd65215efd4bc59dd,0xba6ca79ac4e7ea5466d80b744d9e1bfa,0xc0e427adbbef8f701a2ed487e9ed94e6,0x28f7fc2bd9600806a7bba09544e2ca86,0xf0fe29bcce5e4c57c10898a55d9ab547,0xa545acd59a5c75d85e429545b1b87e8a,0x8526f590664bc76797e45e889630bf14dbeff435771f73aa50aed15d12221607,0xa545acd59a5c75d85e429545b1b87e8a,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xb3998cb8c671dae7f3df2807c2323d4c,0x63073220b2fe03ecb31d6d7ebead3c48,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x798ade8f116cdd93e8e72121a9c5e605,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xd4ed7b89996d373c473a8e75c84e6adf,NULL),(68,0xd0cefeebaa4165fe17f460bcbd7a947b,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9efe82a740c9e77885b3f3bfed9ce10e,0x4f9c6785a4a79892c8118ab8f63ac5d0,0x17b815557b09d1d966b05ab4ee6d8c3a,0x350737412bcf946889b9759a35dce59e,0xc0e427adbbef8f701a2ed487e9ed94e6,0x118c79a8b75b06cfc5cd4045af9a2f06,0x7178e3f46f04e7b945b55ad03edc5c40,0xa545acd59a5c75d85e429545b1b87e8a,0xa2de133dcbac2bcd5d97f3b585129751ef9d08250806a3663d567bc998ece4b3,0x2f7426164de394634a1d539b0b28a1cb,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x8a49a87b58250cd21053a9a2973a46a8,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xf499aa7e158e0ce07554c6b06821e9de,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xb7e0a6e0060298e8d8d5f91464073077,NULL),(69,0x154b8f269894c4610c1b7670b9ca096d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9efe82a740c9e77885b3f3bfed9ce10e,0x7824d52cff717f7c39996e9462c7de85,0xc5ab631561d46e635a4fe259aebf1f28a545acd59a5c75d85e429545b1b87e8a,0xf5b1d80d3e2b0f057d9aea38f72678d4,0xc0e427adbbef8f701a2ed487e9ed94e6,0x154b8f269894c4610c1b7670b9ca096d,0x3ff278f503ea062e08bb1e59ea9f5e07,0xa545acd59a5c75d85e429545b1b87e8a,0x4ee2d9dbf2e7616143745228d4a36709dbeff435771f73aa50aed15d12221607,0x8cf52321c8a8a4dff1d6d83ee5e1bb8f,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xa2cbe5dfb60db4199ddd737a3a0337ce,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x2a28c19cb380960d15bea7cf9e960edc,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x5fc11c0e999bb5e2cb4af303cd9e2dfe,NULL),(70,0xece4f5c8ea2f11773e819c1b4804f535,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0x1c1e42f18b9750ac1f336e956d7cebe4,0x5c74887e8e522ca52b4e7d15330475db,0x6ecc2dcf53ba9dfcd5b251dc5b013da2,0xc0e427adbbef8f701a2ed487e9ed94e6,0xfb2ce8572970bfb41e4c8db85b3e0b08,0x356614929dfe1e2ea9b796b1e72bdc05,0xa545acd59a5c75d85e429545b1b87e8a,0x687b029c3d99b237565bf7b2f6639fd9a3f9b6b4b811d8808669adcb8260aee6,0xbf6fc1e5dcd9041f2504e1be08ae4f01,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xccf74558754b82c243deab9200464cfd,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xd326c354e5bdaffd88ba4bc466cca007,NULL),(71,0x07c0f48e1dbb91de94ca6f0707611433,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0x1e29b1617bc06c84a390a463985c1477,0x2f0779608187080ac9b60a97fc1022a1,0x362fddb3592cbb190f5ec34ad0d43738,0xf68f4736ee0732d51d036bf82f77824c,0xa2473d8229315078730460218cd10b2d,0x5789b3b114d49f2e9a59eb1a8ba15930,0xa545acd59a5c75d85e429545b1b87e8a,0x55089db547755f0f526991a2e6d9f4e9a941df701b0aed6ac43ff6ab5ccfe9d1,0xf0aec85c30c8a90468ffcd831d1516a0,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x8a49a87b58250cd21053a9a2973a46a8,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x2a28c19cb380960d15bea7cf9e960edc,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x4a9efeb9e601431a1fd291ba1ec909d7,NULL),(72,0x246dddf4c88865bd53f070e5b29d2f2f,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0x05c882940f1bebc27e8a35297039b95b,0x06cdfbb7e94a24bbf33d1c0ad1def0ee,0x0693a2d749d8735730c525beddc7b688,0xc0e427adbbef8f701a2ed487e9ed94e6,0x246dddf4c88865bd53f070e5b29d2f2f,0x45c011a470554749abf92350fe38d931,0xa545acd59a5c75d85e429545b1b87e8a,0x0f4572debd92594701122642fbf0b1f4eec1cd4a538b25030bb0b3aa4e1cba03,0x09bf053b928d93b0f1bf2ae13b1dcde7,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xb3998cb8c671dae7f3df2807c2323d4c,0x6668e8ed4819ca8a01e479790b1b2364,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x2a28c19cb380960d15bea7cf9e960edc,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x749f0b938c7b3c37f89e70adae21681b,NULL),(73,0xa67fffd51e5382b40551faac167bde69,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0xad47d731055069a521939fb679a6b287,0x51788f7255cc8b0a55ea40c3ed0d39a4,0x4123dd7c488037d891a3c08d1952b0d8,0xf68f4736ee0732d51d036bf82f77824c,0x1013b15eb2a0419366a47f63aa6fa591,0xad710b933f4187778803acd22a8466f0,0xa545acd59a5c75d85e429545b1b87e8a,0xf6434b577e687e04d2a28fdb5e2b2a1320ff032b6ec76a8539cf789ed83b36c8,0xa545acd59a5c75d85e429545b1b87e8a,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0xe9626359cc1cb53bce011cab6201a04a59af27f6fca95501c426e61e2925b37b,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xe8e060c02ab4989b1feec7e269980598,0xb2466c1699eb2405e1886947a7aaf808),(74,0x246dddf4c88865bd53f070e5b29d2f2f,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0x6155dbb4e6c9ef760d55b221983ec82d,0x7de479e528d365329f750a8155569029,0x9a9994cd7dc3520ed85c17673af4d3fc,0xc0e427adbbef8f701a2ed487e9ed94e6,0x69f5cdde9a919157e3e387e091d55d60,0xd9963fdacaccba5b9cc84436b5ab7af8,0xa545acd59a5c75d85e429545b1b87e8a,0xa7ba30780154087f55dba756be7749b520ff032b6ec76a8539cf789ed83b36c8,0x9b3bb723b068838e0804ec3598d8af02,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xa2cbe5dfb60db4199ddd737a3a0337ce,0x579148c22fe73cbc08659304ef580e92,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x69a7bc937effa47056c972dfe16deb45,NULL),(75,0xa74e6b38c60dd7195b469306f29fe3b5,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0xfc93a1bf2cf0f647b65706792e2efbe4,0x3b2a94ffc44a91f2b5b819e4b6eba724,0xf2061325b95cdf3872eca9c84c45f1bd,0xc0e427adbbef8f701a2ed487e9ed94e6,0x8bbc453ad67b74f906631f0004a93539,0xc6d3d40f0f532c502e34c60ec141f1f4,0xa545acd59a5c75d85e429545b1b87e8a,0xb8c131b668eff69010721f19e9bae88879d15507a4b149505d797b725df3a584,0x445b62d9fc1ce5dd1e0ec43dff1f0ebf,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xb3998cb8c671dae7f3df2807c2323d4c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xf401289b38ea47571686b6b6b41d027a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x9bfd8ddcde63ef268379e8536b9528e6,NULL),(76,0x57c3c213215902f82df4437d08a9836e,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0x99111766246f009d859bf346bb14261c,0x54a182816b170181ac4a7a6b1049f9c7,0x34b5bce8e6fc6ec94fa906b4d5eb34ee,0xf68f4736ee0732d51d036bf82f77824c,0x32336ec25be70270996c2fdfa3fda93a,0x9917dff17c7eaeebb7a5de143b105495,0xa545acd59a5c75d85e429545b1b87e8a,0x65d60616230d131afa104b88944df5758e17f4c87e67c09fdb0e85c896bf1c94,0x857476a7918068c8416720f7625614f0,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x12f651f954dfa04fdc93ffb8489563f31c2880937405951e98bea5968d3a848b,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xccf74558754b82c243deab9200464cfd,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x38ed4b4a61d389d8cd53e5cd19f3a41d,NULL),(77,0xa67fffd51e5382b40551faac167bde69,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xc17f7181ee21c635ac5cf6b98efda0ac,0x84efc91ddb4f79b819727f110c897cb8,0xe547115b569f2c8ab10ddc6db08a02c7,0x7566be4a1fcd98cf268b927665f4d904,0xc0e427adbbef8f701a2ed487e9ed94e6,0x3965375f9701b89ca61d8afbeff52a79,0xb220b6cccfaf45328b5cb1437e653733,0xa545acd59a5c75d85e429545b1b87e8a,0x114aba46eec1a89f74510b74ee66df2be63525ccbb02adba861c7c0076cda2da,0x1a07043a409e07ed3feb5baa65f316f1,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0xa5bcf31cc0c6b030db971f5643b6fd6b,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xccf74558754b82c243deab9200464cfd,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x34c5812ab9bfc13b59519658f7011670,NULL),(78,0xa74e6b38c60dd7195b469306f29fe3b5,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0x65c279d2b379aee1c589d949e542b70a,0xd74c6f33ade3a0cd753c5bfc3efaf43f,0xd9f2b1da7a7a12e073d0f17a0f6e3544,0xf68f4736ee0732d51d036bf82f77824c,0x3ccc16b8345f5233e3ba98201fa2d158,0xce888143f3b97cdd07e4b39157c283f8,0xa545acd59a5c75d85e429545b1b87e8a,0x09ee945b32f8d7f479acf4c2127bf41fa3f9b6b4b811d8808669adcb8260aee6,0xca4217001d2e68ab0b6f083fdb5d0f2d,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x03fca37633820e1a00b3167e73c7915d,NULL),(79,0x246dddf4c88865bd53f070e5b29d2f2f,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0x4a31b6a7857cbddac2d4c4987b35e68c,0xaa965f9be9b906ce367ac603c6c24876,0xde6f4dc629f2ef1c1ad1afdcdd805646,0xc0e427adbbef8f701a2ed487e9ed94e6,0x0a9cd3b344841ed071aafa8ebb948058,0x67369629507c3697cebf8984e78f9b5d,0xa545acd59a5c75d85e429545b1b87e8a,0x2bda9b9dbe414435783c5c3dc4761fd8b0d5958fa1a1ddd37b751e7dd087e326,0x3017dd3ad386e3fa7fb99a71a3d5bad7,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x0cb740cd71b1266f4498d1c04dbbefc5,0x3b78ffa54e3b002166ab41fcba9bc704,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xddc6cfce7c0d258b9647bdf136ef8aa5,NULL),(80,0x246dddf4c88865bd53f070e5b29d2f2f,0x90065fe9ea51973a4989393c1f3a44af,0x69b40c77e26ea173d2df5b8ab08cfe75,0x21e78bb1893dcb33ce930c3edc37d156,0x6c01ebc76df7e8cf2822e1f9eee7d136,0x3059a9ea6ef3e00246913223e3ae7291,0xc0e427adbbef8f701a2ed487e9ed94e6,0xc32d5964ba871aaf4a718063c56d9e9f,0x7d4f8a7751f129809253d2bc9131a562,0xa545acd59a5c75d85e429545b1b87e8a,0x83faa7cbdb30c04438862c5e77695b89e63525ccbb02adba861c7c0076cda2da,0xa545acd59a5c75d85e429545b1b87e8a,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x7bee4cdeb279fd375ce93d1cd35d5c52,0x6668e8ed4819ca8a01e479790b1b2364,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x86284c3bd2c2250046316f76e67034a7,0x488dfadce0355aa3c035ec0ef85d8cc2),(81,0x246dddf4c88865bd53f070e5b29d2f2f,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0xe93c44e270f79cd6e5d8a3cfd055ebf6,0x444df15c42becf11ee81a6f5b8aff2a1,0x1d0e61cf4097851ac369fc6d42b3aecd,0xf68f4736ee0732d51d036bf82f77824c,0xd7fe820aebd7f55995e2e89b4cc0c4d8,0x1334db76504e1e2e4a01951c29aa26f4,0xa545acd59a5c75d85e429545b1b87e8a,0xec9a5b7af07ba2c49074b0f0afc0ccdedbeff435771f73aa50aed15d12221607,0x54bd29f6966609a9c6f262bb85c58d14,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xa2cbe5dfb60db4199ddd737a3a0337ce,0x2db8dc46f201b4266cfeac2982a75b95,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x5d02143bed69f820fb3abb41fb3b456b,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x0e3198d14efdf0e94668f4d5fd7d2e2a,NULL),(82,0xde6b7ed7c81f2c7296249c2f30ba8154,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0xa5eeecb1509c231f1ec3b2fb212be281,0x3499150f5ec363ed68a14b48a7dcce69,0x05e2446ed638b370029372b162b22525,0xc0e427adbbef8f701a2ed487e9ed94e6,0x1a6a9fcca871e0195f9e54b08155c3d7,0xb3f8478514142e15e96c29f1a6c0a1ca,0xa545acd59a5c75d85e429545b1b87e8a,0x2c4579ef5e0c58431307979fb0a0674720ff032b6ec76a8539cf789ed83b36c8,0x0d6675626084d32721d354e1ac950107,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x5d1a3a66df9a423846826a930a89283e,0x47e3948553fab2c8136daf63daab657d1c2880937405951e98bea5968d3a848b,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x3fd8344b97aa8c70dadca701f1b5859f,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x0c66063b2cb922c5aab856453921e43c,NULL),(83,0xf2a9c3049b4eae095c4f70789df42504,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0xee016a64241a785c33478181b19ab282,0xbd47e9434eb9f7cdc8364f71ab0ecd45,0x42ae915031600a33e5c5e569f7beec8c,0xf68f4736ee0732d51d036bf82f77824c,0x246dddf4c88865bd53f070e5b29d2f2f,0xd5823d3215187a1832579ce4a59d4f32,0xa545acd59a5c75d85e429545b1b87e8a,0xeb2052b6251771bc0580dcec93d8ec8120ff032b6ec76a8539cf789ed83b36c8,0x589b70f3f37ed6232435c1edff2c63eb,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x2db8dc46f201b4266cfeac2982a75b95,0xa545acd59a5c75d85e429545b1b87e8a,0x8350a365576c6ea8fe9547d83d1b65b7,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x17128e90ec65e26ded2f68db9ec1a5a8,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa39435a85b3f4b32983e24838e8a61e3,NULL),(84,0x246dddf4c88865bd53f070e5b29d2f2f,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0x524efddeea6d5e8b607443835037fe93,0xa5b4a3914496779bd65215efd4bc59dd,0x34bbc55f171b771dbd074f963a00d4d0,0xc0e427adbbef8f701a2ed487e9ed94e6,0x2a20e2e085e0b0b3163fec9ca96a53ed,0x1039701164bc864a12effd486d47faea,0xa545acd59a5c75d85e429545b1b87e8a,0x8639ec84780b11c6899ee0946b00589820ff032b6ec76a8539cf789ed83b36c8,0x561eb82651a853c1642ed2b5b17c01dc,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0xa5bcf31cc0c6b030db971f5643b6fd6b,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x3fd8344b97aa8c70dadca701f1b5859f,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x43818029b6efc62f15d05895e8cd7444,NULL),(85,0xfccdfc0cc20c7232eb2dc2d355081db6,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0x1309943d078fa6ce911cf136b1c9c662,0xa4082551f45dd3de50bf09922e741414,0x43ce848d55a6d4ea248bba1948a7755d,0xf68f4736ee0732d51d036bf82f77824c,0x99c348c673306014001b06ccfa51772c,0xc341ee70525cd6fdb1a0494d3cc2a8fb,0xa545acd59a5c75d85e429545b1b87e8a,0x4ae2eb3235090ae02d4ce6d809ced988a3f9b6b4b811d8808669adcb8260aee6,0x6f80d4b87ac676a0ec535b144a12a7da,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x2f40fb2b7f25c2cff63b5f1f04a5cb6f,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x17128e90ec65e26ded2f68db9ec1a5a8,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x0c66887656f3b8ef65e573f0efeb2281,NULL),(86,0x246dddf4c88865bd53f070e5b29d2f2f,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0xcf323d4e0ae64c29c41250e42db97431,0xdbf6330fcc61d61b590be92e3f936b02,0xedc1e23d2050be66e379528edc8d71a7,0xc0e427adbbef8f701a2ed487e9ed94e6,0x220aeb2b1eead3bf955878b9894ff9aa,0x122b791fdbb653041c6382c1f0fa127a,0xa545acd59a5c75d85e429545b1b87e8a,0x748dfd87646fa4c1aeba0b3381e64d2da3f9b6b4b811d8808669adcb8260aee6,0x7b3870686dc5edcba8c64bbe01c3c82e,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xb3998cb8c671dae7f3df2807c2323d4c,0x6493a69bc78f4bcd9078ad3f030fec3da545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x76e84e5a34ab1bcbf6d9d6254cc70954,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x6f01dde95130e8a6cd2219ebbde688f5,NULL),(87,0x32734063f8c724195b70616dab32d960,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0x13c6486199bf09a678b4b8d48eb0316c,0x38b187a1af781a20d41f270215ca865e,0x69ccf823a6894eb990e786bfc9d6453c,0xf68f4736ee0732d51d036bf82f77824c,0x13f56d3c3f1f1352af607c253b86d0a6,0xa4d0c8b761b20a62d1e753e7a667fad5,0xa545acd59a5c75d85e429545b1b87e8a,0xb0b8e012b2023a0d48f14502c1483780dbeff435771f73aa50aed15d12221607,0x3e92f839e7eee5d2318e383383b81c1c,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x7bee4cdeb279fd375ce93d1cd35d5c52,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xb6cd3ddbe82a588164053670b0438fd0,NULL),(88,0x45a947d5c525c00fa8640d2a5f9e62af,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0x1823492d3f03050f621183cd7c1513fd,0x444df15c42becf11ee81a6f5b8aff2a1,0x5a4df593afd8c6cee5a799ea545cf87d,0xc0e427adbbef8f701a2ed487e9ed94e6,0xa2473d8229315078730460218cd10b2d,0x4653e933e06e182aa1823a7b27bfae3b,0xa545acd59a5c75d85e429545b1b87e8a,0x52ecf6df9f7828272d318052be43d43fb0d5958fa1a1ddd37b751e7dd087e326,0xbca4d14e97fb215fd2c772ef67538110,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0xc52cb0410f5a1d06cf287b8da8b95502a545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x19f8e2ae69ef848664d356f0f65acbfc,NULL),(89,0x871dfa35a9709284f2cd1567e772a206,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9efe82a740c9e77885b3f3bfed9ce10e,0xfd474f155705555a9d33079cfc3752cf,0xc26377fce88129ed3791412c501913db,0x0bb707e523729eb8083726da96006ddb,0xc0e427adbbef8f701a2ed487e9ed94e6,0x28659fa026c1942555f6db35b1144533,0x0be1f816b5eef078ee7f297a09630611,0xa545acd59a5c75d85e429545b1b87e8a,0xe86c82a0e3d7a1bdc45c42421fb604afb0d5958fa1a1ddd37b751e7dd087e326,0xb9ec06be111fe32feda9e181163a2987,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x2a28c19cb380960d15bea7cf9e960edc,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x1290969a2f4a6341247aa2220850dd0e,NULL),(90,0x0aa59f3bd38b88480f4223513b69e94e,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0xad3a5f28eb90214e82c1df50516014da,0xeccd2a5cb570a241ab8da5199cc8b6e4,0xb54365646b138c8acfb57e92af1e515b,0xc0e427adbbef8f701a2ed487e9ed94e6,0x72730dd34297b0d11bbfd3da485d1aae,0xc18dd0c0f8e46515dd5065339d984327,0xa545acd59a5c75d85e429545b1b87e8a,0xd3f644393c4d5b9c16aee04118db9e28b0d5958fa1a1ddd37b751e7dd087e326,0x20a7ab18d10fd0ecd11424dbc43fb666,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x8a49a87b58250cd21053a9a2973a46a8,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xabe87a549bceeb435bf97ddd67d7f0ce,NULL),(91,0xbd1695896b1164d5a1ff4a64227e4400,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0x8ae6339f84d1420e8c6a3440f4392cd3,0xd43a8c343a6a656f225276c053e4a743,0xb3cd42c7239cf810d1fdcf089f229cbe,0xf68f4736ee0732d51d036bf82f77824c,0x50d0c7f5e98c6adefd36d937362c582b,0xd8bd796d6f870029e73e8a39b79693bc,0xa545acd59a5c75d85e429545b1b87e8a,0x4f398803713482bf9eff8f163f87ab29a941df701b0aed6ac43ff6ab5ccfe9d1,0x04aeb63c7855a40a89696711b2015218,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xb3998cb8c671dae7f3df2807c2323d4c,0x7ba9617ca262decd49ce7d72d1d2228959af27f6fca95501c426e61e2925b37b,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xaf098c607c1f5fb1f5ac0bb87518bd6249b728f963dea34adbcb67bf42af070f,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xd704a2f7a65f74ad24723c27ff8eac12,NULL),(92,0x10e8282f2b4aa5fd975fb6b286498dfa,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0xf4b51928fa6cf34e5da67b8ab59daa29,0x8b664fcd74fa440d0af6ee4475b42a51,0x1860b6344eaaee680bfe8237bafa900e,0xc0e427adbbef8f701a2ed487e9ed94e6,0x0bef095bfdab42c8627be3e6b18f1adb,0xa69dfee4237d1c9f1f4f62f6bfbd0595,0xa545acd59a5c75d85e429545b1b87e8a,0x70a1c7196a2ccb69cad811e1a89c008ca941df701b0aed6ac43ff6ab5ccfe9d1,0xca1df7930abc9ed033b3eab72ec7a14b,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x76e84e5a34ab1bcbf6d9d6254cc70954,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xbd897dae4129656660b1a2734c4f25a0,NULL),(93,0x246dddf4c88865bd53f070e5b29d2f2f,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0xeb133ce1610e6ae1032d95797b649e14,0x51788f7255cc8b0a55ea40c3ed0d39a4,0x4249c876bf152f81e2a22b3f6816f82f,0xf68f4736ee0732d51d036bf82f77824c,0x460bf37db4aa0456e10a5c67a3eba82e,0x008d96ec058be5ddab749fe89dbfa685,0xa545acd59a5c75d85e429545b1b87e8a,0x7c34576dbd30ab38e4a62edec542eb43ef9d08250806a3663d567bc998ece4b3,0x01df0c8d811ea1de6980c51947bed23c,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x68e9e898d973f6c4285277eb76c2e8a7e3daa811545b343e90ee8e4f4f673a70,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x2efeba3eaee7c95d997acaa1a07d283c,NULL),(94,0xa1fb375c1e0256444dd7555a1b215eb4,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0x32cd3c3094fc83591bf25694a9ee26cf,0x421db7b4f24a4814a6a9e85284f7cb25,0xf91abc3fba8ae940a17b651a28b86dac,0xc0e427adbbef8f701a2ed487e9ed94e6,0x2b7511536352c657acdbcd2c4dde45ec,0xc2e72ea45c3afb990047c061e52b85e2,0xa545acd59a5c75d85e429545b1b87e8a,0x878226f5de6174793b5eb86bd0a3ce30ef9d08250806a3663d567bc998ece4b3,0x77bdfd8893dd94439fb7437336ae1945,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x1e35a5249159a1dc135f6355a8df32392e02a99b079bba63a102ce5eeffa9be6c89c23b97364f7f3bc27801b89b9c9dd,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x74805ef7868cf749df04b491df93ff03,NULL),(95,0x82bb6c1e9dc493e0b2ea38e60259a61b,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0x6dbbd550d122b571b69a50fff6e903ca,0x12a1f69806b0787a13c36fecce69ecfb,0xa30027cc0bf8a93a082dc42963650805,0xc0e427adbbef8f701a2ed487e9ed94e6,0x1013b15eb2a0419366a47f63aa6fa591,0x6153e89037ec2d5ab9d7d08dbcc34575,0xa545acd59a5c75d85e429545b1b87e8a,0xe2f6b8fa024e024a929eb49e215b251cb0d5958fa1a1ddd37b751e7dd087e326,0xa57477687e7fcca5d8b6309a72fa94c6,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xeff50b4bf919682fffc9e64884157918,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x798ade8f116cdd93e8e72121a9c5e605,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xc57cb050ee2fa9e3bd2cbcd5a3181478,NULL),(96,0x70d2b873e464085ec0f48f7bd5716606,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0x2fbd8b69d494c1a811252a79a3946a53,0x1846b7e8d350ac2a0be7713309709970,0x32c5a8064787e9d26bd2d16c49dc5080,0xc0e427adbbef8f701a2ed487e9ed94e6,0x5c3fe4d5f352292699084821fc4cb644,0x48cf358403e215910ba0f5f0bedd980b,0xa545acd59a5c75d85e429545b1b87e8a,0x9568e8e323130c86db53adc9436e6907a3f9b6b4b811d8808669adcb8260aee6,0xc432c7c27d574224c47fcaaa848bcf3c,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0xa0ff910595fc3c57ed6105a22a01d360,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x76e84e5a34ab1bcbf6d9d6254cc70954,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x7fcf09e9dc6ca34febad78f0f6faf1b6,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa99526ea3a1e42217ee6e67ae4510f32,NULL),(97,0xa3f0a4e1307d8d0fe06fb811d41689ce,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0x3ec68098c1ed38deb57f6f1b286435e9,0xc550ef11bbcc194d23a04db5f56ba0a1,0x5d95b6f5b05e8949591f64526f82a8b5,0xc0e427adbbef8f701a2ed487e9ed94e6,0xd4afd9ffedb615748ca0361b8f3f05d8,0x73798cfb9f048ed9ec6b5e64928f464d,0xa545acd59a5c75d85e429545b1b87e8a,0x00d174fa5715933e35c810cb50f93349b0d5958fa1a1ddd37b751e7dd087e326,0x9db7beeb6c41d2558a489aab40a58db2,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xfb589c20f470006b47949581bf7e7923,0xa664736116b07144d094544b218732c9,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xdee18a6a25c1ec309e596967cbc7968d,NULL),(98,0xe30d63782719319bcfb936598211a228,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0x2639d54b4f34d656f41b82cf32602660,0xcac4b9fb19949fa8157303fd8256ae88,0x1ffe6239eeb45f822b99a63af14cbc00,0xc0e427adbbef8f701a2ed487e9ed94e6,0xe3d04232b22f598a4689055ab80807d3,0x3f40959794229be32dd41b595c2bc757,0xe53c9ae38ad71b6e690f5583109d5d20,0xbc0224d8fb88b41713bb8108e49846f3b0d5958fa1a1ddd37b751e7dd087e326,0xf22f590e8b6e36d9967c8ec365447831,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x9b1abff5c4d7b5205eeb1286c766f316,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x277cc54b8b37c003fc0a4510aa2db09a,NULL),(99,0xd107c6f030940d0794dee040dc86980e,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9efe82a740c9e77885b3f3bfed9ce10e,0x8c7ee2e84bd685e5273c53df80541aa9,0xe6e788a4dcaada8b0442175e368e8efd,0xb13b1b66f842f4c4e0bbb022320ae663,0xc0e427adbbef8f701a2ed487e9ed94e6,0x62e0c89c6a63143ff93566bf523964e3,0xbafc62565bedf347ff1730052ebc9811,0xa545acd59a5c75d85e429545b1b87e8a,0x7e2639af02ad99ed4d839f6771041669a941df701b0aed6ac43ff6ab5ccfe9d1,0xde7eca92193263cf8057ae5e577a0c9e,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x4cdaf38832bf73b0d04c07a1a636bdb2,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xe77806708ab6c38037e10b8894d5099c,NULL),(100,0xb6e981ddea66fd90872998ab337c2f4b,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x69b40c77e26ea173d2df5b8ab08cfe75,0x084cddef27b554cea9ab45283fac2a95,0xb963e1087d5d4e08f4df41b110af401d,0xb13b1b66f842f4c4e0bbb022320ae663,0xc0e427adbbef8f701a2ed487e9ed94e6,0x4551882ed8b42221c4072c323043a502,0x95daa3c3713c42eac4f2b8232a95f532,0xa545acd59a5c75d85e429545b1b87e8a,0x7e2639af02ad99ed4d839f6771041669a941df701b0aed6ac43ff6ab5ccfe9d1,0x5c5d722f2e9d763e79e1401461925481,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x56aa9807b4104d3af2b7dae53911c6e7,NULL),(101,0x246dddf4c88865bd53f070e5b29d2f2f,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0x79b0c1b719cbe60725095b785a7fbd4c,0x7920e38d6f81a63ec1f2c09a9cf2b532,0x5ab1dd5f23e9b3d3bec265c7fffe45e4,0xf68f4736ee0732d51d036bf82f77824c,0xb239bd4c8d3a93307707dcfc5dd60f34,0x4b560e65ecbe28e8585e911968a1cf4e,0xa545acd59a5c75d85e429545b1b87e8a,0x5d104d49100425fe71c725aaf11df76820ff032b6ec76a8539cf789ed83b36c8,0x1eb0b9fdf38a933a8193786ea9a2185b,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xbc26d26b7e1341b9a4c230409a5b098b,NULL),(102,0x3ccc16b8345f5233e3ba98201fa2d158,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0x47f2692c3ce9dbcb71a3cc484dbb37d6,0x54a182816b170181ac4a7a6b1049f9c7,0x3d9f20bd2fd923d778705c1675503bf8,0xf68f4736ee0732d51d036bf82f77824c,0x0bef095bfdab42c8627be3e6b18f1adb,0x89908404e9eced028caa6d5381f1d4a5,0xa545acd59a5c75d85e429545b1b87e8a,0xc81ae12351c920fc97a90816a2fa864eb96a08f5d50bbc81b191a14fb4f424a7,0x38264fb09188c4c38b2a6a74740437ec,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x4bad37c0d42726bdb837b38e0ebabc5c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xccf74558754b82c243deab9200464cfd,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x4928ccf25321267bf84aeb98b846b991,NULL),(103,0x246dddf4c88865bd53f070e5b29d2f2f,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0x722910a0144927079132c91b6c54bd94,0x8fea08729acb4cf7446ae5b45d3966ce,0x07fd201eb76673fb7ef5d987beb926ab,0xf68f4736ee0732d51d036bf82f77824c,0xf037f5315040c3e74e00aacb99558c55,0x3a1306927b93f2cc372a47c46e08706a,0xa545acd59a5c75d85e429545b1b87e8a,0xa9319642bb4002c283c3e49dc9d33e9a1e0619411b601867bc043ca67b3f2fbc,0x111a9c01b6cff2cc588555799f5e6754,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xb3998cb8c671dae7f3df2807c2323d4c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xd6ae50fd94bb03e1c7b968fbe3ddb4f2,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa8bea903bc9094a541a85db1ff242bd1,NULL),(104,0x88626463d3598e4bc17a3eb136ad9a4d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0xe39028499d7b6f328179930ceb6d554e,0xaa965f9be9b906ce367ac603c6c24876,0x5ac1f8e32fbbfe1b37b0e06c1b4c8ae5,0xc0e427adbbef8f701a2ed487e9ed94e6,0xce48956fbc50835197c157a7f4421eb3,0xdcee16ebb3a60922bb09d204d53e8e34,0xa545acd59a5c75d85e429545b1b87e8a,0x0aaa259b1bfd44396c27b8a10bb621388e17f4c87e67c09fdb0e85c896bf1c94,0x806273735caac27277be349af70fa436,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xb3998cb8c671dae7f3df2807c2323d4c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa9152d204727b2bb30bedb619bb83808,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xf401289b38ea47571686b6b6b41d027a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xf77cde947a6c163dba7106a3a0d2e530,NULL),(105,0xece4f5c8ea2f11773e819c1b4804f535,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0xc2c9c601e6e540d9282b1cf778810255,0x4a0d02c0bbdf5d18385b16b85865e3c7,0x2e5e013c1da1f9d57640e110e8c78195,0xf68f4736ee0732d51d036bf82f77824c,0x12a25ea25ac4249befb32c67c7b18af6,0x2eb455e115d035e92717805076725ca7,0xa545acd59a5c75d85e429545b1b87e8a,0x5ea1dd0354108a4b666e85f1de97b810b96a08f5d50bbc81b191a14fb4f424a7,0xd9ed9fae5927a0dec7a4cf4fbf51c8bb,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x087e6faaaf537f7f690bc4fa5cc5971c,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xccf74558754b82c243deab9200464cfd,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x3247ff62b5f7f5be1e8e1940d7e042e5,NULL),(106,0xc103c0ab59459024fd3efb5bef3018e3,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0x8302f9945d138919c1b7bdd900aa7116,0x227cd3fcb2298f2c78696d8145c26ad7,0x9567402f3062f96d40dee6bfb139e80e,0xf68f4736ee0732d51d036bf82f77824c,0xd9f3df71464a1c1d74f67366faeb43c1,0xa32d390ab399705a18bce732ffc26695,0xa545acd59a5c75d85e429545b1b87e8a,0x7073d436b720e3195c47c71ec6e45c70dbeff435771f73aa50aed15d12221607,0x67aab3c72bd99f34770f56614ca027b6,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xa609bb9051f253e7c1c690dd3ac9e967,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x2a28c19cb380960d15bea7cf9e960edc,0xa545acd59a5c75d85e429545b1b87e8a,0xde3f935b4bde3a144a6170592ca76dcf,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xe323fbfb5abc62ddde312f7c0f9b0d68,NULL),(107,0xa74e6b38c60dd7195b469306f29fe3b5,0xcfa10a53ac284db808f6bedd952eb03d,0x11450daafe9c9d319b69367444d6e356,0xe9e0172579b8636e30e12a6bbfca681a,0x44d40dc081c16ad3c30a14c5901f1c1e,0x446bc71a5e6f4da2871e1fa33377141e,0xf68f4736ee0732d51d036bf82f77824c,0x1013b15eb2a0419366a47f63aa6fa591,0x5fb16157a3f3c79d2515f95cc4387eab,0xa545acd59a5c75d85e429545b1b87e8a,0xd21f3d9c190f2b4423aff2fc19c7d9368f46e8d57ab834233b2e5a06b8153bf3,0x4e22ee66a2074ce431866ff8c5c75005,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xa2cbe5dfb60db4199ddd737a3a0337ce,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa2c1a9757df36cda599bc5fe08d6e1f9,NULL),(108,0x45a947d5c525c00fa8640d2a5f9e62af,0x90065fe9ea51973a4989393c1f3a44af,0x9efe82a740c9e77885b3f3bfed9ce10e,0x5d8a7cba462a8c5edbcb490aabc15930,0x00462cc18e2cb5c73a846514ba0e8971,0x379bf47e34cee087180f46c71758966c,0xc0e427adbbef8f701a2ed487e9ed94e6,0xb189ad5ca4560c03caadfe0fc5486b00,0xe92d7b374dbe2db6223859ab0f93d638,0xa545acd59a5c75d85e429545b1b87e8a,0x58b853bb9a02005881aa5e229d39d3da047a8a1ef6bcd09f236ba09db0048f2d,0x14eb15e26b79b84318a5ca5eaf863a54,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xfdd7d98a2e003c4ee21a5eba336cd9b0,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x2a28c19cb380960d15bea7cf9e960edc,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xd5b48dec692930d9516dbc64455c9b8a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x968eb0f6401bd0f0fb219893131d5d99,NULL),(109,0x987d80fb3a03902df0eeaed7e4e03c9a,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0x641669ea1542e8435e7a175cc612d03b,0x91ac964c51a84dde9b2aa127d13c4522,0xc9e43f6e9f8229d143ddcec77d393749,0xf68f4736ee0732d51d036bf82f77824c,0x0d7315cc65a019d94e3165fe37525d36,0x10cd8bd70681ccd6e8c4d839865cf9ac,0xa545acd59a5c75d85e429545b1b87e8a,0x8f41d3566fe2f0c44ad4ed77563abcf7a941df701b0aed6ac43ff6ab5ccfe9d1,0xdf17180b5ddc97bd6eeba6beaece77c3,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x7bee4cdeb279fd375ce93d1cd35d5c52,0x386c7590ce683a3a45db2f5b1d166726,0xa545acd59a5c75d85e429545b1b87e8a,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x59fb9f3a517c491a1a985bfef60d5ffde84d8048e07f36c9788f0c35dd8255dc,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x5dc631128a37fd77fa7f626b35d89c83,NULL);
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `members_ministry_support`
DROP TABLE IF EXISTS `members_ministry_support`;
CREATE TABLE `members_ministry_support` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `tithe_id` int(11) DEFAULT NULL,
  `type` varchar(256) NOT NULL DEFAULT '',
  `amount` float DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `members_ministry_support`
LOCK TABLES `members_ministry_support` WRITE;
/*!40000 ALTER TABLE `members_ministry_support` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_ministry_support` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `members_other_contributions`
DROP TABLE IF EXISTS `members_other_contributions`;
CREATE TABLE `members_other_contributions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `tithe_id` int(11) DEFAULT NULL,
  `type` varchar(256) NOT NULL DEFAULT '',
  `amount` float DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `members_other_contributions`
LOCK TABLES `members_other_contributions` WRITE;
/*!40000 ALTER TABLE `members_other_contributions` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_other_contributions` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `members_seed_planting`
DROP TABLE IF EXISTS `members_seed_planting`;
CREATE TABLE `members_seed_planting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `tithe_id` int(11) DEFAULT NULL,
  `type` varchar(256) NOT NULL DEFAULT '',
  `amount` float DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `members_seed_planting`
LOCK TABLES `members_seed_planting` WRITE;
/*!40000 ALTER TABLE `members_seed_planting` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_seed_planting` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `members_thanks_giving`
DROP TABLE IF EXISTS `members_thanks_giving`;
CREATE TABLE `members_thanks_giving` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `tithe_id` varchar(256) NOT NULL DEFAULT '',
  `type` varchar(256) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table `members_thanks_giving`
LOCK TABLES `members_thanks_giving` WRITE;
/*!40000 ALTER TABLE `members_thanks_giving` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_thanks_giving` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `members_tithe`
DROP TABLE IF EXISTS `members_tithe`;
CREATE TABLE `members_tithe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` varchar(256) NOT NULL DEFAULT '',
  `tithe_id` varchar(256) NOT NULL DEFAULT '',
  `type` varchar(256) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table `members_tithe`
LOCK TABLES `members_tithe` WRITE;
/*!40000 ALTER TABLE `members_tithe` DISABLE KEYS */;
INSERT INTO `members_tithe` VALUES (1,'35','1','M-Pesa',56000,1,1,NULL,1479810751,NULL);
/*!40000 ALTER TABLE `members_tithe` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `ministries`
DROP TABLE IF EXISTS `ministries`;
CREATE TABLE `ministries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(256) NOT NULL DEFAULT '',
  `name` varchar(256) NOT NULL DEFAULT '',
  `leader` varchar(32) NOT NULL DEFAULT '',
  `telephone` varchar(256) NOT NULL DEFAULT '',
  `mobile` varchar(256) NOT NULL DEFAULT '',
  `email` varchar(256) NOT NULL DEFAULT '',
  `congregation_size` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- Dumping data for table `ministries`
LOCK TABLES `ministries` WRITE;
/*!40000 ALTER TABLE `ministries` DISABLE KEYS */;
INSERT INTO `ministries` VALUES (1,'001','Studio','37','0723924685','(072) 392-4685','makfrek@gmail.com','100','Sound and video',1,NULL,1479807557,NULL),(2,'001','Pastors','35','(072) 274-8665','(072) 274-8665','munenesamuel121@yahoo.com','3000','',1,NULL,1479822727,NULL),(3,'002','Deacons','103','0733647018','(072) 799-4436','dcnzioka@gmail.com','9','',1,1,1479822924,1479994882),(4,'004','Praise & Worship','42','(071) 771-4206','(071) 771-4206','lydiakivondo@gmail.com','30','',1,NULL,1479825124,NULL),(5,'006','Security','53','0725808918','0725808918','edgarden77@gmail.com','10','',1,NULL,1479829641,NULL),(6,'005','Usher','52','0712785185','0712785185','judywaitheramacha@gmail.com','20','',1,NULL,1479920268,NULL),(7,'007','Development Committee','47','0723822041','0723822041','ezekieleringo480@gmail.com','50','',1,NULL,1479920403,NULL);
/*!40000 ALTER TABLE `ministries` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `ministry_support`
DROP TABLE IF EXISTS `ministry_support`;
CREATE TABLE `ministry_support` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` blob,
  `totals` blob,
  `member` blob NOT NULL,
  `amount` blob NOT NULL,
  `bank` blob NOT NULL,
  `treasurer` blob NOT NULL,
  `confirmed_by` blob NOT NULL,
  `description` blob,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `ministry_support`
LOCK TABLES `ministry_support` WRITE;
/*!40000 ALTER TABLE `ministry_support` DISABLE KEYS */;
/*!40000 ALTER TABLE `ministry_support` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `o_sessions`
DROP TABLE IF EXISTS `o_sessions`;
CREATE TABLE `o_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table `o_sessions`
LOCK TABLES `o_sessions` WRITE;
/*!40000 ALTER TABLE `o_sessions` DISABLE KEYS */;
INSERT INTO `o_sessions` VALUES ('20c540b14b0f0768a60a07c2cbad9a4c','41.60.232.15','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0',1480179232,'a:7:{s:9:\"user_data\";s:0:\"\";s:5:\"email\";s:15:\"super@admin.com\";s:2:\"id\";s:1:\"1\";s:7:\"user_id\";s:1:\"1\";s:8:\"group_id\";s:1:\"1\";s:5:\"group\";s:5:\"admin\";s:17:\"flash:old:message\";a:2:{s:4:\"type\";s:7:\"success\";s:4:\"text\";s:27:\"Members Successfully Added.\";}}'),('76d62576bea7a48dbe59b71bb20be8e5','41.60.234.133','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0',1480170704,'a:6:{s:9:\"user_data\";s:0:\"\";s:5:\"email\";s:15:\"super@admin.com\";s:2:\"id\";s:1:\"1\";s:7:\"user_id\";s:1:\"1\";s:8:\"group_id\";s:1:\"1\";s:5:\"group\";s:5:\"admin\";}'),('878c3102f4785156c0fa98d38a98c19e','41.60.234.133','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0',1480160045,'a:1:{s:9:\"user_data\";s:0:\"\";}'),('ff5b642e7c995ebe6bb4c8106817181e','197.237.204.238','Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36',1480332379,'a:7:{s:9:\"user_data\";s:0:\"\";s:5:\"email\";s:15:\"super@admin.com\";s:2:\"id\";s:1:\"1\";s:7:\"user_id\";s:1:\"1\";s:8:\"group_id\";s:1:\"1\";s:5:\"group\";s:5:\"admin\";s:17:\"flash:old:message\";a:2:{s:4:\"type\";s:7:\"success\";s:4:\"text\";s:15:\"Backup Complete\";}}');
/*!40000 ALTER TABLE `o_sessions` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `offerings`
DROP TABLE IF EXISTS `offerings`;
CREATE TABLE `offerings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` blob,
  `status` blob,
  `amount` blob NOT NULL,
  `treasurer` blob NOT NULL,
  `confirmed_by` blob NOT NULL,
  `bank_deposited` blob NOT NULL,
  `description` blob,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `offerings`
LOCK TABLES `offerings` WRITE;
/*!40000 ALTER TABLE `offerings` DISABLE KEYS */;
/*!40000 ALTER TABLE `offerings` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `other_contributions`
DROP TABLE IF EXISTS `other_contributions`;
CREATE TABLE `other_contributions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` blob,
  `contribution_type` blob,
  `totals` blob,
  `member` blob NOT NULL,
  `amount` blob NOT NULL,
  `bank` blob NOT NULL,
  `treasurer` blob NOT NULL,
  `confirmed_by` blob NOT NULL,
  `description` blob,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `other_contributions`
LOCK TABLES `other_contributions` WRITE;
/*!40000 ALTER TABLE `other_contributions` DISABLE KEYS */;
/*!40000 ALTER TABLE `other_contributions` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `other_revenues`
DROP TABLE IF EXISTS `other_revenues`;
CREATE TABLE `other_revenues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `project` varchar(32) NOT NULL DEFAULT '',
  `amount` varchar(256) NOT NULL DEFAULT '',
  `collected_by` varchar(32) NOT NULL DEFAULT '',
  `bank` varchar(32) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `other_revenues`
LOCK TABLES `other_revenues` WRITE;
/*!40000 ALTER TABLE `other_revenues` DISABLE KEYS */;
/*!40000 ALTER TABLE `other_revenues` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `paid_pledges`
DROP TABLE IF EXISTS `paid_pledges`;
CREATE TABLE `paid_pledges` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `pledge_id` int(11) DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `bank` int(11) DEFAULT NULL,
  `remarks` text NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `transaction_no` varchar(50) NOT NULL,
  `amount` float DEFAULT NULL,
  `balance` float DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table `paid_pledges`
LOCK TABLES `paid_pledges` WRITE;
/*!40000 ALTER TABLE `paid_pledges` DISABLE KEYS */;
/*!40000 ALTER TABLE `paid_pledges` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `permissions`
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `res_id` int(11) NOT NULL,
  `route_id` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table `permissions`
LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,4,2,8,1,NULL,1431426211,NULL),(2,4,5,19,1,NULL,1431426211,NULL),(3,4,10,35,1,NULL,1431426211,NULL),(4,4,11,38,1,NULL,1431426211,NULL),(5,4,15,51,1,NULL,1431426211,NULL),(6,4,16,54,1,NULL,1431426212,NULL),(7,4,19,64,1,NULL,1431426212,NULL),(8,4,21,75,1,NULL,1431426212,NULL),(9,4,27,107,1,NULL,1431426212,NULL),(10,4,28,113,1,NULL,1431426212,NULL),(11,4,29,116,1,NULL,1431426212,NULL),(12,4,30,119,1,NULL,1431426212,NULL),(13,4,31,123,1,NULL,1431426212,NULL),(14,4,32,132,1,NULL,1431426212,NULL),(15,4,33,138,1,NULL,1431426212,NULL),(16,4,39,172,1,NULL,1431426212,NULL),(17,4,42,189,1,NULL,1431426212,NULL),(18,4,47,235,1,NULL,1431426212,NULL),(19,4,3,12,1,1,1431599246,1437550326);
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `petty_cash`
DROP TABLE IF EXISTS `petty_cash`;
CREATE TABLE `petty_cash` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `item` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `voucher_number` varchar(256) NOT NULL DEFAULT '',
  `amount` varchar(256) NOT NULL DEFAULT '',
  `authorised_by` varchar(32) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `petty_cash`
LOCK TABLES `petty_cash` WRITE;
/*!40000 ALTER TABLE `petty_cash` DISABLE KEYS */;
/*!40000 ALTER TABLE `petty_cash` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `pledges`
DROP TABLE IF EXISTS `pledges`;
CREATE TABLE `pledges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `title` varchar(256) NOT NULL DEFAULT '',
  `member` varchar(32) NOT NULL DEFAULT '',
  `amount` varchar(256) NOT NULL DEFAULT '',
  `expected_pay_date` int(11) DEFAULT NULL,
  `status` varchar(32) NOT NULL DEFAULT '',
  `remarks` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `pledges`
LOCK TABLES `pledges` WRITE;
/*!40000 ALTER TABLE `pledges` DISABLE KEYS */;
/*!40000 ALTER TABLE `pledges` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `prayer_requests`
DROP TABLE IF EXISTS `prayer_requests`;
CREATE TABLE `prayer_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_date` int(11) DEFAULT NULL,
  `phone_number` varchar(256) NOT NULL DEFAULT '',
  `first_name` varchar(256) NOT NULL DEFAULT '',
  `second_name` varchar(256) NOT NULL DEFAULT '',
  `address` varchar(256) NOT NULL DEFAULT '',
  `membership` varchar(32) NOT NULL DEFAULT '',
  `prayer_request` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `prayer_requests`
LOCK TABLES `prayer_requests` WRITE;
/*!40000 ALTER TABLE `prayer_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `prayer_requests` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `purchase_order`
DROP TABLE IF EXISTS `purchase_order`;
CREATE TABLE `purchase_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_date` int(11) DEFAULT NULL,
  `supplier` int(9) NOT NULL,
  `quatity` varchar(256) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `amount` varchar(256) NOT NULL DEFAULT '',
  `vat` varchar(256) NOT NULL DEFAULT '',
  `total` varchar(256) NOT NULL DEFAULT '',
  `comment` text,
  `status` int(11) DEFAULT NULL,
  `balance` float DEFAULT NULL,
  `due_date` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table `purchase_order`
LOCK TABLES `purchase_order` WRITE;
/*!40000 ALTER TABLE `purchase_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_order` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `purchase_order_list`
DROP TABLE IF EXISTS `purchase_order_list`;
CREATE TABLE `purchase_order_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(9) NOT NULL,
  `quantity` float NOT NULL,
  `description` text NOT NULL,
  `unit_price` float NOT NULL,
  `totals` double NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table `purchase_order_list`
LOCK TABLES `purchase_order_list` WRITE;
/*!40000 ALTER TABLE `purchase_order_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_order_list` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `purchase_order_payment`
DROP TABLE IF EXISTS `purchase_order_payment`;
CREATE TABLE `purchase_order_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` blob NOT NULL,
  `amount` blob NOT NULL,
  `date` blob NOT NULL,
  `pay_type` blob NOT NULL,
  `account` blob NOT NULL,
  `remarks` blob NOT NULL,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table `purchase_order_payment`
LOCK TABLES `purchase_order_payment` WRITE;
/*!40000 ALTER TABLE `purchase_order_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_order_payment` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `record_salaries`
DROP TABLE IF EXISTS `record_salaries`;
CREATE TABLE `record_salaries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_date` int(11) DEFAULT NULL,
  `employee` int(11) DEFAULT NULL,
  `basic_salary` float DEFAULT NULL,
  `total_deductions` float DEFAULT NULL,
  `total_allowance` float DEFAULT NULL,
  `nhif` float DEFAULT NULL,
  `advance` float DEFAULT NULL,
  `bank_details` text NOT NULL,
  `month` varchar(50) NOT NULL,
  `year` int(11) DEFAULT NULL,
  `deductions` text NOT NULL,
  `allowances` text NOT NULL,
  `nhif_no` varchar(255) NOT NULL,
  `nssf_no` varchar(255) NOT NULL,
  `salary_method` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `record_salaries`
LOCK TABLES `record_salaries` WRITE;
/*!40000 ALTER TABLE `record_salaries` DISABLE KEYS */;
/*!40000 ALTER TABLE `record_salaries` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `relatives`
DROP TABLE IF EXISTS `relatives`;
CREATE TABLE `relatives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `first_name` varchar(256) NOT NULL DEFAULT '',
  `last_name` varchar(256) NOT NULL DEFAULT '',
  `gender` varchar(32) NOT NULL DEFAULT '',
  `type` varchar(32) NOT NULL DEFAULT '',
  `relationship` varchar(32) NOT NULL DEFAULT '',
  `phone` varchar(256) NOT NULL DEFAULT '',
  `location` varchar(256) NOT NULL DEFAULT '',
  `email` varchar(256) NOT NULL DEFAULT '',
  `additionals` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;

-- Dumping data for table `relatives`
LOCK TABLES `relatives` WRITE;
/*!40000 ALTER TABLE `relatives` DISABLE KEYS */;
INSERT INTO `relatives` VALUES (1,35,'','','','','','','','','0',1,NULL,1477037785,NULL),(2,36,'Samuel','Munene','Male','parent','father','(072) 274-8665','kitengela','','0',1,NULL,1477039141,NULL),(3,37,'Leonard','Makokha','Male','others','others','(072) 045-5138','Kitengela','lmakokhas1@gmail.com','0',1,NULL,1479807322,NULL),(4,38,'John Kiragu','Kamau','Male','sibling','child','(072) 344-5549','Kitengela','','0',1,NULL,1479822474,NULL),(5,39,'Reginah','Ngendo','Female','spouse','wife','(072) 936-5259','Kitengela','','0',1,NULL,1479823530,NULL),(6,40,'Paul','Ndungu','Male','sibling','child','(072) 550-1194','Kitengela','','0',1,NULL,1479823947,NULL),(7,41,'Laban','Njagi','Male','sibling','child','(072) 401-4527','Mirriams','','0',1,NULL,1479824515,NULL),(8,42,'Samuel','Munene','Male','guardian','father','(072) 274-5665','Kitengela','munenesamuel121@gmail.com','0',1,NULL,1479824971,NULL),(9,43,'Caroline','Gatabi','Female','sibling','others','(072) 669-2807','Embakasi','','0',1,NULL,1479825540,NULL),(10,44,'Samuel','Munene','Male','guardian','others','(072) 076-5905','Kitengela','munenesamuel121@gmail.com','0',1,NULL,1479826309,NULL),(11,45,'Raphael','Mulei','Male','parent','father','(072) 000-2478','Makueni','','0',1,NULL,1479826671,NULL),(12,46,'Nicholas','Kisoi','Male','spouse','husband','(072) 392-4069','Kitengela','','0',1,NULL,1479827014,NULL),(13,47,'Ireen','Kaari','Female','spouse','wife','(070) 355-7535','Kitengela','','0',1,NULL,1479827360,NULL),(14,48,'Wickliffe','Waisonga','Male','parent','father','(073) 230-0080','Mombasa','','0',1,NULL,1479827756,NULL),(15,49,'Christopher','Mbithi','Male','sibling','child','(071) 281-2898','Kitengela','','0',1,NULL,1479828063,NULL),(16,50,'Christopher','Mbithi','Male','sibling','child','(071) 281-2898','Kitengela','','0',1,NULL,1479828064,NULL),(17,51,'Martha','Kithuka','Female','parent','mother','(071) 159-9896','Machakos','','0',1,NULL,1479828585,NULL),(18,52,'Esther','Wanjiku','Female','friend','friend','(071) 443-7834','Kitengela','','0',1,NULL,1479829182,NULL),(19,53,'Samuel','Munene','Male','guardian','father','(072) 274-8665','Kitengela','munenesamuel121@gmail.com','0',1,NULL,1479829547,NULL),(20,54,'Harold','Mwandikwa','Male','parent','father','(071) 308-7022','Kitengela','','0',1,NULL,1479830125,NULL),(21,55,'Kennedy','Mumanyi','Male','others','others','(072) 268-1044','Prison Kitengela','','0',1,NULL,1479830492,NULL),(22,56,'Jeniffer','Wacera','Female','parent','mother','(070) 531-1113','Namanga','','0',1,NULL,1479831057,NULL),(23,57,'Job','Nzioki','Male','others','others','(071) 869-0507','Mulolongo','','0',1,NULL,1479831781,NULL),(24,58,'Jonathan ','Mainga','Male','others','others','(070) 044-8638','Athi River','','0',1,NULL,1479832937,NULL),(25,59,'Jane','Mutua','Female','parent','mother','(072) 407-1364','Nzaikoni','','0',1,NULL,1479833136,NULL),(26,60,'Mary','Malombe','Female','spouse','wife','(070) 410-9670','Kitengela Behind NSSF','marymalombe5@gmail.com','0',1,NULL,1479833608,NULL),(27,61,'Nicodemus','Munyao','Male','others','others','(072) 759-5179','Kitengela','','0',1,NULL,1479833962,NULL),(28,62,'Mercy','Mueni','Female','others','others','(070) 226-9041','','mueni2015mercy@gmail.com','0',1,NULL,1479886179,NULL),(29,63,'','','','','','','','','0',1,NULL,1479889726,NULL),(30,64,'','','','','','','','','0',1,NULL,1479889935,NULL),(31,65,'','','','','','','','','0',1,NULL,1479890293,NULL),(32,66,'Catherine','Nyongesa','Female','parent','mother','(070) 080-5749','Kakamega','','0',1,NULL,1479890591,NULL),(33,67,'Magdaline ','Mukulu','Female','parent','mother','(070) 743-9076','Masinga','','0',1,NULL,1479890854,NULL),(34,68,'Irene','Margret','Female','others','others','(079) 130-4353','KMC Athi River','','0',1,NULL,1479892686,NULL),(35,69,'Christine','Maunda','Female','parent','mother','(070) 486-2444','Kilungu','','0',1,NULL,1479893347,NULL),(36,70,'Esther','Ndunge','Female','sibling','child','(072) 430-3825','Kitengela','','0',1,NULL,1479970417,NULL),(37,71,'Dorothy','Ndululu','Female','guardian','mother','(071) 615-8417','Kitengela','','0',1,NULL,1479970916,NULL),(38,72,'Nashon','Mburu','Female','spouse','husband','(072) 567-1736','Nyamweru','','0',1,NULL,1479971692,NULL),(39,73,'Blessing','Ahoya','Male','sibling','','(072) 458-9243','','','0',1,NULL,1479973399,NULL),(40,73,'Blessing','Ahoya','Male','others','child','(072) 458-9243','Tosha - Kitengela','','0',1,NULL,1479973559,NULL),(41,74,'Bonny ','Wambua','Male','spouse','husband','(071) 112-8953','Kitengela - EPZ','','0',1,NULL,1479973902,NULL),(42,75,'Nichodemus','Munyao','Male','spouse','husband','(072) 759-5179','Kitengela','','0',1,NULL,1479976209,NULL),(43,76,'Nelson','Meli','Male','others','others','(072) 944-9520','Nandi Kapsabet','','0',1,NULL,1479976557,NULL),(44,77,'John','Ngugi','Male','spouse','husband','(071) 431-3820','Noonkopir','','0',1,NULL,1479976834,NULL),(45,78,'Norah','Morris','Female','spouse','wife','(071) 330-6520','Kitengela','','0',1,NULL,1479977950,NULL),(46,79,'Mwangabo','Mwangabo','Male','spouse','husband','(071) 457-9569','Mwireri - Kitengela','','0',1,NULL,1479978256,NULL),(47,80,'Dancan','Maru','Male','spouse','husband','(072) 850-4722','Nyamweru','','0',1,NULL,1479978839,NULL),(48,81,'Josephat','Makau','Male','spouse','husband','(072) 553-8771','Ashut Kitengela','','0',1,NULL,1479979415,NULL),(49,82,'Siras','Owiti','Male','spouse','husband','(072) 854-7638','Kendubei','','0',1,NULL,1479979785,NULL),(50,83,'Ian','','Male','sibling','child','(071) 369-8923','','','0',1,NULL,1479980381,NULL),(51,84,'James','Makibia','Male','sibling','child','(079) 285-2648','Noonkopir','','0',1,NULL,1479980686,NULL),(52,85,'Tabitha','Kavunguyu','Female','spouse','wife','(071) 483-6214','Mwea ','','0',1,NULL,1479981249,NULL),(53,86,'Charles','Mukosi','Male','spouse','husband','(072) 029-6665','Athi River','','0',1,NULL,1479981539,NULL),(54,87,'Eunice','Wanjiku','Female','parent','mother','(070) 590-6422','iriewini','','0',1,NULL,1479987342,NULL),(55,88,'','','','','','','','','0',1,NULL,1479987616,NULL),(56,89,'Jane','Mureithi','Female','parent','mother','(072) 374-7514','Nyeri','','0',1,NULL,1479987824,NULL),(57,90,'Mary','Mwanthi','Female','parent','mother','(071) 532-6668','','','0',1,NULL,1479988054,NULL),(58,91,'Jeff Abrahams','Makau','Male','spouse','husband','(072) 240-4231','Migingo Kitengela','','0',1,NULL,1479988401,NULL),(59,92,'Moses','Muigai','Male','spouse','husband','(072) 076-7636','Kitengela','','0',1,NULL,1479988728,NULL),(60,93,'Baciana','Wakuthi','Female','spouse','wife','(072) 905-3586','Central','','0',1,NULL,1479989045,NULL),(61,94,'Danniela','Mueni','Female','spouse','wife','(070) 722-9983','Kitengela','','0',1,NULL,1479989483,NULL),(62,95,'Robert','Wasike','Male','spouse','husband','(071) 373-9495','Bungoma','','0',1,NULL,1479989730,NULL),(63,96,'Geofrey','Kuria','Male','spouse','husband','(072) 761-6250','Kenya power Kitengela','','0',1,NULL,1479989966,NULL),(64,97,'Paul','Mwangi','Male','spouse','husband','(072) 157-2325','Kitengela','','0',1,NULL,1479992502,NULL),(65,98,'Rael','Nthambi','Female','sibling','child','(072) 003-3497','Kitengela','','0',1,NULL,1479992735,NULL),(66,99,'Vinic Kemunto','Mogaka','Female','others','others','(072) 728-4815','Kitengela','','0',1,NULL,1479993009,NULL),(67,100,'David','Atenga','Male','spouse','husband','(071) 190-1586','Kitengela','','0',1,NULL,1479993362,NULL),(68,101,'Edwin','Kimani','Male','sibling','child','','Kitengela','','0',1,NULL,1479993748,NULL),(69,102,'Cheruiyot','Geff','Male','friend','friend','(071) 793-7316','Kitengela','','0',1,NULL,1479994532,NULL),(70,103,'Zipporah','Kiamba','Female','spouse','wife','(070) 339-2054','Machakos','','0',1,NULL,1479994757,NULL),(71,104,'Timothy','Kimina','Male','spouse','husband','(071) 023-1972','Kitengela','','0',1,NULL,1479995512,NULL),(72,105,'Nicholas','Yegon','Male','others','uncle','(072) 495-9186','Kitengela','','0',1,NULL,1479996387,NULL),(73,106,'Phanis','Namale','Female','parent','mother','(072) 216-7959','Kakamega','','0',1,NULL,1479997601,NULL),(74,107,'Faith','Mukei','Female','spouse','wife','(071) 658-0573','Ashut Kitengela','','0',1,NULL,1479998255,NULL),(75,108,'James','Wachira','Male','parent','father','(072) 428-6373','Naromoru','','0',1,NULL,1479998497,NULL),(76,109,'Beatrice','Kilwake','Female','spouse','wife','(070) 126-5842','Kitengela','beatricekilwke@gmail.com','0',1,NULL,1480179838,NULL);
/*!40000 ALTER TABLE `relatives` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `reports`
DROP TABLE IF EXISTS `reports`;
CREATE TABLE `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dtae` int(11) DEFAULT NULL,
  `title` varchar(256) NOT NULL DEFAULT '',
  `item_id` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `reports`
LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `resources`
DROP TABLE IF EXISTS `resources`;
CREATE TABLE `resources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resource` varchar(255) NOT NULL,
  `cat` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- Dumping data for table `resources`
LOCK TABLES `resources` WRITE;
/*!40000 ALTER TABLE `resources` DISABLE KEYS */;
INSERT INTO `resources` VALUES (1,'address_book','   Contacts Directory','Address Book',1,1,1431422584,1431432280),(2,'address_book_category','     Contacts Directory','Address Book Category',1,1,1431422584,1431432283),(3,'advance_salary','   Payroll','Advance Salary',1,1,1431422584,1431432290),(4,'allowances','   Payroll','Allowances',1,1,1431422584,1431432242),(5,'announcements','   Communication','Announcements',1,1,1431422584,1431432341),(6,'asset_category','   Assets Management','Asset Category',1,1,1431422584,1431432371),(7,'asset_items','      Assets Management','Asset Items',1,1,1431422584,1431432374),(8,'asset_stock','      Assets Management','Asset Stock',1,1,1431422584,1431432380),(9,'bank_accounts','   Church Accounts','Bank Accounts',1,1,1431422584,1431432394),(10,'baptism','    Members Management ','Baptism',1,1,1431422584,1431432597),(11,'bible_quotes','Resources','Bible Quotes',1,1,1431422584,1431433079),(12,'cfd_parents','    Members Management ','Dedication Parents',1,1,1431422584,1431433472),(13,'contribution_types','      Church Accounts','Contribution Types',1,1,1431422584,1431432400),(14,'current','','Current',1,NULL,1431422584,NULL),(15,'daily_inspirations','Resources','Daily Inspiration',1,1,1431422584,1431433450),(16,'dedications','Members Management','Dedications',1,1,1431422584,1431432995),(17,'deductions','Payroll','Deductions',1,1,1431422584,1431433261),(18,'donations','Church Accounts','Donations',1,1,1431422584,1431433288),(19,'email_templates','Communication','Email Templates',1,1,1431422584,1431433295),(20,'emails','Communication','Emails',1,1,1431422584,1431433299),(21,'events','Communication','Events',1,1,1431422584,1431433303),(22,'expenses','Church Accounts','Expenses',1,1,1431422584,1431432987),(23,'expenses_category','Church Accounts','Expenses Category',1,1,1431422584,1431432981),(24,'expenses_items','Church Accounts','Expenses Items',1,1,1431422584,1431432976),(25,'files','Communication','Files',1,1,1431422584,1431433310),(26,'groups','','Groups',1,NULL,1431422584,NULL),(27,'hbc_meetings','Members Management','HBC Meetings',1,1,1431422584,1431433436),(28,'hbcs','Members Management','HBCs',1,1,1431422584,1431433430),(29,'hymns_manager','Resources','Hymns Manager',1,1,1431422584,1431433109),(30,'meetings','Communication','Meetings',1,1,1431422584,1431433118),(31,'members','Members Management','Members',1,1,1431422584,1431432958),(32,'ministries','Members Management','Ministries',1,1,1431422584,1431432952),(33,'ministry_support','Members Management','Ministry Support',1,1,1431422584,1431432944),(34,'offerings','Church Accounts','Offerings',1,1,1431422584,1431432937),(35,'other_contributions','Church Accounts','Other Contributions',1,1,1431422584,1431432931),(36,'permissions','','Permissions',1,NULL,1431422584,NULL),(37,'petty_cash','Church Accounts','Petty Cash',1,1,1431422584,1431432862),(38,'pledges','Church Accounts','Pledges',1,1,1431422584,1431432856),(39,'prayer_requests','Resources','Prayer Requests',1,1,1431422584,1431433127),(40,'purchase_order','Church Accounts','Purchase Order',1,1,1431422584,1431432849),(41,'record_salaries','Payroll','Record Salaries',1,1,1431422584,1431433245),(42,'relatives','    Members Management ','Relatives',1,1,1431422584,1431432684),(43,'reports','Reports','Reports',1,1,1431422584,1431433138),(44,'salaries','Payroll','Salaries',1,1,1431422584,1431433240),(45,'sandbox','','Sandbox',1,NULL,1431422584,NULL),(46,'seed_planting','Church Accounts','Seed Planting',1,1,1431422584,1431432830),(47,'sermons','Resources','Sermons',1,1,1431422584,1431433147),(48,'settings','Settings','Settings',1,1,1431422584,1431433228),(49,'sms','Communication','Sms',1,1,1431422584,1431433222),(50,'sms_subscriptions','Communication','Sms Subscriptions',1,1,1431422584,1431433212),(51,'ss_parents','Members Management','Sunday School Parents',1,1,1431422584,1431433390),(52,'sunday_school','Members Management','Sunday School',1,1,1431422584,1431432816),(53,'take_stock','Assets Management','Take Stock',1,1,1431422584,1431433200),(54,'task_manager','Resources','Task Manager',1,1,1431422584,1431433188),(55,'tax_config','Payroll','Tax Config',1,1,1431422584,1431433171),(56,'testmodes','','Testmodes',1,NULL,1431422584,NULL),(57,'thanks_giving','Members Management','Thanks Giving',1,1,1431422584,1431432808),(58,'tithes','      Church Accounts','Tithes',1,1,1431422584,1431432480),(59,'tools','','Tools',1,NULL,1431422584,NULL),(60,'users','','Users',1,NULL,1431422584,NULL),(61,'visitors','Members Management ','Visitors',1,1,1431422584,1431432801),(62,'weddings','Resources','Weddings',1,1,1431422584,1431432785),(63,'allocations','','Allocations',1,NULL,1433680342,NULL),(64,'allocations_expenditure','','Allocations Expenditure',1,NULL,1433680342,NULL),(65,'folders','','Folders',1,NULL,1433680342,NULL),(66,'video_sermons','','Video Sermons',1,NULL,1433680343,NULL);
/*!40000 ALTER TABLE `resources` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `routes`
DROP TABLE IF EXISTS `routes`;
CREATE TABLE `routes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resource` int(11) NOT NULL,
  `method` varchar(255) NOT NULL,
  `is_menu` tinyint(4) NOT NULL,
  `description` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=310 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- Dumping data for table `routes`
LOCK TABLES `routes` WRITE;
/*!40000 ALTER TABLE `routes` DISABLE KEYS */;
INSERT INTO `routes` VALUES (1,1,'index',1,'Address Book','clip-list',1,NULL,1431424708,NULL),(2,1,'customers',1,'Customers Address Book','',1,NULL,1431424708,NULL),(3,1,'suppliers',1,'Suppliers Address Book','',1,NULL,1431424708,NULL),(4,1,'others',1,'Others Address Book','',1,NULL,1431424708,NULL),(5,1,'quick_add',0,'Quick Add Address Book','',1,1,1431424708,1436884553),(6,1,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424708,NULL),(7,1,'edit',1,'Edit Address Book','clip-pencil',1,NULL,1431424708,NULL),(8,2,'index',1,'Address Book Category','clip-list',1,NULL,1431424708,NULL),(9,2,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424708,NULL),(10,2,'quick_add',1,'Quick Add Category','',1,1,1431424708,1431425312),(11,2,'edit',1,'Edit Category','clip-pencil',1,1,1431424708,1431425342),(12,3,'index',1,'Advance Salary','clip-list',1,NULL,1431424708,NULL),(13,3,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424708,NULL),(14,3,'edit',1,'Edit Advance Salary','clip-pencil',1,NULL,1431424708,NULL),(15,3,'void',1,'Void Advance Salary','clip-close-4',1,NULL,1431424708,NULL),(16,4,'index',1,'Allowances','clip-list',1,NULL,1431424708,NULL),(17,4,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424708,NULL),(18,4,'edit',1,'Edit Allowances','clip-pencil',1,NULL,1431424708,NULL),(19,5,'index',1,'Announcements','clip-list',1,NULL,1431424708,NULL),(20,5,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424708,NULL),(21,5,'edit',1,'Edit Announcements','clip-pencil',1,NULL,1431424708,NULL),(22,6,'index',1,'Asset Category','clip-list',1,NULL,1431424708,NULL),(23,6,'quick_add',1,'Quick Add','',1,1,1431424708,1431425293),(24,6,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424708,NULL),(25,6,'edit',1,'Edit Asset Category','clip-pencil',1,NULL,1431424708,NULL),(26,7,'index',1,'Asset Items','clip-list',1,NULL,1431424709,NULL),(27,7,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(28,7,'edit',1,'Edit Asset Items','clip-pencil',1,NULL,1431424709,NULL),(29,8,'index',1,'Asset Stock','clip-list',1,NULL,1431424709,NULL),(30,8,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(31,8,'edit',1,'Edit Asset Stock','clip-pencil',1,NULL,1431424709,NULL),(32,9,'index',1,'Bank Accounts','clip-list',1,NULL,1431424709,NULL),(33,9,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(34,9,'edit',1,'Edit Bank Accounts','clip-pencil',1,NULL,1431424709,NULL),(35,10,'index',1,'Baptism','clip-list',1,NULL,1431424709,NULL),(36,10,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(37,10,'edit',1,'Edit Baptism','clip-pencil',1,NULL,1431424709,NULL),(38,11,'index',1,'Bible Quotes','clip-list',1,NULL,1431424709,NULL),(39,11,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(40,11,'edit',1,'Edit Bible Quotes','clip-pencil',1,NULL,1431424709,NULL),(41,12,'index',1,'Cfd Parents','clip-list',1,NULL,1431424709,NULL),(42,12,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(43,12,'edit',1,'Edit Cfd Parents','clip-pencil',1,NULL,1431424709,NULL),(44,13,'index',1,'Contribution Types','clip-list',1,NULL,1431424709,NULL),(45,13,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(46,13,'quick_add',1,'Quick Add Contribution Types','',1,NULL,1431424709,NULL),(47,13,'edit',1,'Edit Contribution Types','clip-pencil',1,NULL,1431424709,NULL),(48,14,'index',1,'Current','clip-list',1,NULL,1431424709,NULL),(49,14,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(50,14,'edit',1,'Edit Current','clip-pencil',1,NULL,1431424709,NULL),(51,15,'index',1,'Daily Inspirations','clip-list',1,NULL,1431424709,NULL),(52,15,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(53,15,'edit',1,'Edit Daily Inspirations','clip-pencil',1,NULL,1431424709,NULL),(54,16,'index',1,'Dedications','clip-list',1,NULL,1431424709,NULL),(55,16,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(56,16,'edit',1,'Edit Dedications','clip-pencil',1,NULL,1431424709,NULL),(57,16,'dedicate',1,'Dedicate Dedications','',1,NULL,1431424709,NULL),(58,17,'index',1,'Deductions','clip-list',1,NULL,1431424709,NULL),(59,17,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(60,17,'edit',1,'Edit Deductions','clip-pencil',1,NULL,1431424709,NULL),(61,18,'index',1,'Donations','clip-list',1,NULL,1431424709,NULL),(62,18,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(63,18,'edit',1,'Edit Donations','clip-pencil',1,NULL,1431424709,NULL),(64,19,'index',1,'Email Templates','clip-list',1,NULL,1431424709,NULL),(65,19,'import',1,'Import Email Templates','',1,NULL,1431424709,NULL),(66,19,'export',1,'Export Email Templates','',1,NULL,1431424709,NULL),(67,19,'help',1,'Help Email Templates','',1,NULL,1431424709,NULL),(68,19,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(69,19,'edit',1,'Edit Email Templates','clip-pencil',1,NULL,1431424709,NULL),(70,19,'preview',1,'Preview Email Templates','',1,NULL,1431424709,NULL),(71,19,'action',1,'Action Email Templates','',1,NULL,1431424709,NULL),(72,20,'index',1,'Emails','clip-list',1,NULL,1431424709,NULL),(73,20,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(74,20,'edit',1,'Edit Emails','clip-pencil',1,NULL,1431424709,NULL),(75,21,'index',1,'Events','clip-list',1,NULL,1431424709,NULL),(76,21,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(77,21,'edit',1,'Edit Events','clip-pencil',1,NULL,1431424709,NULL),(78,22,'index',1,'Expenses','clip-list',1,NULL,1431424709,NULL),(79,22,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(80,22,'edit',1,'Edit Expenses','clip-pencil',1,NULL,1431424709,NULL),(81,23,'index',1,'Expenses Category','clip-list',1,NULL,1431424709,NULL),(82,23,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(83,23,'quick_add',1,'Quick Add Expenses Category','',1,NULL,1431424709,NULL),(84,23,'edit',1,'Edit Expenses Category','clip-pencil',1,NULL,1431424709,NULL),(85,24,'index',1,'Expenses Items','clip-list',1,NULL,1431424709,NULL),(86,24,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(87,24,'quick_add',1,'Quick Add Expenses Items','',1,NULL,1431424709,NULL),(88,24,'edit',1,'Edit Expenses Items','clip-pencil',1,NULL,1431424709,NULL),(89,25,'index',1,'Files','clip-list',1,NULL,1431424709,NULL),(90,25,'folder',1,'Folder Files','',1,NULL,1431424709,NULL),(91,25,'get_files',1,'Get Files Files','',1,NULL,1431424709,NULL),(92,25,'import',1,'Import Files','',1,NULL,1431424709,NULL),(93,25,'export',1,'Export Files','',1,NULL,1431424709,NULL),(94,25,'help',1,'Help Files','',1,NULL,1431424709,NULL),(95,25,'files_list',1,'Files List Files','',1,NULL,1431424709,NULL),(96,25,'files_upload',1,'Files Upload Files','',1,NULL,1431424709,NULL),(97,25,'upload',1,'Upload Files','',1,NULL,1431424709,NULL),(98,25,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(99,25,'created',1,'Created Files','',1,NULL,1431424709,NULL),(100,25,'edited',1,'Edited Files','',1,NULL,1431424709,NULL),(101,25,'edit',1,'Edit Files','clip-pencil',1,NULL,1431424709,NULL),(102,25,'preview',1,'Preview Files','',1,NULL,1431424709,NULL),(103,25,'action',1,'Action Files','',1,NULL,1431424709,NULL),(104,26,'index',1,'Groups','clip-list',1,NULL,1431424709,NULL),(105,26,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(106,26,'edit',1,'Edit Groups','clip-pencil',1,NULL,1431424709,NULL),(107,27,'index',1,'Hbc Meetings','clip-list',1,NULL,1431424709,NULL),(108,27,'meetings',1,'Meetings Hbc Meetings','',1,NULL,1431424709,NULL),(109,27,'add',1,'Add Hbc Meetings','',1,NULL,1431424709,NULL),(110,27,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(111,27,'edit',1,'Edit Hbc Meetings','clip-pencil',1,NULL,1431424709,NULL),(112,28,'upload_hbcsc',1,'Upload Hbcsc Hbcs','',1,NULL,1431424709,NULL),(113,28,'index',1,'Hbcs','clip-list',1,NULL,1431424709,NULL),(114,28,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(115,28,'edit',1,'Edit Hbcs','clip-pencil',1,NULL,1431424709,NULL),(116,29,'index',1,'Hymns Manager','clip-list',1,NULL,1431424709,NULL),(117,29,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(118,29,'edit',1,'Edit Hymns Manager','clip-pencil',1,NULL,1431424709,NULL),(119,30,'index',1,'Meetings','clip-list',1,NULL,1431424709,NULL),(120,30,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(121,30,'edit',1,'Edit Meetings','clip-pencil',1,NULL,1431424709,NULL),(122,31,'add_members',1,'Add Members Members','',1,NULL,1431424709,NULL),(123,31,'index',1,'Members','clip-users-2',1,NULL,1431424709,NULL),(124,31,'add_groups',1,'Add Groups Members','',1,NULL,1431424709,NULL),(125,31,'upload_members',1,'Upload Members Members','',1,NULL,1431424709,NULL),(126,31,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(127,31,'update_mems',1,'Update Mems Members','',1,NULL,1431424709,NULL),(128,31,'search',1,'Search Members','clip-search',1,NULL,1431424709,NULL),(129,31,'profile',1,'Profile Members','',1,NULL,1431424709,NULL),(130,31,'edit',1,'Edit Members','clip-pencil',1,NULL,1431424709,NULL),(131,31,'remove_ministry',1,'Remove Ministry Members','',1,NULL,1431424709,NULL),(132,32,'index',1,'Ministries','clip-list',1,NULL,1431424709,NULL),(133,32,'members',1,'Members Ministries','',1,NULL,1431424709,NULL),(134,32,'search',1,'Search Ministries','clip-search',1,NULL,1431424709,NULL),(135,32,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(136,32,'edit',1,'Edit Ministries','clip-pencil',1,NULL,1431424709,NULL),(137,32,'remove_member',1,'Remove Member Ministries','',1,NULL,1431424709,NULL),(138,33,'index',1,'Ministry Support','clip-list',1,NULL,1431424709,NULL),(139,33,'voided',1,'Voided Ministry Support','clip-close-4',1,NULL,1431424709,NULL),(140,33,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(141,33,'view_members',1,'View Members Ministry Support','',1,NULL,1431424709,NULL),(142,33,'edit',1,'Edit Ministry Support','clip-pencil',1,NULL,1431424709,NULL),(143,33,'void',1,'Void Ministry Support','clip-close-4',1,NULL,1431424709,NULL),(144,34,'index',1,'Offerings','clip-list',1,NULL,1431424709,NULL),(145,34,'voided',1,'Voided Offerings','clip-close-4',1,NULL,1431424709,NULL),(146,34,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(147,34,'edit_removed',1,'Edit Removed Offerings','',1,NULL,1431424709,NULL),(148,34,'void',1,'Void Offerings','clip-close-4',1,NULL,1431424709,NULL),(149,35,'index',1,'Other Contributions','clip-list',1,NULL,1431424709,NULL),(150,35,'voided',1,'Voided Other Contributions','clip-close-4',1,NULL,1431424709,NULL),(151,35,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(152,35,'custom',1,'Custom Other Contributions','',1,NULL,1431424709,NULL),(153,35,'view_members',1,'View Members Other Contributions','',1,NULL,1431424709,NULL),(154,35,'edit',1,'Edit Other Contributions','clip-pencil',1,NULL,1431424709,NULL),(155,35,'void',1,'Void Other Contributions','clip-close-4',1,NULL,1431424709,NULL),(156,36,'index',1,'Permissions','clip-list',1,NULL,1431424709,NULL),(157,36,'view',1,'View Permissions','',1,NULL,1431424709,NULL),(158,36,'assign',1,'Assign Permissions','',1,NULL,1431424709,NULL),(159,36,'get_routes',1,'Get Routes Permissions','',1,NULL,1431424709,NULL),(160,37,'index',1,'Petty Cash','clip-list',1,NULL,1431424709,NULL),(161,37,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(162,37,'edit',1,'Edit Petty Cash','clip-pencil',1,NULL,1431424709,NULL),(163,38,'index',1,'Pledges','clip-list',1,NULL,1431424709,NULL),(164,38,'paid',1,'Paid Pledges','',1,NULL,1431424709,NULL),(165,38,'voided',1,'Voided Pledges','clip-close-4',1,NULL,1431424709,NULL),(166,38,'pending',1,'Pending Pledges','',1,NULL,1431424709,NULL),(167,38,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(168,38,'payment',1,'Payment Pledges','',1,NULL,1431424709,NULL),(169,38,'edit',1,'Edit Pledges','clip-pencil',1,NULL,1431424709,NULL),(170,38,'void',1,'Void Pledges','clip-close-4',1,NULL,1431424709,NULL),(171,38,'void_paid',1,'Void Paid Pledges','',1,NULL,1431424709,NULL),(172,39,'index',1,'Prayer Requests','clip-list',1,NULL,1431424709,NULL),(173,39,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(174,39,'edit',1,'Edit Prayer Requests','clip-pencil',1,NULL,1431424709,NULL),(175,40,'index',1,'Purchase Order','clip-list',1,NULL,1431424709,NULL),(176,40,'voided',1,'Voided Purchase Order','clip-close-4',1,NULL,1431424709,NULL),(177,40,'void',1,'Void Purchase Order','clip-close-4',1,NULL,1431424709,NULL),(178,40,'order',1,'Order Purchase Order','',1,NULL,1431424709,NULL),(179,40,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(180,40,'make_pay',1,'Make Pay Purchase Order','',1,NULL,1431424709,NULL),(181,40,'edit_old',1,'Edit Old Purchase Order','',1,NULL,1431424709,NULL),(182,41,'index',1,'Record Salaries','clip-list',1,NULL,1431424709,NULL),(183,41,'employees',1,'Employees Record Salaries','',1,NULL,1431424709,NULL),(184,41,'my_slips',1,'My Slips Record Salaries','',1,NULL,1431424709,NULL),(185,41,'slip',1,'Slip Record Salaries','',1,NULL,1431424709,NULL),(186,41,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424709,NULL),(187,41,'edit_removed',1,'Edit Removed Record Salaries','',1,NULL,1431424710,NULL),(188,41,'delete_removed',1,'Delete Removed Record Salaries','',1,NULL,1431424710,NULL),(189,42,'index',1,'Relatives','clip-list',1,NULL,1431424710,NULL),(190,42,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424710,NULL),(191,42,'edit',1,'Edit Relatives','clip-pencil',1,NULL,1431424710,NULL),(192,43,'index',1,'Reports','clip-list',1,NULL,1431424710,NULL),(193,43,'accounts_reports',1,'Accounts Reports Reports','',1,NULL,1431424710,NULL),(194,43,'filter_account',1,'Filter Account Reports','',1,NULL,1431424710,NULL),(195,43,'accounts_date',1,'Accounts Date Reports','',1,NULL,1431424710,NULL),(196,43,'members_reports',1,'Members Reports Reports','',1,NULL,1431424710,NULL),(197,43,'filter_members',1,'Filter Members Reports','',1,NULL,1431424710,NULL),(198,43,'members_byDate',1,'Members Bydate Reports','',1,NULL,1431424710,NULL),(199,43,'members_custom_filter',1,'Members Custom Filter Reports','',1,NULL,1431424710,NULL),(200,43,'filter_hbc_members',1,'Filter Hbc Members Reports','',1,NULL,1431424710,NULL),(201,43,'filter_visitors',1,'Filter Visitors Reports','',1,NULL,1431424710,NULL),(202,43,'visitors_byDate',1,'Visitors Bydate Reports','',1,NULL,1431424710,NULL),(203,43,'filter_baptism',1,'Filter Baptism Reports','',1,NULL,1431424710,NULL),(204,43,'baptism_byDate',1,'Baptism Bydate Reports','',1,NULL,1431424710,NULL),(205,43,'filter_dedications',1,'Filter Dedications Reports','',1,NULL,1431424710,NULL),(206,43,'dedications_byDate',1,'Dedications Bydate Reports','',1,NULL,1431424710,NULL),(207,43,'filter_ssSchool',1,'Filter Ssschool Reports','',1,NULL,1431424710,NULL),(208,43,'ssSchool_byDate',1,'Ssschool Bydate Reports','',1,NULL,1431424710,NULL),(209,43,'filter_ministry_members',1,'Filter Ministry Members Reports','',1,NULL,1431424710,NULL),(210,43,'ministry_members',1,'Ministry Members Reports','',1,NULL,1431424710,NULL),(211,43,'ministry_search',1,'Ministry Search Reports','',1,NULL,1431424710,NULL),(212,43,'sms_reports',1,'Sms Reports Reports','',1,NULL,1431424710,NULL),(213,43,'filter_sms',1,'Filter Sms Reports','',1,NULL,1431424710,NULL),(214,43,'current_monthSMS',1,'Current Monthsms Reports','',1,NULL,1431424710,NULL),(215,43,'sms_byDate',1,'Sms Bydate Reports','',1,NULL,1431424710,NULL),(216,43,'sms_purchased',1,'Sms Purchased Reports','',1,NULL,1431424710,NULL),(217,43,'purchased_byDate',1,'Purchased Bydate Reports','',1,NULL,1431424710,NULL),(218,43,'assets_reports',1,'Assets Reports Reports','',1,NULL,1431424710,NULL),(219,43,'filter_assets',1,'Filter Assets Reports','',1,NULL,1431424710,NULL),(220,43,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424710,NULL),(221,43,'edit',1,'Edit Reports','clip-pencil',1,NULL,1431424710,NULL),(222,44,'index',1,'Salaries','clip-list',1,NULL,1431424710,NULL),(223,44,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424710,NULL),(224,44,'edit',1,'Edit Salaries','clip-pencil',1,NULL,1431424710,NULL),(225,44,'get_nhif',1,'Get Nhif Salaries','',1,NULL,1431424710,NULL),(226,45,'exp',1,'Exp Sandbox','',1,NULL,1431424710,NULL),(227,45,'index',1,'Sandbox','clip-list',1,NULL,1431424710,NULL),(228,45,'fix',1,'Fix Sandbox','',1,NULL,1431424710,NULL),(229,46,'index',1,'Seed Planting','clip-list',1,NULL,1431424710,NULL),(230,46,'voided',1,'Voided Seed Planting','clip-close-4',1,NULL,1431424710,NULL),(231,46,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424710,NULL),(232,46,'view_members',1,'View Members Seed Planting','',1,NULL,1431424710,NULL),(233,46,'edit',1,'Edit Seed Planting','clip-pencil',1,NULL,1431424710,NULL),(234,46,'void',1,'Void Seed Planting','clip-close-4',1,NULL,1431424710,NULL),(235,47,'index',1,'Sermons','clip-list',1,NULL,1431424710,NULL),(236,47,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424710,NULL),(237,47,'edit',1,'Edit Sermons','clip-pencil',1,NULL,1431424710,NULL),(238,48,'index',1,'Settings','clip-list',1,NULL,1431424710,NULL),(239,48,'index_reloaded',1,'Index Reloaded Settings','',1,NULL,1431424710,NULL),(240,48,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424710,NULL),(241,48,'edit',1,'Edit Settings','clip-pencil',1,NULL,1431424710,NULL),(242,49,'index',1,'Sms','clip-list',1,NULL,1431424710,NULL),(243,49,'my_sms',1,'My Sms Sms','',1,NULL,1431424710,NULL),(244,49,'compose',1,'Compose Sms','',1,NULL,1431424710,NULL),(245,49,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424710,NULL),(246,49,'edit_removed',1,'Edit Removed Sms','',1,NULL,1431424710,NULL),(247,50,'index',1,'Sms Subscriptions','clip-list',1,NULL,1431424710,NULL),(248,50,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424710,NULL),(249,50,'edit',1,'Edit Sms Subscriptions','clip-pencil',1,NULL,1431424710,NULL),(250,51,'index',1,'Ss Parents','clip-list',1,NULL,1431424710,NULL),(251,51,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424710,NULL),(252,51,'edit',1,'Edit Ss Parents','clip-pencil',1,NULL,1431424710,NULL),(253,52,'index',1,'Sunday School','clip-list',1,NULL,1431424710,NULL),(254,52,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424710,NULL),(255,52,'search',1,'Search Sunday School','clip-search',1,NULL,1431424710,NULL),(256,52,'profile',1,'Profile Sunday School','',1,NULL,1431424710,NULL),(257,52,'edit',1,'Edit Sunday School','clip-pencil',1,NULL,1431424710,NULL),(258,52,'remove_parent',1,'Remove Parent Sunday School','',1,NULL,1431424710,NULL),(259,53,'index',1,'Take Stock','clip-list',1,NULL,1431424710,NULL),(260,53,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424710,NULL),(261,53,'edit',1,'Edit Take Stock','clip-pencil',1,NULL,1431424710,NULL),(262,54,'index',1,'Task Manager','clip-list',1,NULL,1431424710,NULL),(263,54,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424710,NULL),(264,54,'edit',1,'Edit Task Manager','clip-pencil',1,NULL,1431424710,NULL),(265,55,'index',1,'Tax Config','clip-list',1,NULL,1431424710,NULL),(266,55,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424710,NULL),(267,55,'edit',1,'Edit Tax Config','clip-pencil',1,NULL,1431424710,NULL),(268,56,'index',1,'Testmodes','clip-list',1,NULL,1431424710,NULL),(269,56,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424710,NULL),(270,56,'edit',1,'Edit Testmodes','clip-pencil',1,NULL,1431424710,NULL),(271,57,'index',1,'Thanks Giving','clip-list',1,NULL,1431424710,NULL),(272,57,'voided',1,'Voided Thanks Giving','clip-close-4',1,NULL,1431424710,NULL),(273,57,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424710,NULL),(274,57,'view_members',1,'View Members Thanks Giving','',1,NULL,1431424710,NULL),(275,57,'edit',1,'Edit Thanks Giving','clip-pencil',1,NULL,1431424710,NULL),(276,57,'void',1,'Void Thanks Giving','clip-close-4',1,NULL,1431424710,NULL),(277,58,'index',1,'Tithes','clip-list',1,NULL,1431424710,NULL),(278,58,'voided',1,'Voided Tithes','clip-close-4',1,NULL,1431424710,NULL),(279,58,'sms_tithe',1,'Sms Tithe Tithes','',1,NULL,1431424710,NULL),(280,58,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424710,NULL),(281,58,'receipt',1,'Receipt Tithes','',1,NULL,1431424710,NULL),(282,58,'view_members',1,'View Members Tithes','',1,NULL,1431424710,NULL),(283,58,'edit',1,'Edit Tithes','clip-pencil',1,NULL,1431424710,NULL),(284,58,'void',1,'Void Tithes','clip-close-4',1,NULL,1431424710,NULL),(285,59,'index',1,'Tools','clip-list',1,NULL,1431424710,NULL),(286,60,'index',1,'Users','clip-list',1,NULL,1431424710,NULL),(287,60,'search_around',1,'Search Around Users','',1,NULL,1431424710,NULL),(288,60,'edit',1,'Edit Users','clip-pencil',1,NULL,1431424710,NULL),(289,60,'change_password',1,'Change Password Users','',1,NULL,1431424710,NULL),(290,60,'forgot_password',1,'Forgot Password Users','',1,NULL,1431424710,NULL),(291,60,'reset_password',1,'Reset Password Users','',1,NULL,1431424710,NULL),(292,60,'activate',1,'Activate Users','',1,NULL,1431424710,NULL),(293,60,'deactivate',1,'Deactivate Users','',1,NULL,1431424710,NULL),(294,60,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424710,NULL),(295,60,'profile',1,'Profile Users','',1,NULL,1431424710,NULL),(296,60,'add_connection',1,'Add Connection Users','',1,NULL,1431424710,NULL),(297,60,'fetch_notes',1,'Fetch Notes Users','',1,NULL,1431424710,NULL),(298,61,'index',1,'Visitors','clip-list',1,NULL,1431424710,NULL),(299,61,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424710,NULL),(300,61,'edit',1,'Edit Visitors','clip-pencil',1,NULL,1431424710,NULL),(301,62,'index',1,'Weddings','clip-list',1,NULL,1431424710,NULL),(302,62,'create',1,'Add New ','clip-plus-circle-2',1,NULL,1431424710,NULL),(303,62,'edit',1,'Edit Weddings','clip-pencil',1,NULL,1431424710,NULL),(304,36,'fix_resources',1,'Fix Resources Permissions','',1,NULL,1431437357,NULL),(305,48,'backup',1,'Backup Settings','',1,NULL,1431599521,NULL),(306,22,'by_item',1,'By Item Expenses','',1,NULL,1433680334,NULL),(307,22,'by_category',1,'By Category Expenses','',1,NULL,1433680334,NULL),(308,24,'petty_add',1,'Petty Add Expenses Items','',1,NULL,1433680334,NULL),(309,37,'by_item',1,'By Item Petty Cash','',1,NULL,1433680334,NULL);
/*!40000 ALTER TABLE `routes` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `salaries`
DROP TABLE IF EXISTS `salaries`;
CREATE TABLE `salaries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee` varchar(256) NOT NULL DEFAULT '',
  `salary_method` varchar(256) NOT NULL DEFAULT '',
  `basic_salary` float DEFAULT NULL,
  `nhif` float DEFAULT NULL,
  `bank_account_no` varchar(256) NOT NULL DEFAULT '',
  `bank_name` varchar(256) NOT NULL DEFAULT '',
  `nhif_no` varchar(256) NOT NULL DEFAULT '',
  `nssf_no` varchar(256) NOT NULL DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `salaries`
LOCK TABLES `salaries` WRITE;
/*!40000 ALTER TABLE `salaries` DISABLE KEYS */;
/*!40000 ALTER TABLE `salaries` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `seed_planting`
DROP TABLE IF EXISTS `seed_planting`;
CREATE TABLE `seed_planting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` blob,
  `totals` blob,
  `member` blob NOT NULL,
  `amount` blob NOT NULL,
  `bank` blob NOT NULL,
  `treasurer` blob NOT NULL,
  `confirmed_by` blob NOT NULL,
  `description` blob,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `seed_planting`
LOCK TABLES `seed_planting` WRITE;
/*!40000 ALTER TABLE `seed_planting` DISABLE KEYS */;
/*!40000 ALTER TABLE `seed_planting` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `sermons`
DROP TABLE IF EXISTS `sermons`;
CREATE TABLE `sermons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_date` int(11) DEFAULT NULL,
  `title` varchar(256) NOT NULL DEFAULT '',
  `service_leader` varchar(256) NOT NULL DEFAULT '',
  `first_service` varchar(256) NOT NULL DEFAULT '',
  `second_service` varchar(256) NOT NULL DEFAULT '',
  `pastor_on_duty` varchar(32) NOT NULL DEFAULT '',
  `file` varchar(32) NOT NULL DEFAULT '',
  `sermon_theme` text,
  `description` text,
  `upload_sermon` varchar(256) NOT NULL DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `sermons`
LOCK TABLES `sermons` WRITE;
/*!40000 ALTER TABLE `sermons` DISABLE KEYS */;
/*!40000 ALTER TABLE `sermons` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `servers`
DROP TABLE IF EXISTS `servers`;
CREATE TABLE `servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `license` blob,
  `status` blob NOT NULL,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table `servers`
LOCK TABLES `servers` WRITE;
/*!40000 ALTER TABLE `servers` DISABLE KEYS */;
INSERT INTO `servers` VALUES (1,0xa6dad194194075b7fb69b56ae801a72e9a65057b345e4e232237df245485fc3a4750a64633022949a211ceea53e1f1f0a6dad194194075b7fb69b56ae801a72ea6dad194194075b7fb69b56ae801a72e5f27a34697bd47f2ae9fb620de3bc0388459c565724b0fc65f52e278c21b0d5a9128a1a6e3b7c0d825b599690dd4b63d6257b25d719d96b01594368a13c01d4b0e7a22faeaa8fb778bc388c10fd63da06510a4520e8d5bd6456792da900f04a274777869bb446cf461e88c796b005ff57e92c69ecf17672599f8bdbbbd5469ee897e3a6b24456f88aebc517fa7b53efc24ec2e81bd0cc80450af1da02cc5bbcf780556ea9cc8827e606bb930f06e0956349f2c4f90389d894b1800e144cbf02aef08876bcf863983b9468134d154cd8ab9daadce46df9c3932117292e330fab2328efce3f2318678d1be6399896b654c0256a2511673bc69e9516daf9f55d071868064accbba6460e9f9024024d72dd0eb2da2e2d193421fd5c8fce637a023735bef7e3e3878a654373f38a6d6ff4f8bd3fffeb38cf4da363072dd75041becbc2e5042e757a323ef314cc2d06aadefd655f4bf69cb7b511e77429168e2a1960485e3ea24a1e2b5751cc9f4a9255dfa2662ebf8de9f4eb02da4813e960db28eeb13b39deff1493250ff2c11e11d5b47e84d7cff9bfe2e47ffacd7d81c3d7d02a20ae1241291e6973360c0b180f8153283bb4275a58bca95720d696416889a7b574f7fa3e0a294eb16602a96694ab187956c2a0172b813ec6c3473acca7ce70e6ff3032c89c1bcea89b064bea0443e4b8c24eaa3bbc76f1b020a40b97fc9c6d286616d48c9835d533535f7d8edefb51529840428a4e5a0f6e07b870c3d9d0d6bcea0709d65c48216083167ea9dce188c3aaf0ccf152ebfcd4ffdab8319ab3a180757c025fb28797729254c47a3803f7893babe0aa4776e28b9e36ec9c4e74165f5be9cc1e1798cf45e0a040b3dd8639c0ea648b4f44ab1bb18083dfad15ba278e59f9e5c958a6623b5adf0374d70e4f5b1fba917dbdaf590b6475d056cdd513124d9e8040eb7bafa138ddc35fa41f69fb76a885a9334a14271c1c4dec527a1ad9d1b2c4125834780ffc1d974eac20ea213cf6be0077606e843c3933dda53044ce7547b89fb1b280d4d87aeee87e759f1c7440f5bb47d3efe600722660de884c6a134fed48d2e8f6a51410b51ff016caed31c869ffdcf568062c7350b013e8c84a29da36eb304bf6951023af4e5f232e704a31dc24c29e840a92750091bf887191885308bf43133738f62b44d56728c12f6c6178b36fa1319074a8eed38e1b70ab27c87bdacd01a7b5a8487689eb919a1a2d0f6772514cb4d74bcf083e8a3c1e3c631b27ed37915f9a9ebd9227578c8d34bcf170a83163e703c2cfa6339c76d892ffc0c61a23bf2bfcc06addcd9497a958ac2291f246bd3fd7c110d88f0c582df7331b1f18a2e4c4c313ea9d9ac0fb46cce3354a99eb8c5a8503c6dff1d569b5c6986de6bd4dac3ada01a736a9f0b49bd162f143f7626e3fe11042d705016ebbaf04d0d9e419e702cd1fe41bc488c7a4575cc31dbf6eea06e82e7411f64842085f1e2654b7b88cfb069470ed1396471e28bc8ee2d749b6c2a632d8a0079d7295392ad6e20ba4160e605298cf7fb4c621ceb9d9d3684eefcb6bbf261fe210748e464e0541f64702c6171479161dc3d2188e09e360683bc39a542ebb4d539491a212713b1b7bb53fa573832f533432449a541c45626ef6b508717b49d74df1f95cd51a6dad194194075b7fb69b56ae801a72e9545174a8f68320a8a206374e78c113f663560ef9be9f1b87d04a4790d3143faa6dad194194075b7fb69b56ae801a72e054104c22053e020bffb2e7862886569,0x82a1e878c5ac69376cb8b60f78d0d878,0x9e0c3309c8fb9a2c9e37ecda3339171b,NULL,0x98921d7f2f14db1696e3ea036f2ffc2d,NULL),(2,0xfd4e0185cda7d53c019816624babc1d1dd47ccec68364ff519c0e9a6850deac378eb4505647f2eaef7e764adf5f44bf7fd4e0185cda7d53c019816624babc1d1fd4e0185cda7d53c019816624babc1d194157727f74fd79d5fdaa1adafca86b9d02bb7d6b512814cb8de26479437c6ad3d0dd0f7b69b0d49445202079c46b3028a01ea867bc19bad2dbb6c2cf9a07942838557fa287e17c961c20ceda1473f0cad329c3d8dc8003567c5a6fe221f6b51925da72adcdc58361d2a6193450df3d16337fc1fccc0e26e5154e5857c8622104c6ae9d0822bf6520ed9576c350ae90264876549b5d5b6cfb2668deaaf3c12b7c6a6aa7eb6fbe13bf15305ea49caf04e2554a7bceb5ea2092cdfa161f7fc6ca871596e89b3cd3dd61d125028011709c091da944eade5bfd24bc68a933afcddc070ed59e3d67e98f792d988a85822047e5f3244f6d97938fc98db6be54774f5651d48df3f84abc0bf2911ef50e2d7e4b1de3e353102da9f75ec2c26d751a5aee740fe40ffe7c4825f015e74377ad5f5657af9d3f617bf3839ea1cec0c5f2bd2b7055efae625d4ee4e5fc9fcd04cdae3e9fa56f99a93ae81159c32f68372decca0c2333f3a59456efee523a7918538ea3d3de96cb8bc1e089e4c4d60f80c9d35818bebb392651af88fd56608f63fc5607cc8bc5afcb3c937c64a462545d618755880d02e00ec0c447b5d87e179ae9d58a4be18c1f1e9e985ad798810eaab4308fc69d76cb14ec9531cdbae6ad6e1f315a706f66244ce825d2e7d76204be414f340d6a13ddbe49098d964056f3ab3c08d9e320f60bd19d13e48b00d74e406206aeadd5f32a811aa3cf5c972aedd336ce27dada9a9f394647a783019068320544568d0ae153e426934769fa3ceed8daafabe33bbc73a9d49232d0162dcfae9426769a98fd5a275d988098f03f73c65f57f66c448176bf9dc3e8afb1117bfd1808c07a19d762348c4c5b6b490cc74f0a643e2d633e08b25f61553a071d8e44f60ed5ac1c23524cddb45a141f8c660aa33af8b5c545a4d1b36eec62287c09abef442316ce7b91955b4b2da278223e2fbb01005357f9e077af440347a59021ad7db0f6684ad123509166f7e87fcd8e3c29d6da398c76e6792f74ba26962fbd2eefafef4ffe940c778807cd0b8b00733fbade0cdc0c12d78f2541dee9b72494982615b86b8614452e524d315aee9b5d0eb03ff9f9cd00cd3cbd9018365bf116b3a21a112ad514aacb6fdd5634e6b74e3ba6235c113626434c8558b183059ab234be932aa3f23bb685f2d357445edb2d2d4bffce907f078119eeef2b81079f3d581a68d75df22caddf5b84b487cba678b16ecedaa082e51002418d75fa61b4444a88e71fa7d63b902187188889fe18894c282433ed896a6add0d661dbd33c3b01f35518067dbf246e5dff22b797a0844da86a5f063b363bfc8420681dfa6aa30064c59c5a94b03652337a9e63b4b3cd8be8477fbed0285344ff60d18eecfdaff4a220fa10f4267e0721f7d40f1417eb8cea3c8cf575669046b07ac64a27b8eb5ade65b97d81b28685a28cc54ad94f09cac09afe32ecff917976a63177071810356af3c217bd4c155b978648f82eb51267959e37ef8106fc4a8a43af035e12c751f3230cd3c3ff8f60edb58ff62bcd73f3b81cafee8c22ab0552a50535f1dbb89a1e5ad9304a8c2ce656bb5d775fa73c894cd7cd478d8f4be1d1d7961464f845cfb598ee9ed7b7d2dfc92bc85ca71c3252a6d5324a6f267d973a08255ea8994829b614e2d2235b2e2058bde34ba6aefd0f6b651fc4fd4e0185cda7d53c019816624babc1d1db020f74f4b0b4b4969a870b0c3901bd181945f57436d65f02aaad7fc42ccc8bfd4e0185cda7d53c019816624babc1d19beca2392b2ba10a544bb1362b5e9e18,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x5b61acf23088a2214d164d7524a6193e,NULL);
/*!40000 ALTER TABLE `servers` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `settings`
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `name` varchar(256) NOT NULL DEFAULT '',
  `address` text,
  `county` varchar(256) NOT NULL DEFAULT '',
  `town` varchar(256) NOT NULL DEFAULT '',
  `phone` varchar(256) NOT NULL DEFAULT '',
  `other_phones` varchar(256) NOT NULL DEFAULT '',
  `email` varchar(256) NOT NULL DEFAULT '',
  `sender_id` varchar(256) NOT NULL DEFAULT '',
  `sms_initial` varchar(256) NOT NULL DEFAULT '',
  `member_code_initial` varchar(256) NOT NULL DEFAULT '',
  `file` varchar(256) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table `settings`
LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,1325624400,'Smart Churches','Box 12548','Nairobi','Umoja','(072) 134-1214','0205285243/07213584587','info@smartchurch.com','M-SHAMBA','Hello','NK','neno.png',1,1,1422976879,1480332608);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `sms`
DROP TABLE IF EXISTS `sms`;
CREATE TABLE `sms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient` varchar(32) NOT NULL DEFAULT '',
  `status` int(11) DEFAULT NULL,
  `cost` int(11) DEFAULT NULL,
  `group_type` varchar(50) DEFAULT NULL,
  `sent_to` varchar(50) DEFAULT NULL,
  `message` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Dumping data for table `sms`
LOCK TABLES `sms` WRITE;
/*!40000 ALTER TABLE `sms` DISABLE KEYS */;
INSERT INTO `sms` VALUES (1,'35',1,NULL,'A65A1967A/10/16','church member','Hi Samuel, we thank you for choosing to become a member of our church. Your Membership Code is MLC-035',1,NULL,1477037786,NULL),(2,'36',1,NULL,'7A3B162BB/10/16','church member','Hi Lincoln, we thank you for choosing to become a member of our church. Your Membership Code is MLC-036',1,NULL,1477039142,NULL),(3,'37',1,NULL,'8BA1315A1/11/16','church member','Hi Fredrick, we thank you for choosing to become a member of our church. Your Membership Code is MLC-037',1,NULL,1479807324,NULL),(4,'35',1,NULL,'33856771A/11/16','church member','Hello Samuel, Confirmed your Tithe 56,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1479810753,NULL);
/*!40000 ALTER TABLE `sms` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `sms_counter`
DROP TABLE IF EXISTS `sms_counter`;
CREATE TABLE `sms_counter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` blob,
  `balance` blob,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table `sms_counter`
LOCK TABLES `sms_counter` WRITE;
/*!40000 ALTER TABLE `sms_counter` DISABLE KEYS */;
INSERT INTO `sms_counter` VALUES (1,'',0x82a1e878c5ac69376cb8b60f78d0d878,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343231323432353139,0x046d4bb491944a59284865f26da11488);
/*!40000 ALTER TABLE `sms_counter` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `sms_subscriptions`
DROP TABLE IF EXISTS `sms_subscriptions`;
CREATE TABLE `sms_subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member` varchar(32) NOT NULL DEFAULT '',
  `bible_quotes` varchar(32) NOT NULL DEFAULT '',
  `daily_inspirations` varchar(32) NOT NULL DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `sms_subscriptions`
LOCK TABLES `sms_subscriptions` WRITE;
/*!40000 ALTER TABLE `sms_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `ss_parents`
DROP TABLE IF EXISTS `ss_parents`;
CREATE TABLE `ss_parents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `child_id` int(11) NOT NULL DEFAULT '0',
  `first_name` varchar(256) NOT NULL DEFAULT '',
  `last_name` varchar(256) NOT NULL DEFAULT '',
  `gender` varchar(256) NOT NULL DEFAULT '',
  `relationship` varchar(256) NOT NULL DEFAULT '',
  `phone1` varchar(256) NOT NULL DEFAULT '',
  `phone2` varchar(256) NOT NULL DEFAULT '',
  `email` varchar(256) NOT NULL DEFAULT '',
  `address` text,
  `county` varchar(256) NOT NULL DEFAULT '',
  `location` varchar(256) NOT NULL DEFAULT '',
  `additionals` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `ss_parents`
LOCK TABLES `ss_parents` WRITE;
/*!40000 ALTER TABLE `ss_parents` DISABLE KEYS */;
/*!40000 ALTER TABLE `ss_parents` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `sunday_school`
DROP TABLE IF EXISTS `sunday_school`;
CREATE TABLE `sunday_school` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_joined` int(11) DEFAULT NULL,
  `first_name` varchar(256) NOT NULL DEFAULT '',
  `last_name` varchar(256) NOT NULL DEFAULT '',
  `dob` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `gender` varchar(256) NOT NULL,
  `relationship` varchar(256) NOT NULL,
  `home_phone` varchar(256) NOT NULL,
  `baptised` varchar(256) NOT NULL,
  `confirmed` varchar(256) NOT NULL,
  `how_joined` varchar(256) NOT NULL,
  `residential` varchar(256) NOT NULL,
  `special_interest` text,
  `strengths` text,
  `weaknesses` text,
  `health` text,
  `passport` varchar(256) NOT NULL DEFAULT '',
  `additionals` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `sunday_school`
LOCK TABLES `sunday_school` WRITE;
/*!40000 ALTER TABLE `sunday_school` DISABLE KEYS */;
/*!40000 ALTER TABLE `sunday_school` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `take_stock`
DROP TABLE IF EXISTS `take_stock`;
CREATE TABLE `take_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `asset_name` varchar(32) NOT NULL DEFAULT '',
  `remaining_stock` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `take_stock`
LOCK TABLES `take_stock` WRITE;
/*!40000 ALTER TABLE `take_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `take_stock` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `task_manager`
DROP TABLE IF EXISTS `task_manager`;
CREATE TABLE `task_manager` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL DEFAULT '',
  `date` int(11) DEFAULT NULL,
  `status` varchar(32) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `task_manager`
LOCK TABLES `task_manager` WRITE;
/*!40000 ALTER TABLE `task_manager` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_manager` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `tax_config`
DROP TABLE IF EXISTS `tax_config`;
CREATE TABLE `tax_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `amount` varchar(256) NOT NULL DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Dumping data for table `tax_config`
LOCK TABLES `tax_config` WRITE;
/*!40000 ALTER TABLE `tax_config` DISABLE KEYS */;
INSERT INTO `tax_config` VALUES (1,'PAYE','16',1,NULL,1422346949,NULL),(2,'VAT','16',1,NULL,1422346949,NULL);
/*!40000 ALTER TABLE `tax_config` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `thanks_giving`
DROP TABLE IF EXISTS `thanks_giving`;
CREATE TABLE `thanks_giving` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` blob,
  `member` blob NOT NULL,
  `amount` blob NOT NULL,
  `bank` blob NOT NULL,
  `totals` blob,
  `treasurer` blob NOT NULL,
  `confirmed_by` blob NOT NULL,
  `description` blob,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `thanks_giving`
LOCK TABLES `thanks_giving` WRITE;
/*!40000 ALTER TABLE `thanks_giving` DISABLE KEYS */;
/*!40000 ALTER TABLE `thanks_giving` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `tithes`
DROP TABLE IF EXISTS `tithes`;
CREATE TABLE `tithes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` blob,
  `bank` blob NOT NULL,
  `treasurer` blob NOT NULL,
  `confirmed_by` blob NOT NULL,
  `totals` blob,
  `description` blob,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table `tithes`
LOCK TABLES `tithes` WRITE;
/*!40000 ALTER TABLE `tithes` DISABLE KEYS */;
INSERT INTO `tithes` VALUES (1,0x736b2e8669ff95286121478d326a2249,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xb60a11bc1479d6ea3a771e2ef2de261e,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xd06282a3728651e29f20a3c9299879e8,NULL);
/*!40000 ALTER TABLE `tithes` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `users`
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` blob NOT NULL,
  `ip_address` blob NOT NULL,
  `username` blob NOT NULL,
  `password` blob NOT NULL,
  `salt` blob,
  `email` blob NOT NULL,
  `activation_code` blob,
  `first_name` blob,
  `last_name` blob,
  `phone` blob,
  `forgotten_password_code` blob,
  `remember_code` blob,
  `created_on` blob NOT NULL,
  `last_login` blob,
  `active` blob,
  `bio` blob,
  `created_by` blob,
  `modified_by` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table `users`
LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x8dae8c71f911eac0f2518c609acbb13d,0xb0c6204d92e820bdd9b382d8f6192146,0x059b467b01ba3fd865e8feb1b2ca42072ad4141ee4f3dce0c84dac22afdc111008fa455c9d750adcf2fffdc05312ee1e,0x71bf490a36d1388798efa45f3873a254,0x0eb8f055b6c50c5edf71649a9f86bab2,0xa545acd59a5c75d85e429545b1b87e8a,0xf50a452dbb53f438439b1b253706ce71,0x9f58d531d84034ba1bb50f1b0aa21762,0x9833ba881c4ec01e0d747c21f7c0aeb5,0xa545acd59a5c75d85e429545b1b87e8a,0x64373366363036663536323265333332343632356632356631643937636238356532636330663636,0x88f2ac67959d408673ab63a7f8c52f58,0x31343830333332333835,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x632373b1cbe3a80f4e1619f3947b75c3),(2,0x90065fe9ea51973a4989393c1f3a44af,0xc1bd6816ef79c1356cc4b0bbfc854dbb,0x8629a24cd97c1d65a5a83a231cb02e39,0x8b70659aa8ceed8c2ccbe5989e224328aa9e81e19f84de5ee9a8568114236ae809e1f026f77e366f588efb76ef24ac68,NULL,0x3b4a47c5142a37811e62169a0c859e82,NULL,0xcb636b55031f4c3018f7ca4575b02a68,0xd9f2b1da7a7a12e073d0f17a0f6e3544,0xd623a851185391639992510f2d3a00b3,NULL,NULL,0x83001a6f31c4d7f2d2d37b23d9d8e1c8,0x31343331343338383130,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x840a763dbf80755b8e274cf14afd990f),(3,0x90065fe9ea51973a4989393c1f3a44af,0xc1bd6816ef79c1356cc4b0bbfc854dbb,0xddcab4581f1eb4a2f02b536fe64d7f79,0x452f6f4f3bd6b8fd5370d2caca2201edec12f1035bc44cadb996b0dc851aa146bba25c205bbc06ddfe954ef5959c1fbf,NULL,0xab20d12201cf113367c690a73bbca206,NULL,0xf3abfa7a76633a5696999bccb966e2ad,0xd9f2b1da7a7a12e073d0f17a0f6e3544,0x0b71b5c0abbc69717e2cca0d71d38d98,NULL,NULL,0x7f4024d92f831b5ccaac4ddcfb8f80c5,0x31343139393336353533,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x3609c9ec305d6885f239a8fd352b0449),(4,0x90065fe9ea51973a4989393c1f3a44af,0x8dae8c71f911eac0f2518c609acbb13d,0xf01ff376ba4fbbe5b2fbafc61d432f74,0x02c5d4b49db5bc5d5d9966c8b1f62b05d468d34fb23e79e1212e2ffe3c416e8ed1319fe6fc7111cc51e844472c6b4690,NULL,0x155fbd3edae4dda9c375cfc2e3576dce,NULL,0x5a67f3de2994745c6cb4c3360f6a1ef0,0xb9bf66345da59b8a0cf2216b3e9994aa,0xe5cc65b19014c41f8496fe5904d8b9e8,NULL,NULL,0xbc522691e6c9fbe9c83126e88d8821dc,0xbc522691e6c9fbe9c83126e88d8821dc,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x8da3c85600c8c494d025d768beb4b76f);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `users_groups`
DROP TABLE IF EXISTS `users_groups`;
CREATE TABLE `users_groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` blob NOT NULL,
  `group_id` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- Dumping data for table `users_groups`
LOCK TABLES `users_groups` WRITE;
/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
INSERT INTO `users_groups` VALUES (10,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d),(13,0xcfa10a53ac284db808f6bedd952eb03d,0xcfa10a53ac284db808f6bedd952eb03d),(14,0xcfa10a53ac284db808f6bedd952eb03d,0x90065fe9ea51973a4989393c1f3a44af),(16,0xcdf3a1cb3f3ee08d0e0c63e679397c3a,0x90065fe9ea51973a4989393c1f3a44af),(17,0x90065fe9ea51973a4989393c1f3a44af,0xcdf3a1cb3f3ee08d0e0c63e679397c3a);
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `video_sermons`
DROP TABLE IF EXISTS `video_sermons`;
CREATE TABLE `video_sermons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL DEFAULT '',
  `value` varchar(256) NOT NULL DEFAULT '',
  `file` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `video_sermons`
LOCK TABLES `video_sermons` WRITE;
/*!40000 ALTER TABLE `video_sermons` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_sermons` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `visitors`
DROP TABLE IF EXISTS `visitors`;
CREATE TABLE `visitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `visit_date` int(11) DEFAULT NULL,
  `first_name` varchar(256) NOT NULL DEFAULT '',
  `last_name` varchar(256) NOT NULL DEFAULT '',
  `gender` varchar(256) NOT NULL DEFAULT '',
  `phone` varchar(256) NOT NULL DEFAULT '',
  `email` varchar(256) NOT NULL DEFAULT '',
  `county` varchar(256) NOT NULL DEFAULT '',
  `location` varchar(256) NOT NULL DEFAULT '',
  `directed_by` varchar(256) NOT NULL DEFAULT '',
  `interested_in_membership` int(1) NOT NULL,
  `saved` int(1) NOT NULL,
  `baptised` int(1) NOT NULL,
  `know_more` int(1) NOT NULL,
  `ministries_interest` int(1) NOT NULL,
  `come_back` int(1) NOT NULL,
  `additionals` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `visitors`
LOCK TABLES `visitors` WRITE;
/*!40000 ALTER TABLE `visitors` DISABLE KEYS */;
/*!40000 ALTER TABLE `visitors` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `weddings`
DROP TABLE IF EXISTS `weddings`;
CREATE TABLE `weddings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wedding_date` int(11) DEFAULT NULL,
  `bride` varchar(32) NOT NULL DEFAULT '',
  `bridegroom` varchar(32) NOT NULL DEFAULT '',
  `venue` varchar(256) NOT NULL DEFAULT '',
  `status` varchar(32) NOT NULL DEFAULT '',
  `brief_description` text,
  `wedding_photo` varchar(256) NOT NULL DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `weddings`
LOCK TABLES `weddings` WRITE;
/*!40000 ALTER TABLE `weddings` DISABLE KEYS */;
/*!40000 ALTER TABLE `weddings` ENABLE KEYS */;
UNLOCK TABLES;

-- Dump completed on: Mon, 28 Nov 2016 14:35:37 +0300
