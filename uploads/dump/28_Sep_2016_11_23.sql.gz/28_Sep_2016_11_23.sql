-- HMS DATABASE BACKUP UTILITY 
--
-- Host: localhost	Database: kanisa
--------------------------------------------------------
-- Server version 	5.6.26
-- Backup By:  Super (1) ***** Date: Wed, 28 Sep 2016 11:23:43 +0300

-- Current Database: `kanisa`
--
/*!40000 DROP DATABASE IF EXISTS `kanisa`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `kanisa` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci*/;

USE `kanisa`;

-- Table structure for table `account_types`
DROP TABLE IF EXISTS `account_types`;
CREATE TABLE `account_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `campus_id` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table `account_types`
LOCK TABLES `account_types` WRITE;
/*!40000 ALTER TABLE `account_types` DISABLE KEYS */;
INSERT INTO `account_types` VALUES (1,'Equity','Equity',1,NULL,NULL,1405932029,NULL),(2,'Fixed Assets','',1,NULL,1,1405932181,1405932307),(3,'Non-current Liabilities','',1,NULL,1,1405932217,1405932322),(4,'Current Liabilities','',1,NULL,1,1405932229,1405932338),(5,'Current Assets','',1,NULL,NULL,1405932256,NULL),(6,'Expenses','',1,NULL,NULL,1405932285,NULL),(7,'Revenue','',1,NULL,NULL,1405932295,NULL);
/*!40000 ALTER TABLE `account_types` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `accounts`
DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` blob NOT NULL,
  `code` blob NOT NULL,
  `account_type` blob NOT NULL,
  `tax` blob NOT NULL,
  `balance` blob NOT NULL,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table `accounts`
LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (1,0xf0fbd9a9c8a3f3b4cf9460dfe97a4725,0x92f8c2e50395bf6b4400885fc7d87c5f,0xe1f7f7bd788a5ed3d65a0a992e1f5f52,0x82a1e878c5ac69376cb8b60f78d0d878,0x82a1e878c5ac69376cb8b60f78d0d878,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x153ce6a396cae4c1b30689e4416eed78,NULL),(2,0x99161f00503f3cf8d40e53ee75b5577f,0xf6f58e1247c4acddaf343371d8555616,0xe1f7f7bd788a5ed3d65a0a992e1f5f52,0x82a1e878c5ac69376cb8b60f78d0d878,0x82a1e878c5ac69376cb8b60f78d0d878,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x1aaed38a2e241759e3e764a3292740bc,NULL),(3,0x3892c37e33385119b98bb54b2acb2403,0xa6839df257d5fe9b3b394d693831b27c,0xe1f7f7bd788a5ed3d65a0a992e1f5f52,0x82a1e878c5ac69376cb8b60f78d0d878,0x82a1e878c5ac69376cb8b60f78d0d878,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa932b52d42ea2e770e8977d3a2be2cfa,NULL),(4,0x060c12b55a90967950dc7ab4bb5ff25728500f8f0d4f4eaf68ea7ca7d82839ef,0x71828812c5fcd2861720ccf6ed5219c3,0xe1f7f7bd788a5ed3d65a0a992e1f5f52,0x82a1e878c5ac69376cb8b60f78d0d878,0x82a1e878c5ac69376cb8b60f78d0d878,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x0338cda639519e107b0302f0e9bd6e47,NULL),(5,0x8a4e8d3a08f6d1b13c13e84dee6b8130,0x2d305cba0fc70b97eb1085705a0ecfa4,0xe1f7f7bd788a5ed3d65a0a992e1f5f52,0x82a1e878c5ac69376cb8b60f78d0d878,0x82a1e878c5ac69376cb8b60f78d0d878,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x6a5c289e0209ee9a4c2df1697ee79e2d,NULL),(6,0x317fb74cf3867c449d7ae1a392bf70f1,0x44f7af09ebe016b8cbd4f8c572b723d1,0xe1f7f7bd788a5ed3d65a0a992e1f5f52,0x82a1e878c5ac69376cb8b60f78d0d878,0x82a1e878c5ac69376cb8b60f78d0d878,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xca98a9147faec9615ad1868c79cbb1f5,NULL),(7,0x15f8f18a9518eaee0cf53fd5ea9315f8a545acd59a5c75d85e429545b1b87e8a,0x5e0226a04dcf6a85dde3c79781976f06,0xe1f7f7bd788a5ed3d65a0a992e1f5f52,0x82a1e878c5ac69376cb8b60f78d0d878,0x82a1e878c5ac69376cb8b60f78d0d878,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa827243e0f8d19538c0aa17e7897633b,NULL),(8,0xe691b6a71baf0856c4f4e302d99e0e98,0xe52889c8eef9c547a439f203649309cc,0xe1f7f7bd788a5ed3d65a0a992e1f5f52,0x82a1e878c5ac69376cb8b60f78d0d878,0x82a1e878c5ac69376cb8b60f78d0d878,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x46a29313cdf16cafa344f4bf57daa72a,NULL),(9,0x68512c753282f04742dee29d1e5bd3a1,0x5a1c3b28eeaf3f6cab6f9f0ca134c33f,0xe2a390b58325c1cf93f752183e0090a4,0x82a1e878c5ac69376cb8b60f78d0d878,0x82a1e878c5ac69376cb8b60f78d0d878,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x894d6794cb70f7a76e1a61ac1ad05df2,0x32a94b807db6e48d692e570a81d64515),(10,0xbeccd2b9c4e43bb7bd7762c7e0ba3b80,0x150fae481aba89526fe54da4794da63f,0xe2a390b58325c1cf93f752183e0090a4,0x82a1e878c5ac69376cb8b60f78d0d878,0x82a1e878c5ac69376cb8b60f78d0d878,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xbbb42a17814e144af4e459d4b7baa9d2,NULL),(11,0x23dbb418c503c9ac5db73de1202d0a0b,0xcfc934fc14af9bd05b7dc721d49008e3,0x90065fe9ea51973a4989393c1f3a44af,0x82a1e878c5ac69376cb8b60f78d0d878,0x82a1e878c5ac69376cb8b60f78d0d878,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x5b2c47e40fc21e1661a985f91ca19caa,NULL);
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `address_book`
DROP TABLE IF EXISTS `address_book`;
CREATE TABLE `address_book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address_book` varchar(256) NOT NULL DEFAULT '',
  `category` varchar(32) NOT NULL DEFAULT '',
  `contact_person` varchar(256) NOT NULL DEFAULT '',
  `business_name` varchar(256) NOT NULL DEFAULT '',
  `phone` varchar(256) NOT NULL DEFAULT '',
  `email` varchar(256) NOT NULL DEFAULT '',
  `address` text,
  `additional_info` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Dumping data for table `address_book`
LOCK TABLES `address_book` WRITE;
/*!40000 ALTER TABLE `address_book` DISABLE KEYS */;
INSERT INTO `address_book` VALUES (1,'suppliers','1','Lorry Moja','The Lorry','07215487458','lory@lories.com','Box 12548','Nothing',1,1,1422102673,1422109721),(2,'suppliers','3','Sony Ken','Sony Kenya','072154878','sony@sony.co.ke','Box 125488 Nairobi','',1,NULL,1423394826,NULL),(3,'suppliers','4','Jim Kanner','Jim & sons','0721341214','jim@gmail.com','Box 12548','',1,NULL,1426251096,NULL),(4,'suppliers','3','Orange Kenya','Orange Kenya','07215487458','info@orange.com','Box 125488','',1,NULL,1426251316,NULL);
/*!40000 ALTER TABLE `address_book` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `address_book_category`
DROP TABLE IF EXISTS `address_book_category`;
CREATE TABLE `address_book_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Dumping data for table `address_book_category`
LOCK TABLES `address_book_category` WRITE;
/*!40000 ALTER TABLE `address_book_category` DISABLE KEYS */;
INSERT INTO `address_book_category` VALUES (1,'Stationary','0',1,NULL,1422102482,NULL),(2,'Foodstuff','0',1,NULL,1422102617,NULL),(3,'Electronics','0',1,NULL,1423387766,NULL),(4,'Realestate','0',1,NULL,1426250628,NULL),(5,'Individual','0',1,NULL,1426250652,NULL);
/*!40000 ALTER TABLE `address_book_category` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `advance_salary`
DROP TABLE IF EXISTS `advance_salary`;
CREATE TABLE `advance_salary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee` varchar(256) NOT NULL DEFAULT '',
  `advance_date` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `amount` varchar(256) NOT NULL DEFAULT '',
  `comment` text NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table `advance_salary`
LOCK TABLES `advance_salary` WRITE;
/*!40000 ALTER TABLE `advance_salary` DISABLE KEYS */;
INSERT INTO `advance_salary` VALUES (1,'2',1422306000,0,'5000','Test',1,1,1422278237,1433765499);
/*!40000 ALTER TABLE `advance_salary` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `allocations`
DROP TABLE IF EXISTS `allocations`;
CREATE TABLE `allocations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `ministry` varchar(32) NOT NULL DEFAULT '',
  `amount` double DEFAULT NULL,
  `approved_by` varchar(32) NOT NULL DEFAULT '',
  `confirmed_by` varchar(32) NOT NULL DEFAULT '',
  `expenditure` double DEFAULT NULL,
  `balance` double DEFAULT NULL,
  `description` text,
  `comment` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Dumping data for table `allocations`
LOCK TABLES `allocations` WRITE;
/*!40000 ALTER TABLE `allocations` DISABLE KEYS */;
INSERT INTO `allocations` VALUES (1,1432414800,1,'3',45000,'2','3',NULL,NULL,'Approved',NULL,1,1,1432660226,1432707084),(2,1432414800,1,'1',28000,'3','2',24500,3500,'This is the amount approved','Spent well',1,1,1432717190,1432798251),(3,1432414800,1,'2',7500,'2','3',4500,3000,'This is the allocation','This is what they spent',1,1,1432798639,1433602101),(4,1434229200,1,'2',45000,'2','3',NULL,NULL,'This is the amount given',NULL,1,NULL,1433602147,NULL),(5,1435006800,1,'1',85000,'2','3',55000,45000,'Banked','this was what was used',1,1,1433679467,1433767526),(6,1461013200,1,'2',125000,'2','3',NULL,NULL,'Given',NULL,1,NULL,1461075613,NULL);
/*!40000 ALTER TABLE `allocations` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `allowances`
DROP TABLE IF EXISTS `allowances`;
CREATE TABLE `allowances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `amount` varchar(256) NOT NULL DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Dumping data for table `allowances`
LOCK TABLES `allowances` WRITE;
/*!40000 ALTER TABLE `allowances` DISABLE KEYS */;
INSERT INTO `allowances` VALUES (2,'Travelling Allowance','10000',1,NULL,1422273112,NULL);
/*!40000 ALTER TABLE `allowances` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `announcements`
DROP TABLE IF EXISTS `announcements`;
CREATE TABLE `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `title` varchar(256) NOT NULL DEFAULT '',
  `status` varchar(32) NOT NULL DEFAULT '',
  `file` varchar(32) NOT NULL,
  `brief_description` text,
  `upload_announcements` varchar(256) NOT NULL DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- Dumping data for table `announcements`
LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
INSERT INTO `announcements` VALUES (1,1424120400,'Sunday School Event','1','','There will be event for Sunday school children. Church committee to remain for a meeting after service','',1,1,1423133334,1431628748),(2,1424725200,'Youth Meeting','1','Brochure_Modules.docx','There will be youth meeting next week in church hall. Church committee to remain for a meeting after service','',1,1,1423134137,1431628731),(3,1424898000,'Committee Meeting','1','','Church committee to remain for a meeting after service.Church committee to remain for a meeting after service','',1,1,1423134219,1431628719),(4,1431550800,'System Launch','1','','New system launch We have tried our best in working on the Unit Economics.We are ready for the call tomorrow afternoon as discussed','',1,NULL,1431628667,NULL),(5,1431810000,'Camp Registration','1','','Good morning?Am writing to apply for a post in the IT department of your organization. I was referred to you by Simon Gicharu of  0713272546 Kindly find attached copies of my relevant credentials. Thank you.','',1,NULL,1431634674,NULL),(6,1431810000,'Youth Camp','1','','Good morning?Am writing to apply for a post in the IT department of your organization. I was referred to you by Simon Gicharu of  0713272546\r\nKindly find attached copies of my relevant credentials.\r\nThank you.','',1,NULL,1431634696,NULL),(7,1431810000,'Leaders Meeting','1','','Happy Sunday ?Am writing to apply for a post in the IT department of your organization. I was referred to you by Simon Gicharu of  0713272546\r\nKindly find attached copies of my relevant credentials.\r\nThank you.','',1,NULL,1431634726,NULL),(8,1431810000,'Visitor Registration','1','','Happy Sabbath. Am writing to apply for a post in the IT department of your organization.Kindly find attached copies of my relevant credentials.\r\nThank you.','',1,NULL,1431634815,NULL);
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `asset_category`
DROP TABLE IF EXISTS `asset_category`;
CREATE TABLE `asset_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Dumping data for table `asset_category`
LOCK TABLES `asset_category` WRITE;
/*!40000 ALTER TABLE `asset_category` DISABLE KEYS */;
INSERT INTO `asset_category` VALUES (1,'Electronics','Electronics',1,NULL,1423382370,NULL),(2,'Furniture','Furniture',1,1,1423382370,1423382488),(3,'Vehicle','All Vehicles',1,NULL,1423387304,NULL),(4,'Machines','Machines',1,NULL,1426250330,NULL),(5,'Building','Building',1,NULL,1426250331,NULL);
/*!40000 ALTER TABLE `asset_category` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `asset_items`
DROP TABLE IF EXISTS `asset_items`;
CREATE TABLE `asset_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- Dumping data for table `asset_items`
LOCK TABLES `asset_items` WRITE;
/*!40000 ALTER TABLE `asset_items` DISABLE KEYS */;
INSERT INTO `asset_items` VALUES (1,'Microphone','Microphone',1,1,1,1423384699,1423385334),(2,'Amplifier','Amplifier',1,1,1,1423384699,1423385324),(3,'Chair','Chair',1,2,1,1423384699,1423385309),(4,'Church Van','Van',1,3,NULL,1423387512,NULL),(5,'Church Building','Church Building',1,5,NULL,1426250548,NULL),(6,'Church Machine','Church Machine',1,5,NULL,1426250549,NULL),(7,'Speakers','Speakers',1,1,NULL,1426251246,NULL),(8,'Computers','Computers',1,1,NULL,1426251246,NULL),(9,'Internet Modem','Internet Modem',1,1,NULL,1426251246,NULL);
/*!40000 ALTER TABLE `asset_items` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `asset_stock`
DROP TABLE IF EXISTS `asset_stock`;
CREATE TABLE `asset_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `supplier` varchar(32) NOT NULL DEFAULT '',
  `item` varchar(32) NOT NULL DEFAULT '',
  `quantity` varchar(256) NOT NULL DEFAULT '',
  `unit_price` varchar(256) NOT NULL DEFAULT '',
  `total` varchar(256) NOT NULL DEFAULT '',
  `person_responsible` varchar(32) NOT NULL DEFAULT '',
  `file` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- Dumping data for table `asset_stock`
LOCK TABLES `asset_stock` WRITE;
/*!40000 ALTER TABLE `asset_stock` DISABLE KEYS */;
INSERT INTO `asset_stock` VALUES (1,1424120400,'1','4','1','1500000','1500000.00','3','Brochure_Modules1.docx','New stock',1,NULL,1423391574,NULL),(2,1423602000,'2','2','2','18000','36000.00','2','','This is another stock',1,NULL,1423403218,NULL),(3,1425243600,'3','5','1','1500000','1500000.00','2','','Was paid in full',1,NULL,1426251140,NULL),(4,1426539600,'4','9','1','12500','12500.00','2','','Was paid in full',1,NULL,1426251356,NULL),(5,1425934800,'2','7','5','28000','140000.00','2','','Paid with cheque',1,NULL,1426251406,NULL),(6,1423602000,'2','7','2','20000','40000.00','2','','Paid in full',1,NULL,1426260600,NULL),(7,1433624400,'2','2','4','40000','160000.00','4','','',1,NULL,1433679822,NULL),(8,1436821200,'3','2','2','25000','50000.00','2','','ereerr',1,NULL,1437551883,NULL);
/*!40000 ALTER TABLE `asset_stock` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `bank_accounts`
DROP TABLE IF EXISTS `bank_accounts`;
CREATE TABLE `bank_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(256) NOT NULL DEFAULT '',
  `account_name` varchar(256) NOT NULL DEFAULT '',
  `account_number` varchar(256) NOT NULL DEFAULT '',
  `branch` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Dumping data for table `bank_accounts`
LOCK TABLES `bank_accounts` WRITE;
/*!40000 ALTER TABLE `bank_accounts` DISABLE KEYS */;
INSERT INTO `bank_accounts` VALUES (1,'Equity Bank','Kanisa Account','10201300','Buruburu','This is bank account',1,NULL,1421246650,NULL),(2,'Barclays Bank','Members','201030125','Umoja','This is another bank',1,NULL,1421246690,NULL);
/*!40000 ALTER TABLE `bank_accounts` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `baptism`
DROP TABLE IF EXISTS `baptism`;
CREATE TABLE `baptism` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `member` varchar(32) NOT NULL DEFAULT '',
  `ff_name` varchar(256) NOT NULL DEFAULT '',
  `fl_name` varchar(256) NOT NULL DEFAULT '',
  `father_religion` varchar(256) NOT NULL DEFAULT '',
  `father_phone` varchar(256) NOT NULL DEFAULT '',
  `father_email` varchar(256) NOT NULL DEFAULT '',
  `father_address` text,
  `mf_name` varchar(256) NOT NULL DEFAULT '',
  `ml_name` varchar(256) NOT NULL DEFAULT '',
  `mother_religion` varchar(256) NOT NULL DEFAULT '',
  `mother_phone` varchar(256) NOT NULL DEFAULT '',
  `mother_email` varchar(256) NOT NULL DEFAULT '',
  `mother_address` text,
  `gff_name` varchar(256) NOT NULL DEFAULT '',
  `gfl_name` varchar(256) NOT NULL DEFAULT '',
  `gf_age` varchar(256) NOT NULL DEFAULT '',
  `gf_phone` varchar(256) NOT NULL DEFAULT '',
  `gf_address` text,
  `gmf_name` varchar(256) NOT NULL DEFAULT '',
  `gml_name` varchar(256) NOT NULL DEFAULT '',
  `gm_age` varchar(256) NOT NULL DEFAULT '',
  `gm_phone` varchar(256) NOT NULL DEFAULT '',
  `gm_address` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Dumping data for table `baptism`
LOCK TABLES `baptism` WRITE;
/*!40000 ALTER TABLE `baptism` DISABLE KEYS */;
INSERT INTO `baptism` VALUES (1,1421528400,0,2,'1','Nick','Munga','Christian','(072) 155-4858','nick@gmail.com','Nothing','Benta','Nyanguaso','Muslim','','benta@gmail.com','Nothing','Steve','Njori','55','(024) 587-8858','Box 125488','Mary','Kens','40','(048) 877-8888','Box 12548','No more info here',1,1,1422022921,1422092374),(2,1421528400,0,1,'22','Njane','Matilda','Christian','(072) 155-4858','nj@gmail.com','None','Lintare','Musso','Christian','','bta@gmail.com','None','Noah','Kimani','38','(075) 885-8885','','','','','','','No more',1,1,1422024644,1422092131);
/*!40000 ALTER TABLE `baptism` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `bible_quotes`
DROP TABLE IF EXISTS `bible_quotes`;
CREATE TABLE `bible_quotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL DEFAULT '',
  `status` varchar(32) NOT NULL DEFAULT '',
  `content` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- Dumping data for table `bible_quotes`
LOCK TABLES `bible_quotes` WRITE;
/*!40000 ALTER TABLE `bible_quotes` DISABLE KEYS */;
INSERT INTO `bible_quotes` VALUES (1,'Blessed','0','God bless you',1,NULL,1423338715,NULL),(2,'Blessed','0','God bless you',1,NULL,1423338731,NULL),(3,'Blessed','0','God bless you',1,NULL,1423338935,NULL),(4,'Blessed','0','God bless you',1,NULL,1423338953,NULL),(5,'Blessed','0','God bless you',1,NULL,1423338978,NULL),(6,'Blessed','0','God bless you',1,NULL,1423339097,NULL),(7,'Blessed','0','Be Blessed',1,NULL,1423339125,NULL),(8,'Blessed','1','This is the message',1,NULL,1423339403,NULL),(9,'Blessed','1','This is the message',1,NULL,1423339502,NULL),(10,'Blessed','1','This is the message',1,NULL,1423339520,NULL);
/*!40000 ALTER TABLE `bible_quotes` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `cfd_parents`
DROP TABLE IF EXISTS `cfd_parents`;
CREATE TABLE `cfd_parents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `child_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(256) NOT NULL DEFAULT '',
  `first_name` varchar(256) NOT NULL DEFAULT '',
  `last_name` varchar(256) NOT NULL DEFAULT '',
  `phone` varchar(256) NOT NULL DEFAULT '',
  `email` varchar(256) NOT NULL DEFAULT '',
  `address` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Dumping data for table `cfd_parents`
LOCK TABLES `cfd_parents` WRITE;
/*!40000 ALTER TABLE `cfd_parents` DISABLE KEYS */;
INSERT INTO `cfd_parents` VALUES (1,1,'Father','Joseph','Mwango','(072) 154-8878','jose@gmail.com','Box 125487',1,NULL,1421919584,NULL),(2,1,'Mother','Mwende','Mwango','072154885825','mwe@gmail.com','Box 1248',1,NULL,1421919584,NULL);
/*!40000 ALTER TABLE `cfd_parents` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `church_projects`
DROP TABLE IF EXISTS `church_projects`;
CREATE TABLE `church_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `county` varchar(32) NOT NULL DEFAULT '',
  `location` varchar(256) NOT NULL DEFAULT '',
  `status` varchar(32) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Dumping data for table `church_projects`
LOCK TABLES `church_projects` WRITE;
/*!40000 ALTER TABLE `church_projects` DISABLE KEYS */;
INSERT INTO `church_projects` VALUES (1,'School','Nairobi','Buruburu','1','church project',1,NULL,1433840269,NULL),(2,'Kindergaten','Nairobi','Umoja','1','School',1,NULL,1433840344,NULL),(3,'Office space','Nairobi','CBD','1','offices',1,NULL,1433840484,NULL);
/*!40000 ALTER TABLE `church_projects` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `collections_log`
DROP TABLE IF EXISTS `collections_log`;
CREATE TABLE `collections_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collection_id` blob,
  `type` blob,
  `amount` blob,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8;

-- Dumping data for table `collections_log`
LOCK TABLES `collections_log` WRITE;
/*!40000 ALTER TABLE `collections_log` DISABLE KEYS */;
INSERT INTO `collections_log` VALUES (1,0x8f40c2b6d1bcf10be77a3a285981f461,0x9300112d60ac061120c538a51c74484a,0x426522ac9dc19da52d214e320b6d4c17,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xdd3535e396a0fea81bf5b3652760327c,NULL),(2,0xcfa10a53ac284db808f6bedd952eb03d,0x3c4da3fb3c2fdc13565410d0b5b296e2,0x916808310ec41533f6584600479bf87c,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xc6f9439b0f3a53cf234d07739038cb6c,NULL),(3,0xf26a9545f4fed2b9ab661c3e645c3a9d,0x90638c6529e9ec277f42086fc9a15839,0x81d487dd187f0a4c42f41b5a9cbf06f8,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x93bd93e5f6521c439f63de858b7491ac,NULL),(4,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x0c57a59e51de5ef2960a3e5e75fdbf7e,0xf2daede898d325f100f90b373938be3d,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xe3a2cadd615dadc792a3f7971d385246,NULL),(5,0xe2a390b58325c1cf93f752183e0090a4,0xf4c584724b1f22a935dbbcb2042dc534,0x140df34bf338c985e14e20fe97e68541,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xcb0518f1b19cdec7eaae0a3098d296d8,NULL),(6,0xcdf3a1cb3f3ee08d0e0c63e679397c3a,0x73b107b94fc388dd6838eeb029c6eaeca545acd59a5c75d85e429545b1b87e8a,0xc32cdd8682fd9f82eb96ecd25fd7d407,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x6e5d4396d225d5d687de8665982b80f9,NULL),(7,0xe2a390b58325c1cf93f752183e0090a4,0xd3aafaae129795965a9fbfe758c4925928500f8f0d4f4eaf68ea7ca7d82839ef,0x532f665f8b9e27b3edf0594508bcbb08,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xcb116fa9524cfc7a934300aefa3d062d,NULL),(8,0xcdf3a1cb3f3ee08d0e0c63e679397c3a,0x3c4da3fb3c2fdc13565410d0b5b296e2,0x209a1d42efa12402299ec744d39cd2ae,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x4df277471664e16e1089f75311c1aeb2,NULL),(9,0x6278d03adb36391e12615a9c8a0fe2dd,0x3c4da3fb3c2fdc13565410d0b5b296e2,0xadb2c68c3de4373e40f5ee7f3c6ca157,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xb23df6d32606debc654cdc22c43d8b46,NULL),(10,0xe2a390b58325c1cf93f752183e0090a4,0x3c4da3fb3c2fdc13565410d0b5b296e2,0xf082a6d0e7258ca8e38c85d360e10933,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xe26592d76af25e1b92f0b27455c98599,NULL),(11,0xe1f7f7bd788a5ed3d65a0a992e1f5f52,0x3c4da3fb3c2fdc13565410d0b5b296e2,0x817f2bb2ca8877e6e1ca5f0b3beed8de,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x1def193f3ed92ebfef3563f3b871e05e,NULL),(12,0xf26a9545f4fed2b9ab661c3e645c3a9d,0x3c4da3fb3c2fdc13565410d0b5b296e2,0x6dd3befa51ae35e17f597cae52940882,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x319a1ef4ba35ef0347870ad95983678c,NULL),(13,0x44e8fada0ff8a584bd931dd1c3ed968a,0x1200f53aa19a76ac97cffa5a3880d04f,0x4c02c00ea1483174e99db0176dbc903e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x7fa3f446389e6cd026dddf2e2573bf4f,NULL),(14,0xf8d16a4f7ddd778e522592b9c7f06593,0x1200f53aa19a76ac97cffa5a3880d04f,0x9d09bd426c25e232a0ef9a2365ff4cb5,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa7b2383bc3e857960f5ee88096dd5b23,NULL),(15,0x4a18b3f049ec94e84aa51826dd939564,0x90638c6529e9ec277f42086fc9a15839,0xd01be0f90632ad9a323133b9a34f030b,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x561c415f61003c41bbfc700a7c1f9df1,NULL),(16,0xc53bc276ae8351e61ba2b35cea3fb25f,0x90638c6529e9ec277f42086fc9a15839,0x60d55e9a8f73eb796319e9f8dae2e024,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x677c5b7ae613fed99ee2f1d188dcef2b,NULL),(17,0xe1f7f7bd788a5ed3d65a0a992e1f5f52,0xf4c584724b1f22a935dbbcb2042dc534,0xd01be0f90632ad9a323133b9a34f030b,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x63ed655642d12f49de079355fa1188f1,NULL),(18,0xe1f7f7bd788a5ed3d65a0a992e1f5f52,0xd3aafaae129795965a9fbfe758c4925928500f8f0d4f4eaf68ea7ca7d82839ef,0xa84a0b1d104d93239462538148e3c92b,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x50449577095f5a20326c1b8a2ca42306,NULL),(19,0x4a18b3f049ec94e84aa51826dd939564,0x3c4da3fb3c2fdc13565410d0b5b296e2,0xa284a21b23a0634e5bad9c7279df5f7f,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xf89ceaa84da3660ee25de3d0838f71a8,NULL),(20,0x3a7d52fdf221e4e76986d657d17bb8b6,0x1200f53aa19a76ac97cffa5a3880d04f,0xcdd4837c2482cb51ce2a2a974afd58ea,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x984cfe8107375a23850d9cf92d4e56cc,NULL),(21,0xa77cc47b55f653f98d0c18f68037fcc3,0x1200f53aa19a76ac97cffa5a3880d04f,0x916808310ec41533f6584600479bf87c,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xd1ad52584e05f28444b6ba607262be84,NULL),(22,0xc53bc276ae8351e61ba2b35cea3fb25f,0x3c4da3fb3c2fdc13565410d0b5b296e2,0x2e7e539c4ef10c0ee4cca7e89dfbc9e2,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x68f99c67c5c0e96ca5cf9b5d98c91bae,NULL),(23,0xe78a06a94c3962a7164c5d14d8d87cdb,0x1200f53aa19a76ac97cffa5a3880d04f,0xb1c94cc2798e39e70e3e11395f686f28,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x6fe28b03e7f36b24295cbd99350969b3,NULL),(24,0x8f40c2b6d1bcf10be77a3a285981f461,0x90638c6529e9ec277f42086fc9a15839,0x211709c02ae2a4d5c3781d1919c4e94d,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xf8e1901467968fa67206476ea9e1a49f,NULL),(25,0x6278d03adb36391e12615a9c8a0fe2dd,0x73b107b94fc388dd6838eeb029c6eaeca545acd59a5c75d85e429545b1b87e8a,0x2d6cbc535ed536b2b0d78114084a927e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa32893fc3420770895937b52d66d638a,NULL),(26,0xf26a9545f4fed2b9ab661c3e645c3a9d,0xf4c584724b1f22a935dbbcb2042dc534,0xefcbf255754a35c00561e31e8ae6a563,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x08bc9a3b10c83cf873679558f1b3985a,NULL),(27,0xf26a9545f4fed2b9ab661c3e645c3a9d,0xd3aafaae129795965a9fbfe758c4925928500f8f0d4f4eaf68ea7ca7d82839ef,0x94cd17a0b7849da8b093dedbc80f43ce,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x1840da3311e1928ce5baaa96cf3da00d,NULL),(28,0x17f29d374b2a97020e49a5401edcf49f,0x1200f53aa19a76ac97cffa5a3880d04f,0x3a6d666126f2718953e62f1987f4f200,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xc3cb7c142ac2eee7ed2f81c15c50a976,NULL),(29,0x200c3786fd557afdf4281f4906b7fb0f,0x1200f53aa19a76ac97cffa5a3880d04f,0xefcbf255754a35c00561e31e8ae6a563,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x93f257c02d35687a839cea2cde104e53,NULL),(30,0xf278037cb98f06b904210e448757d202,0x1200f53aa19a76ac97cffa5a3880d04f,0x151d9d6a3578457a437c17defdc0d82f,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x9087c3a060e87884bc1646b15d9f587b,NULL),(31,0x9c96f4c4cd88e950ff94e06996263fa3,0x1200f53aa19a76ac97cffa5a3880d04f,0xb9e2a0e5fb5fe131dd226acb0cc97e5e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x189c4442f822df0d54fc1242fcf2da96,NULL),(32,0x44e8fada0ff8a584bd931dd1c3ed968a,0x90638c6529e9ec277f42086fc9a15839,0xe8e8327d40b4d6980444f213647eacb4,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xdfa7c1d99c65bbd19416f239d762ecbb,NULL),(33,0xe2a390b58325c1cf93f752183e0090a4,0x73b107b94fc388dd6838eeb029c6eaeca545acd59a5c75d85e429545b1b87e8a,0xfc47ce1ba6daa0ba26add0cb013cb472,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x218c5b93d970f5effb9d6b2a26b843f4,NULL),(34,0xf8d16a4f7ddd778e522592b9c7f06593,0x90638c6529e9ec277f42086fc9a15839,0xe99e9df13636b51472b494b6f9c4ff6d,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x3b220932fb771f678c5b8eee9f18aca6,NULL),(35,0x3a7d52fdf221e4e76986d657d17bb8b6,0x90638c6529e9ec277f42086fc9a15839,0xda52cf942d93ae4e0b6f33582b91ca5f,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x3903f1541107ba218a3c37148af66148,NULL),(36,0xe1f7f7bd788a5ed3d65a0a992e1f5f52,0x73b107b94fc388dd6838eeb029c6eaeca545acd59a5c75d85e429545b1b87e8a,0xe34e7632beaad6a3c4c2514d0d3548b9,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xfbbdde62f3e021b3fdab04feaf54165a,NULL),(37,0xf26a9545f4fed2b9ab661c3e645c3a9d,0x73b107b94fc388dd6838eeb029c6eaeca545acd59a5c75d85e429545b1b87e8a,0xeb15b7b799204400bdcf27cc34b013ae,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x61f006e3304db40109c7931f93946ae6,NULL),(38,0x4a18b3f049ec94e84aa51826dd939564,0x73b107b94fc388dd6838eeb029c6eaeca545acd59a5c75d85e429545b1b87e8a,0x536281d9045f3f7836eacebae017a7f7,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xdb6a2a01f7a65cb83b1995034663bcc9,NULL),(39,0x4a18b3f049ec94e84aa51826dd939564,0xf4c584724b1f22a935dbbcb2042dc534,0xff220be5cd7691151351e20e5caab560,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x9aab8439d1c7fefe77f3402f7b2b684d,NULL),(40,0x4a18b3f049ec94e84aa51826dd939564,0xd3aafaae129795965a9fbfe758c4925928500f8f0d4f4eaf68ea7ca7d82839ef,0xd3ab0eb5857ea9a53f668468f1abcec2,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x20169466b5734d63255eb6d22c89ddd9,NULL),(41,0xc53bc276ae8351e61ba2b35cea3fb25f,0xd3aafaae129795965a9fbfe758c4925928500f8f0d4f4eaf68ea7ca7d82839ef,0x3a356dffd4b436fdb7510736b0f9f5fa,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xcf0b6316e59ab6d318cc002b341f11ee,NULL),(42,0x0befa358efad18b90b42779c035cb942,0xd3aafaae129795965a9fbfe758c4925928500f8f0d4f4eaf68ea7ca7d82839ef,0x0d8f9b451c1643d327535986d0c61e3b,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xc62382f5233ba9d56f0f7dae84967d03,NULL),(43,0x0befa358efad18b90b42779c035cb942,0x3c4da3fb3c2fdc13565410d0b5b296e2,0x6672567c942e88b71febb4110da43473,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xfe96c16436cb235abc0d99331e0df403,NULL),(44,0x8f40c2b6d1bcf10be77a3a285981f461,0x3c4da3fb3c2fdc13565410d0b5b296e2,0xa88174fd3e4a55aca4b252b7469f736d,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xc1681b1e8459a6d5231cc671045a81fd,NULL),(45,0x44e8fada0ff8a584bd931dd1c3ed968a,0x3c4da3fb3c2fdc13565410d0b5b296e2,0x2e7e539c4ef10c0ee4cca7e89dfbc9e2,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x573f32259f8af5752ec040e0c3e3621b,NULL),(46,0xf8d16a4f7ddd778e522592b9c7f06593,0x3c4da3fb3c2fdc13565410d0b5b296e2,0xc0bf9e711138cd0767cba7dc3067add7,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x6f7385b0eed08dc4b50c24068a2247e7,NULL),(47,0xc53bc276ae8351e61ba2b35cea3fb25f,0xf4c584724b1f22a935dbbcb2042dc534,0x65977f18de2ebef0e0bc8d1ab1bef3b5,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xb81a8e5dfa66182a4e28ec63bb7c9ea4,NULL),(48,0x0befa358efad18b90b42779c035cb942,0xf4c584724b1f22a935dbbcb2042dc534,0xffc65390e378134a88d2cbc4bd737343,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xdac4c0ac1ba8e060342525ac682046aa,NULL),(49,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x0c57a59e51de5ef2960a3e5e75fdbf7e,0x3069241455c0ec7172aae5007ede32b3,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x0a8ac971b6abcc83ec04146409e43155,NULL),(50,0xc3b34aa2fcc9ad3732f372e541dba19f,0x1200f53aa19a76ac97cffa5a3880d04f,0xa9b8a34b4131e6993cde5f1f1bd31813,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x2dc3176c4820832ca87fd146390d24cd,NULL),(51,0x8b13809c5b231adadcc67b4c523d115b,0x1200f53aa19a76ac97cffa5a3880d04f,0x61db175fa3d78e79ee0703970735f5de,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x1bec2ef8e9e6e414e3d967e6bec7a6fd,NULL),(52,0x38d54869f32c7d43524a9e0c2e3ffeb9,0x1200f53aa19a76ac97cffa5a3880d04f,0xe34e7632beaad6a3c4c2514d0d3548b9,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x6e84975c94b15bf759103236b1ea6341,NULL),(53,0xd1ae0cddf8bbfe38aec0ec7e255fcc1f,0x1200f53aa19a76ac97cffa5a3880d04f,0x44f70dd57bf6caa9730313d97b1f4f78,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xc03c03d9bb14dcb9d6d4bcd47dde99b3,NULL),(54,0x3a7d52fdf221e4e76986d657d17bb8b6,0x3c4da3fb3c2fdc13565410d0b5b296e2,0xddc5843b2aa5588f3d3ff7e035fc4644,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x2afe0ac0293f58bbbf7dd0862562ba03,NULL),(55,0xa77cc47b55f653f98d0c18f68037fcc3,0x3c4da3fb3c2fdc13565410d0b5b296e2,0x1ee4bbabce80d7958a57b9c454721bd1,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x17cd78fb14351e4b140c1e6bd583c0f3,NULL),(56,0xe78a06a94c3962a7164c5d14d8d87cdb,0x3c4da3fb3c2fdc13565410d0b5b296e2,0x0fef04ac3a9badaacfd77cceb0011f70,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x9e62f46335dcaf65c7ba4efaeaf60a89,NULL),(57,0xa77cc47b55f653f98d0c18f68037fcc3,0x90638c6529e9ec277f42086fc9a15839,0xd2f329ec0a3dfab40458acbf6e517b52,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xe53cc952dc1f01c0d7629a17d2fb10f9,NULL),(58,0xe78a06a94c3962a7164c5d14d8d87cdb,0x90638c6529e9ec277f42086fc9a15839,0xd3ab0eb5857ea9a53f668468f1abcec2,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x90c5e63412d276353d8a69ea2a93393f,NULL),(59,0xc53bc276ae8351e61ba2b35cea3fb25f,0x73b107b94fc388dd6838eeb029c6eaeca545acd59a5c75d85e429545b1b87e8a,0x2fe1cd385cca3513a00f11be716f9b57,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x39f7cd9acabbd62e81f0d21866ce8433,NULL),(60,0x8f40c2b6d1bcf10be77a3a285981f461,0xf4c584724b1f22a935dbbcb2042dc534,0x3345d711cdc31f29917762d11b270496,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x7ed08e01de1fd264b5be8463377457a3,NULL),(61,0x4c14997ee8832eb7eefb99d7e2df8c5b,0x1200f53aa19a76ac97cffa5a3880d04f,0xda57de7ae0c9adfb0ea4ab18b6d7aeaa,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xfca5e6cccb316170881bea52f80339e1,NULL),(62,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x0c57a59e51de5ef2960a3e5e75fdbf7e,0x4c02c00ea1483174e99db0176dbc903e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x090b4030ee6d6a206ddcb08d96ccec8f,NULL),(63,0x17f29d374b2a97020e49a5401edcf49f,0x3c4da3fb3c2fdc13565410d0b5b296e2,0xc4d28a9b93a570db340d3cfc07ecad0d,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x36439fdc957ef88edaf100e62d530cf0,NULL),(64,0x0abe1ecc8c935edbfa141889eb9e0e2e,0x1200f53aa19a76ac97cffa5a3880d04f,0xd3ab0eb5857ea9a53f668468f1abcec2,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa80fbaaf8b06ce882c2d3f64f4b53c10,NULL),(65,0x3616257c4ecea232767b748802400805,0x1200f53aa19a76ac97cffa5a3880d04f,0xf082a6d0e7258ca8e38c85d360e10933,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xf96203e450a2387c3f209359668cdb4e,NULL),(66,0x200c3786fd557afdf4281f4906b7fb0f,0x3c4da3fb3c2fdc13565410d0b5b296e2,0x6672567c942e88b71febb4110da43473,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa149b14e48d9986f6377c2f9e79f355b,NULL),(67,0xf278037cb98f06b904210e448757d202,0x3c4da3fb3c2fdc13565410d0b5b296e2,0x968e26ae5674c4eee91a790547525ed0,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x1cea5e46b67f44f7176b71301398f33e,NULL),(68,0x110bdd332dedc08038373d015f1d7758,0x1200f53aa19a76ac97cffa5a3880d04f,0xefcbf255754a35c00561e31e8ae6a563,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x1b4ede12d3b239de94998a061f58de86,NULL),(69,0xc36c420a46413f6532c7076086e5bea2,0x1200f53aa19a76ac97cffa5a3880d04f,0x406dc83653b6a220eb41e20a903b4372,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xab83e73edadd7b0031593960cd1ccfc7,NULL),(70,0xc31a6d8b206e3bae11ad781f796cda95,0x1200f53aa19a76ac97cffa5a3880d04f,0x406dc83653b6a220eb41e20a903b4372,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x73733b15d479e1c39de4e8b15baf6f31,NULL),(71,0xe521cfbc1703f7e0e72985a0e62cb0d7,0x1200f53aa19a76ac97cffa5a3880d04f,0xefcbf255754a35c00561e31e8ae6a563,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x8a00a04dd5d0aecd21d4eb6c1689ff0a,NULL),(72,0x8efd4ad0d5e541c77a3749e90f5161f7,0x1200f53aa19a76ac97cffa5a3880d04f,0xf082a6d0e7258ca8e38c85d360e10933,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xc3e1325274fa4fe2fbc092e1bf7d53d5,NULL),(73,0xd3fc23e2bd0b563dea84398b7dbdda19,0x1200f53aa19a76ac97cffa5a3880d04f,0xd01be0f90632ad9a323133b9a34f030b,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x1d63a4389d3941487b47eee53b8b0eca,NULL),(74,0x110bdd332dedc08038373d015f1d7758,0x1200f53aa19a76ac97cffa5a3880d04f,0x406dc83653b6a220eb41e20a903b4372,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x2f400cc01f093dbd1389fa5a448126ec,NULL),(75,0xc36c420a46413f6532c7076086e5bea2,0x1200f53aa19a76ac97cffa5a3880d04f,0xd01be0f90632ad9a323133b9a34f030b,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x8c230a7fa1b2e07a93e7218572fa8bf8,NULL),(76,0x0befa358efad18b90b42779c035cb942,0x73b107b94fc388dd6838eeb029c6eaeca545acd59a5c75d85e429545b1b87e8a,0xc9bdf3e542ef47aa9dfcd7f3942cf607,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x7c3b04ddfacbef11f33f8eef4384ccec,NULL),(77,0x8f40c2b6d1bcf10be77a3a285981f461,0xd3aafaae129795965a9fbfe758c4925928500f8f0d4f4eaf68ea7ca7d82839ef,0xd3ab0eb5857ea9a53f668468f1abcec2,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa43e297c9f2c8ffdc672577b027290a2,NULL),(78,0x17f29d374b2a97020e49a5401edcf49f,0x90638c6529e9ec277f42086fc9a15839,0x209a1d42efa12402299ec744d39cd2ae,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x366fa3ab4dd86b9d88861d8fb585a5d7,NULL),(79,0x9c96f4c4cd88e950ff94e06996263fa3,0x3c4da3fb3c2fdc13565410d0b5b296e2,0xeace595bd96147bd2683f35ca365291c,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xf573da8b209e785cc7d14156832e19eb,NULL),(80,0xc3b34aa2fcc9ad3732f372e541dba19f,0x3c4da3fb3c2fdc13565410d0b5b296e2,0xc4d28a9b93a570db340d3cfc07ecad0d,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x464cb2531730be78d3748e65bf3268ad,NULL),(81,0x8b13809c5b231adadcc67b4c523d115b,0x3c4da3fb3c2fdc13565410d0b5b296e2,0xf423b322ba30314b6004239c0d189936,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xc6600e80b0c6ff71d1b33829cfb3eb70,NULL),(82,0xe521cfbc1703f7e0e72985a0e62cb0d7,0x1200f53aa19a76ac97cffa5a3880d04f,0xd3ab0eb5857ea9a53f668468f1abcec2,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x8346207b2fcbc24c0cac1a683c881274,NULL),(83,0x8efd4ad0d5e541c77a3749e90f5161f7,0x1200f53aa19a76ac97cffa5a3880d04f,0xc4d28a9b93a570db340d3cfc07ecad0d,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x763fdb8fd609d65b018fe922ec782822,NULL),(84,0x200c3786fd557afdf4281f4906b7fb0f,0x90638c6529e9ec277f42086fc9a15839,0xefcbf255754a35c00561e31e8ae6a563,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xee6f9648dbd891be3ffa8b5d8956dced,NULL),(85,0x8f40c2b6d1bcf10be77a3a285981f461,0x73b107b94fc388dd6838eeb029c6eaeca545acd59a5c75d85e429545b1b87e8a,0xc4d28a9b93a570db340d3cfc07ecad0d,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x19f1c79b949cb1bb1dcfa52e6fe1ef11,NULL),(86,0xd3fc23e2bd0b563dea84398b7dbdda19,0x1200f53aa19a76ac97cffa5a3880d04f,0xf082a6d0e7258ca8e38c85d360e10933,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x6a86a367e529d35db421f559e690d458,NULL),(87,0xf744f9d43721c5bc948fa2a7a5fb9f2e,0x1200f53aa19a76ac97cffa5a3880d04f,0xf082a6d0e7258ca8e38c85d360e10933,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x9080a24a7d972e0d17160ac7f7f63aec,NULL),(88,0x22e8474a442ce73c1bfc8ba82716144f,0x1200f53aa19a76ac97cffa5a3880d04f,0xa748668db8c908dd27f0f1675be591cf,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x21c741e8ae47e2c493fedf11fe241297,NULL),(89,0x19a1b91fa9318a2132ab46f673d6d193,0x1200f53aa19a76ac97cffa5a3880d04f,0x6bb340de71b9bccfe7ff805d32b09742,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa57035e348d74bd748048a835a202deb,NULL),(90,0x38d54869f32c7d43524a9e0c2e3ffeb9,0x3c4da3fb3c2fdc13565410d0b5b296e2,0x7056e74e1a4b93099f7d6f61e9e93589,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x0fa340db8721735a0d7972ecd44e4b87,NULL),(91,0xf278037cb98f06b904210e448757d202,0x90638c6529e9ec277f42086fc9a15839,0xc9bdf3e542ef47aa9dfcd7f3942cf607,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x5186575b0133346a7490867a76b16f0c,NULL),(92,0x44e8fada0ff8a584bd931dd1c3ed968a,0x73b107b94fc388dd6838eeb029c6eaeca545acd59a5c75d85e429545b1b87e8a,0xe390079e74b26ffb84b8592a971f78ef,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xf7f5e9ebe68219c543254a91046572a2,NULL),(93,0x44e8fada0ff8a584bd931dd1c3ed968a,0xf4c584724b1f22a935dbbcb2042dc534,0xe4837d83371b4d2ac0b5d4565a467794,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x17d783d412875d696d60bb6273d4136e,NULL),(94,0x44e8fada0ff8a584bd931dd1c3ed968a,0xd3aafaae129795965a9fbfe758c4925928500f8f0d4f4eaf68ea7ca7d82839ef,0xf74d21723b060cc6519a64085b2af8cc,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x393d32772c177ed357839b15a01e761e,NULL),(95,0xd1ae0cddf8bbfe38aec0ec7e255fcc1f,0x3c4da3fb3c2fdc13565410d0b5b296e2,0x9385630dffd0eac97bdc227b4d15403d,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x4071c43be1e4d61fadb6b26e7daf8d83,NULL),(96,0x913f9688f792666f12b9fa6b3146461e,0x1200f53aa19a76ac97cffa5a3880d04f,0x09c156679beafe6fd1d853b52392de64,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x5830e627e12119487e7644e6b25d6885,NULL),(97,0xd71168d172853f11fcdeab12a20dd09a,0x1200f53aa19a76ac97cffa5a3880d04f,0x135f7885053c846f85d94a93e219e850,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x75d8081ea4dcdec51e47d6dab74f4e4b,NULL),(98,0x9c96f4c4cd88e950ff94e06996263fa3,0x90638c6529e9ec277f42086fc9a15839,0x3b3d68a9d20bc3d917e91533480f0e53,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x70cc13f421231b8d8f9f3a5a4d2fc7ca,NULL),(99,0xf8d16a4f7ddd778e522592b9c7f06593,0x73b107b94fc388dd6838eeb029c6eaeca545acd59a5c75d85e429545b1b87e8a,0x528dffc9a15cda48fa08f7e66c3c2941,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x22dcb6a2de8a23331eea4ba4d95579c7,NULL),(100,0xf8d16a4f7ddd778e522592b9c7f06593,0xf4c584724b1f22a935dbbcb2042dc534,0x6672567c942e88b71febb4110da43473,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa5960a2f431573915fe03d03be1a751b,NULL),(101,0xf8d16a4f7ddd778e522592b9c7f06593,0xd3aafaae129795965a9fbfe758c4925928500f8f0d4f4eaf68ea7ca7d82839ef,0x209a1d42efa12402299ec744d39cd2ae,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xf227ac2ecae1874e42e4a8ec8efbca5a,NULL),(102,0xccefdeae543890c5dcf70308197a8304,0x1200f53aa19a76ac97cffa5a3880d04f,0x817f2bb2ca8877e6e1ca5f0b3beed8de,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x7516dd0f0c2618eb40299e9ff23933eb,NULL),(103,0x3a7d52fdf221e4e76986d657d17bb8b6,0xf4c584724b1f22a935dbbcb2042dc534,0x654ee6bc2cb5d019614e0c3bc4c80d19,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x5ce74b2a0ac19849dc6a69ab5cf2ad8b,NULL),(104,0xc3b34aa2fcc9ad3732f372e541dba19f,0x90638c6529e9ec277f42086fc9a15839,0x22a6632041a214238e5327aaf3e1abc0,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x547b78d328313a206a1e9331f4770819,NULL),(105,0x4c14997ee8832eb7eefb99d7e2df8c5b,0x3c4da3fb3c2fdc13565410d0b5b296e2,0x209a1d42efa12402299ec744d39cd2ae,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xf5942f3d5ad6ff294ce68a9f78f84fe1,NULL),(106,0x92269507c4ba23d18b595962c4497298,0x1200f53aa19a76ac97cffa5a3880d04f,0x8a99034dec0b03c6c8449155449b0811,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x538547f4c264acdf751f7f7f948811de,NULL),(107,0x3a7d52fdf221e4e76986d657d17bb8b6,0xd3aafaae129795965a9fbfe758c4925928500f8f0d4f4eaf68ea7ca7d82839ef,0x3a6d666126f2718953e62f1987f4f200,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x3bff06bc12ac7663980368353afc6bf1,NULL),(108,0xba78100c1dc7b8e34e623e2a91e20178,0x1200f53aa19a76ac97cffa5a3880d04f,0xf082a6d0e7258ca8e38c85d360e10933,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa3b7d5aefc344bba987fe0b0684fab89,NULL),(109,0x0944fcc0a6cac54d3fd4eb6c2811f17c,0x1200f53aa19a76ac97cffa5a3880d04f,0xf082a6d0e7258ca8e38c85d360e10933,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x07f20b6a8665b85c90009862c53b147e,NULL);
/*!40000 ALTER TABLE `collections_log` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `contribution_types`
DROP TABLE IF EXISTS `contribution_types`;
CREATE TABLE `contribution_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- Dumping data for table `contribution_types`
LOCK TABLES `contribution_types` WRITE;
/*!40000 ALTER TABLE `contribution_types` DISABLE KEYS */;
INSERT INTO `contribution_types` VALUES (1,'Building Fund','This building Fund',1,NULL,1421676174,NULL),(2,'First Fruit','First Fruit',1,NULL,1421676212,NULL),(3,'Christmas Gift','Christmas Gift',1,NULL,1421676389,NULL),(4,'Easter Gift','Easter Gift',1,NULL,1421676408,NULL),(5,'Baptism','Baptism',1,NULL,1421676420,NULL),(6,'Confirmation','Confirmation',1,NULL,1421676434,NULL),(7,'Pastor Appreciation','Pastor Appreciation',1,NULL,1421676465,NULL),(8,'Door','',1,NULL,1468847428,NULL),(9,'Window','',1,NULL,1468847464,NULL);
/*!40000 ALTER TABLE `contribution_types` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `core_settings`
DROP TABLE IF EXISTS `core_settings`;
CREATE TABLE `core_settings` (
  `slug` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `default` text COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`slug`),
  UNIQUE KEY `unique - slug` (`slug`),
  KEY `index - slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Stores settings for the multi-site interface';

-- Dumping data for table `core_settings`
LOCK TABLES `core_settings` WRITE;
/*!40000 ALTER TABLE `core_settings` DISABLE KEYS */;
INSERT INTO `core_settings` VALUES ('date_format','g:ia -- m/d/y','g:ia -- m/d/y'),('lang_direction','ltr','ltr'),('status_message','This site has been disabled by a super-administrator.','This site has been disabled by a super-administrator.');
/*!40000 ALTER TABLE `core_settings` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `core_sites`
DROP TABLE IF EXISTS `core_sites`;
CREATE TABLE `core_sites` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `ref` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `domain` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` int(11) NOT NULL DEFAULT '0',
  `updated_on` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `Unique ref` (`ref`),
  UNIQUE KEY `Unique domain` (`domain`),
  KEY `ref` (`ref`),
  KEY `domain` (`domain`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table `core_sites`
LOCK TABLES `core_sites` WRITE;
/*!40000 ALTER TABLE `core_sites` DISABLE KEYS */;
INSERT INTO `core_sites` VALUES (1,'Default Site','default','localhost',1,1361856990,0);
/*!40000 ALTER TABLE `core_sites` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `core_users`
DROP TABLE IF EXISTS `core_users`;
CREATE TABLE `core_users` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `salt` varchar(6) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `group_id` int(11) DEFAULT NULL,
  `ip_address` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` int(1) DEFAULT NULL,
  `activation_code` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_on` int(11) NOT NULL,
  `last_login` int(11) NOT NULL,
  `username` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `forgotten_password_code` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_code` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Super User Information';

-- Dumping data for table `core_users`
LOCK TABLES `core_users` WRITE;
/*!40000 ALTER TABLE `core_users` DISABLE KEYS */;
INSERT INTO `core_users` VALUES (1,'evansogola@digitalvision.co.ke','2a7a93fb841e8d17217f56895ccc93f38f2f9114','acf67',1,'',1,'',1361856990,1361856990,'evans',NULL,NULL);
/*!40000 ALTER TABLE `core_users` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `current`
DROP TABLE IF EXISTS `current`;
CREATE TABLE `current` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` blob NOT NULL,
  `total` blob NOT NULL,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- Dumping data for table `current`
LOCK TABLES `current` WRITE;
/*!40000 ALTER TABLE `current` DISABLE KEYS */;
INSERT INTO `current` VALUES (2,0x20bfbac382eb2123b1c5d427436fc1b4,0x90065fe9ea51973a4989393c1f3a44af,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x921b3121e3614246d1851518c28eb193,NULL),(3,0xecb6627aa08517ab62fa13b05320dc21,0xf278037cb98f06b904210e448757d202,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xd445bffc04361113da8dcce6e055de08,NULL),(4,0xa51393e96ae5235cddd30d9cb64d801d,0xf278037cb98f06b904210e448757d202,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa6e96638067cdc9a22225948f48a4569,NULL),(5,0xb6aa85c1acc11305706acc86f1c5b6ea,0x6278d03adb36391e12615a9c8a0fe2dd,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x508637beb36afb823db37d5f39d25bc0,NULL),(6,0x2ab82f695c1b470f597cb0be24f360d7,0xcfa10a53ac284db808f6bedd952eb03d,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x3165d5a70f5e724b9b91f648f162dbbd,NULL),(7,0x076f41d9f76f8ee07daf8bcf78fd345f,0xc53bc276ae8351e61ba2b35cea3fb25f,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x173b27a8d0c2ebaf3f8d736284f30c3e,NULL),(8,0xfeb33515866ad8caf0f005771c7ff10d,0xc53bc276ae8351e61ba2b35cea3fb25f,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x50750f20b15ee7000b067a44108ee70b,NULL),(9,0x8483cf034e650a1c39477f3888a59cdc,0xcfa10a53ac284db808f6bedd952eb03d,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x8a8d2e6cfc71dbc7b8cfa437daefaa1b,NULL),(10,0x5af1a736adbb4f953345df160447dde5,0x6278d03adb36391e12615a9c8a0fe2dd,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xb852d8d37eb65801ad31819edb1e80a8,NULL),(11,0x0d0094f4d365286600226f00598e5f80,0x90065fe9ea51973a4989393c1f3a44af,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x726a7b8687510be61751e20fc8086a90,NULL),(12,0x339fc82a5fc93b9a76164a5c8895a938,0xc53bc276ae8351e61ba2b35cea3fb25f,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xe0da160ad0b844b3abd06314994a0e68,NULL),(13,0xfeb33515866ad8caf0f005771c7ff10d,0xc53bc276ae8351e61ba2b35cea3fb25f,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xf852e73a5a7a83cf529d4781ebc4079f,NULL),(14,0xfeb33515866ad8caf0f005771c7ff10d,0xc53bc276ae8351e61ba2b35cea3fb25f,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x026818d72aef3d9d6bb7ab468bd0fe17,NULL),(15,0x479b76baa01aa28a6928be4a0325e1a6,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x583d63938838ec92248b7e4a535df43a,NULL),(16,0x27adbfe44ee2df162340ad646993de42,0x71f106e2cb7a3adc5b935d135ea71546,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x7a021a5ebef3ca4bfe3c75c4abe759df,NULL),(17,0x210efcffc9b1f819d2a697326aad5cb9,0xf278037cb98f06b904210e448757d202,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xe28f129a15aa137878207e010e95cce6,NULL),(18,0xf8f12444f298c0fe854d9ffb58f6a7ad,0x6278d03adb36391e12615a9c8a0fe2dd,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x2a040a0ab87996095c22a4e0cfd1ecdb,NULL),(19,0x0c6bc44f3ca3f4905195b6c5fc7bc2df,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xabe12b468f04785655662f8266f19e0f,NULL),(20,0xb71a8b39512ab528a3874bc129050f68,0xc53bc276ae8351e61ba2b35cea3fb25f,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xfbf3d26cf53512486f5636ba3dfa7079,NULL),(21,0xd368acc86890f4eafa56a21f04090740,0x3a7d52fdf221e4e76986d657d17bb8b6,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x1f67b441416e593d71399757b25fc4f8,NULL);
/*!40000 ALTER TABLE `current` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `daily_inspirations`
DROP TABLE IF EXISTS `daily_inspirations`;
CREATE TABLE `daily_inspirations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL DEFAULT '',
  `message` text,
  `status` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Dumping data for table `daily_inspirations`
LOCK TABLES `daily_inspirations` WRITE;
/*!40000 ALTER TABLE `daily_inspirations` DISABLE KEYS */;
INSERT INTO `daily_inspirations` VALUES (1,'The Inspiration','This is the inspiration',1,1,NULL,1423343449,NULL),(2,'We live','the is the message',1,1,NULL,1423343875,NULL);
/*!40000 ALTER TABLE `daily_inspirations` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `dedications`
DROP TABLE IF EXISTS `dedications`;
CREATE TABLE `dedications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `first_name` varchar(256) NOT NULL DEFAULT '',
  `middle_name` varchar(256) NOT NULL DEFAULT '',
  `last_name` varchar(256) NOT NULL DEFAULT '',
  `gender` varchar(256) NOT NULL DEFAULT '',
  `dob` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `location` varchar(256) NOT NULL DEFAULT '',
  `country` varchar(256) NOT NULL DEFAULT '',
  `city` varchar(256) NOT NULL DEFAULT '',
  `expected_dedication_date` int(11) DEFAULT NULL,
  `service_type` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `type` int(11) DEFAULT NULL,
  `father` int(11) DEFAULT NULL,
  `mother` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Dumping data for table `dedications`
LOCK TABLES `dedications` WRITE;
/*!40000 ALTER TABLE `dedications` DISABLE KEYS */;
INSERT INTO `dedications` VALUES (1,1420059600,'Lucy','J','Mwang\'o','Female',1390338000,1,'Mama Lucy','Kenya','Nairobi',1420923600,'Third Service','Here',NULL,NULL,NULL,1,1,1421919565,1421996191),(3,1421528400,'Meshack','Njoi','Masinde','Male',1421528400,1,'KNH','Kenya','Nairobi',1422133200,'Second Service','',1,6,24,1,NULL,1421924256,NULL),(4,1421528400,'Mercy','Norah','Lugari','Female',1420059600,1,'USA','United States','Texas',1422133200,'Third Service','Done',1,22,5,1,1,1421996324,1423116755);
/*!40000 ALTER TABLE `dedications` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `deductions`
DROP TABLE IF EXISTS `deductions`;
CREATE TABLE `deductions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `amount` varchar(256) NOT NULL DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Dumping data for table `deductions`
LOCK TABLES `deductions` WRITE;
/*!40000 ALTER TABLE `deductions` DISABLE KEYS */;
INSERT INTO `deductions` VALUES (1,'SACCO','500',1,NULL,1422263718,NULL),(2,'Loan','1000',1,NULL,1422272358,NULL),(3,'Others','1500',1,NULL,1422272358,NULL);
/*!40000 ALTER TABLE `deductions` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `donations`
DROP TABLE IF EXISTS `donations`;
CREATE TABLE `donations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `donor` varchar(256) NOT NULL DEFAULT '',
  `phone` varchar(256) NOT NULL DEFAULT '',
  `email` varchar(256) NOT NULL DEFAULT '',
  `address` text,
  `country` varchar(32) NOT NULL DEFAULT '',
  `city` varchar(256) NOT NULL DEFAULT '',
  `donation_type` varchar(256) NOT NULL DEFAULT '',
  `pledged_amount` varchar(256) NOT NULL DEFAULT '',
  `value` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Dumping data for table `donations`
LOCK TABLES `donations` WRITE;
/*!40000 ALTER TABLE `donations` DISABLE KEYS */;
INSERT INTO `donations` VALUES (1,1421096400,'Mwalimu SACCO','(070) 122-5888','mail@mail.com','Box 12548 Nairobi','Kenya','Nairobi','Donation','200000','','This is donation',1,NULL,1421485026,NULL),(2,1421614800,'Mwalimu Investemnts','(072) 154-8888','mwa@mwa.com','Box 12548','Kenya','Nairobi','Merchandise','550000','550000','More here',1,NULL,1421846325,NULL),(3,1424120400,'M-Shamba Limited','(072) 134-1214','info@mshamba.net','Box 12548','Kenya','Nairobi','Donation','50000','50000','New donation',1,NULL,1422947181,NULL),(4,1424293200,'Smart shuleLimited','(072) 134-1214','info@mshamba.net','Box 12548','Kenya','Nairobi','Donation','70000','70000','New donation',1,NULL,1422947238,NULL),(5,1461013200,'Church Smart','0720000000','chrch@admin.com','Box 4588','Kenya','Nairobi','Donation','45000','','',1,NULL,1461075582,NULL);
/*!40000 ALTER TABLE `donations` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `email_recipients`
DROP TABLE IF EXISTS `email_recipients`;
CREATE TABLE `email_recipients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` varchar(256) NOT NULL DEFAULT '',
  `email_id` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;

-- Dumping data for table `email_recipients`
LOCK TABLES `email_recipients` WRITE;
/*!40000 ALTER TABLE `email_recipients` DISABLE KEYS */;
INSERT INTO `email_recipients` VALUES (1,'5','1',1,NULL,1422705398,NULL),(2,'5','2',1,NULL,1422705567,NULL),(3,'5','3',1,NULL,1422705587,NULL),(4,'5','4',1,NULL,1422705763,NULL),(5,'5','5',1,NULL,1422705780,NULL),(6,'5','6',1,NULL,1422705867,NULL),(7,'6','6',1,NULL,1422705869,NULL),(8,'7','6',1,NULL,1422705871,NULL),(9,'16','6',1,NULL,1422705873,NULL),(10,'17','6',1,NULL,1422705875,NULL),(11,'18','6',1,NULL,1422705878,NULL),(12,'19','6',1,NULL,1422705880,NULL),(13,'20','6',1,NULL,1422705882,NULL),(14,'21','6',1,NULL,1422705884,NULL),(15,'22','6',1,NULL,1422705886,NULL),(16,'23','6',1,NULL,1422705888,NULL),(17,'24','6',1,NULL,1422705890,NULL),(18,'5','7',1,NULL,1422706128,NULL),(19,'6','7',1,NULL,1422706130,NULL),(20,'7','7',1,NULL,1422706132,NULL),(21,'16','7',1,NULL,1422706134,NULL),(22,'17','7',1,NULL,1422706135,NULL),(23,'18','7',1,NULL,1422706137,NULL),(24,'19','7',1,NULL,1422706139,NULL),(25,'20','7',1,NULL,1422706141,NULL),(26,'21','7',1,NULL,1422706142,NULL),(27,'22','7',1,NULL,1422706144,NULL),(28,'23','7',1,NULL,1422706146,NULL),(29,'24','7',1,NULL,1422706147,NULL),(30,'5','8',1,NULL,1422706383,NULL),(31,'6','8',1,NULL,1422706385,NULL),(32,'7','8',1,NULL,1422706386,NULL),(33,'16','8',1,NULL,1422706388,NULL),(34,'17','8',1,NULL,1422706389,NULL),(35,'18','8',1,NULL,1422706391,NULL),(36,'19','8',1,NULL,1422706392,NULL),(37,'20','8',1,NULL,1422706394,NULL),(38,'21','8',1,NULL,1422706395,NULL),(39,'22','8',1,NULL,1422706397,NULL),(40,'23','8',1,NULL,1422706398,NULL),(41,'24','8',1,NULL,1422706399,NULL),(42,'5','9',1,NULL,1422707281,NULL),(43,'6','9',1,NULL,1422707283,NULL),(44,'7','9',1,NULL,1422707285,NULL),(45,'16','9',1,NULL,1422707287,NULL),(46,'17','9',1,NULL,1422707289,NULL),(47,'18','9',1,NULL,1422707291,NULL),(48,'19','9',1,NULL,1422707292,NULL),(49,'20','9',1,NULL,1422707294,NULL),(50,'21','9',1,NULL,1422707296,NULL),(51,'22','9',1,NULL,1422707298,NULL),(52,'23','9',1,NULL,1422707300,NULL),(53,'24','9',1,NULL,1422707302,NULL),(54,'5','10',1,NULL,1422707647,NULL);
/*!40000 ALTER TABLE `email_recipients` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `email_templates`
DROP TABLE IF EXISTS `email_templates`;
CREATE TABLE `email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) DEFAULT NULL,
  `slug` varchar(250) DEFAULT NULL,
  `description` text,
  `content` text,
  `status` enum('draft','live') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'draft',
  `created_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Dumping data for table `email_templates`
LOCK TABLES `email_templates` WRITE;
/*!40000 ALTER TABLE `email_templates` DISABLE KEYS */;
INSERT INTO `email_templates` VALUES (1,'Meetings Template','meetings','This is meetings template','<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\r\n<meta name=\"viewport\" content=\"initial-scale=1.0\"> \r\n<meta name=\"format-detection\" content=\"telephone=no\">\r\n<title>Metric : Responsive Email Templates</title>\r\n<style type=\"text/css\">\r\n\r\n/* Resets: see reset.css for details */\r\n.ReadMsgBody { width: 100%; background-color: #ffffff;}\r\n.ExternalClass {width: 100%; background-color: #ffffff;}\r\n.ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {line-height:100%;}\r\nhtml{width: 100%; }\r\nbody {-webkit-text-size-adjust:none; -ms-text-size-adjust:none; }\r\nbody {margin:0; padding:0;}\r\ntable {border-spacing:0;}\r\nimg{display:block !important;}\r\n\r\ntable td {border-collapse:collapse;}\r\n.yshortcuts a {border-bottom: none !important;}\r\n\r\n\r\n/* \r\n\r\nmain color = #2f9bbe\r\n\r\nother color = #186e8a\r\n\r\n\r\n*/\r\n\r\n\r\nimg{height:auto !important;}\r\n\r\n\r\n@media only screen and (max-width: 640px){\r\n  body{\r\n    width:auto!important;\r\n  }\r\n\r\n  table[class=\"container\"]{\r\n    width: 100%!important;\r\n    padding-left: 20px!important; \r\n    padding-right: 20px!important; \r\n  }\r\n\r\n  img[class=\"image-100-percent\"]{\r\n    width:100% !important;\r\n    height:auto !important;\r\n    max-width:100% !important;\r\n  }\r\n\r\n  img[class=\"small-image-100-percent\"]{\r\n    width:100% !important;\r\n    height:auto !important;\r\n  }\r\n\r\n  table[class=\"full-width\"]{\r\n    width:100% !important;\r\n  }\r\n\r\n  table[class=\"full-width-text\"]{\r\n    width:100% !important;\r\n     background-color:#186e8a;\r\n     padding-left:20px !important;\r\n     padding-right:20px !important;\r\n  }\r\n\r\n  table[class=\"full-width-text2\"]{\r\n    width:100% !important;\r\n     background-color:#f3f3f3;\r\n     padding-left:20px !important;\r\n     padding-right:20px !important; \r\n  }\r\n\r\n  table[class=\"col-2-3img\"]{\r\n    width:50% !important;\r\n    margin-right: 20px !important;\r\n  }\r\n    table[class=\"col-2-3img-last\"]{\r\n    width:50% !important;\r\n  }\r\n\r\n  table[class=\"col-2\"]{\r\n    width:47% !important;\r\n    margin-right:20px !important;\r\n  }\r\n\r\n  table[class=\"col-2-last\"]{\r\n    width:47% !important;\r\n  }\r\n\r\n  table[class=\"col-3\"]{\r\n    width:29% !important;\r\n    margin-right:20px !important;\r\n  }\r\n\r\n  table[class=\"col-3-last\"]{\r\n    width:29% !important;\r\n  }\r\n\r\n  table[class=\"row-2\"]{\r\n    width:50% !important;\r\n  }\r\n\r\n  td[class=\"text-center\"]{\r\n     text-align: center !important;\r\n   }\r\n\r\n  /* start clear and remove*/\r\n  table[class=\"remove\"]{\r\n    display:none !important;\r\n  }\r\n\r\n  td[class=\"remove\"]{\r\n    display:none !important;\r\n  }\r\n  /* end clear and remove*/\r\n\r\n  table[class=\"fix-box\"]{\r\n    padding-left:20px !important;\r\n    padding-right:20px !important;\r\n  }\r\n  td[class=\"fix-box\"]{\r\n    padding-left:20px !important;\r\n    padding-right:20px !important;\r\n  }\r\n\r\n  td[class=\"font-resize\"]{\r\n    font-size: 18px !important;\r\n    line-height: 22px !important;\r\n  }\r\n\r\n\r\n}\r\n\r\n\r\n\r\n@media only screen and (max-width: 479px){\r\n  body{\r\n    font-size:10px !important;\r\n  }\r\n\r\n   table[class=\"container2\"]{\r\n    width: 100%!important; \r\n    float:none !important;\r\n  }\r\n\r\n  img[class=\"image-100-percent\"]{\r\n    width:100% !important;\r\n    height:auto !important;\r\n    max-width:100% !important;\r\n    min-width:124px !important;\r\n  }\r\n    img[class=\"small-image-100-percent\"]{\r\n    width:100% !important;\r\n    height:auto !important;\r\n    max-width:100% !important;\r\n    min-width:124px !important;\r\n  }\r\n\r\n  table[class=\"full-width\"]{\r\n    width:100% !important;\r\n  }\r\n\r\n  table[class=\"full-width-text\"]{\r\n    width:100% !important;\r\n     background-color:#186e8a;\r\n     padding-left:20px !important;\r\n     padding-right:20px !important;\r\n  }\r\n\r\n  table[class=\"full-width-text2\"]{\r\n    width:100% !important;\r\n     background-color:#f3f3f3;\r\n     padding-left:20px !important;\r\n     padding-right:20px !important;\r\n  }\r\n\r\n\r\n\r\n  table[class=\"col-2\"]{\r\n    width:100% !important;\r\n    margin-right:0px !important;\r\n  }\r\n\r\n  table[class=\"col-2-last\"]{\r\n    width:100% !important;\r\n   \r\n  }\r\n\r\n  table[class=\"col-3\"]{\r\n    width:100% !important;\r\n    margin-right:0px !important;\r\n  }\r\n\r\n  table[class=\"col-3-last\"]{\r\n    width:100% !important;\r\n   \r\n  }\r\n\r\n    table[class=\"row-2\"]{\r\n    width:100% !important;\r\n  }\r\n\r\n\r\n  table[id=\"col-underline\"]{\r\n    float: none !important;\r\n    width: 100% !important;\r\n    border-bottom: 1px solid #eee;\r\n  }\r\n\r\n  td[id=\"col-underline\"]{\r\n    float: none !important;\r\n    width: 100% !important;\r\n    border-bottom: 1px solid #eee;\r\n  }\r\n\r\n  td[class=\"col-underline\"]{\r\n    float: none !important;\r\n    width: 100% !important;\r\n    border-bottom: 1px solid #eee;\r\n  }\r\n\r\n\r\n\r\n   /*start text center*/\r\n  td[class=\"text-center\"]{\r\n    text-align: center !important;\r\n\r\n  }\r\n\r\n  div[class=\"text-center\"]{\r\n    text-align: center !important;\r\n  }\r\n   /*end text center*/\r\n\r\n\r\n\r\n  /* start  clear and remove */\r\n\r\n  table[id=\"clear-padding\"]{\r\n    padding:0 !important;\r\n  }\r\n  td[id=\"clear-padding\"]{\r\n    padding:0 !important;\r\n  }\r\n  td[class=\"clear-padding\"]{\r\n    padding:0 !important;\r\n  }\r\n  table[class=\"remove-479\"]{\r\n    display:none !important;\r\n  }\r\n  td[class=\"remove-479\"]{\r\n    display:none !important;\r\n  }\r\n  table[class=\"clear-align\"]{\r\n    float:none !important;\r\n  }\r\n  /* end  clear and remove */\r\n\r\n  table[class=\"width-small\"]{\r\n    width:100% !important;\r\n  }\r\n\r\n  table[class=\"fix-box\"]{\r\n    padding-left:0px !important;\r\n    padding-right:0px !important;\r\n  }\r\n  td[class=\"fix-box\"]{\r\n    padding-left:0px !important;\r\n    padding-right:0px !important;\r\n  }\r\n    td[class=\"font-resize\"]{\r\n    font-size: 14px !important;\r\n  }\r\n\r\n}\r\n@media only screen and (max-width: 320px){\r\n  table[class=\"width-small\"]{\r\n    width:125px !important;\r\n  }\r\n  img[class=\"image-100-percent\"]{\r\n    width:100% !important;\r\n    height:auto !important;\r\n    max-width:100% !important;\r\n    min-width:124px !important;\r\n  }\r\n\r\n}\r\n</style>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<!--start 100% wrapper (white background) -->\r\n<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"background-color:#ececec;\">\r\n\r\n  <!-- START TAB TOP -->\r\n    <tbody><tr>\r\n      <td valign=\"top\">\r\n        <table width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"height:6px; background-color:#2f9bbe;\">\r\n          <tbody><tr>\r\n            <td valign=\"top\" height=\"6\">\r\n              <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\" style=\"height:6px;\">\r\n                <tbody><tr>\r\n                  <td valign=\"top\" align=\"center\"> \r\n                    <table width=\"150\" align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"clear-align\" style=\"height:6px; background-color:#186e8a;\">\r\n                      <tbody><tr>\r\n                        <td valign=\"top\" height=\"6\"></td>\r\n                      </tr>\r\n                    </tbody></table>\r\n                  </td>\r\n                </tr>\r\n              </tbody></table>\r\n            </td>\r\n          </tr>\r\n        </tbody></table>\r\n      </td>\r\n    </tr>\r\n  <!-- END TAB TOP -->\r\n\r\n  <!--START TOP NAVIGATION ?LAYOUT-->\r\n  <tr>\r\n    <td align=\"center\" valign=\"top\" class=\"fix-box\">\r\n      \r\n      <!-- start top navigation container -->\r\n      <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"container\" bgcolor=\"#ffffff\" style=\"background-color:#ffffff;\">\r\n      \r\n        <tbody><tr>\r\n          <td valign=\"top\">\r\n              \r\n\r\n            <!-- start top navigaton -->\r\n            <table width=\"560\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\">\r\n              <tbody><tr>\r\n                <td valign=\"top\">\r\n                \r\n                <table align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"container2\">\r\n                 \r\n                  <tbody><tr>\r\n                    <td align=\"center\" valign=\"middle\">\r\n                       <a href=\"#\"><img src=\"http://localhost/sikul/assets/themes/admin/img/logo-sm.png\" width=\"124\" style=\"max-width:124px;\" alt=\"Logo\" border=\"0\" hspace=\"0\" vspace=\"0\"></a>\r\n                    </td>\r\n                  </tr>\r\n\r\n                </tbody></table>\r\n\r\n                <!--start content nav -->\r\n                <table border=\"0\" align=\"right\" cellpadding=\"0\" cellspacing=\"0\" class=\"container2\">\r\n\r\n                   <tbody><tr>\r\n                    <td height=\"20\" valign=\"top\" class=\"remove-479\"></td>\r\n                  </tr>\r\n\r\n                   <!--start call us -->\r\n                  <tr>\r\n                     <td valign=\"top\" align=\"center\">\r\n                    \r\n                    <table align=\"right\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"clear-align\">\r\n                      <tbody><tr>\r\n                      \r\n\r\n                        <td style=\"font-size: 13px;  line-height: 18px; color: #555555;  font-weight:normal; text-align: center; font-family:Arail,Tahoma, Helvetica, Arial, sans-serif;\">\r\n\r\n                          <span style=\"color: #2f9bbe;\">CALL US</span>\r\n                          +254 721 341 214\r\n                        </td>\r\n                      </tr>\r\n\r\n                    </tbody></table>\r\n                    </td>\r\n                  </tr>\r\n                  <!--end call us -->\r\n\r\n                  <!-- start space height -->\r\n                   <tr>\r\n                    <td height=\"10\" valign=\"top\"></td>\r\n                  </tr>\r\n                  <!-- start space height -->\r\n\r\n\r\n                  <!--start view online -->\r\n                  <tr>\r\n                    <td valign=\"top\" align=\"center\">\r\n                    \r\n                    <table align=\"right\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"clear-align\">\r\n\r\n                      <tbody><tr>\r\n                      \r\n                        <td align=\"center\" style=\"font-size: 13px;  line-height: 18px; color: #555555;  font-weight:normal; text-align: center; font-family:Arail,Tahoma, Helvetica, Arial, sans-serif;\">\r\n\r\n                          <span style=\"color: #2f9bbe;\">View online</span>\r\n                          \r\n                        </td>\r\n                      </tr>\r\n\r\n                    </tbody></table>\r\n                    </td>\r\n                  </tr>\r\n                  <!--end view online -->\r\n                  \r\n                \r\n                   <tr>\r\n                    <td height=\"20\" valign=\"top\"></td>\r\n                  </tr>\r\n\r\n                </tbody></table>\r\n                <!--end content nav -->\r\n\r\n               </td>\r\n             </tr>\r\n			 <tr>\r\n		   <td align=\"center\" valign=\"top\" class=\"fix-box\">\r\n			 <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"container\" style=\"background-color:#ffffff;\">\r\n			   <tbody>\r\n			   <tr>\r\n				 <td valign=\"top\" align=\"center\" style=\"background-color:#ffffff;\">\r\n				   <a href=\"#\">\r\n					 <img class=\"image-100-percent\" src=\"http://localhost/sikul/assets/themes/admin/img/email/Divider.png\" height=\"9\" alt=\"Divider\" style=\"display:block; max-height:9px; \" border=\"0\" hspace=\"0\" vspace=\"0\"> \r\n				   </a>\r\n				 </td>\r\n               </tr>\r\n     </tbody></table>\r\n   </td>\r\n </tr>\r\n           </tbody></table>\r\n           <!-- end top navigaton -->\r\n          </td>\r\n        </tr>\r\n      </tbody></table>\r\n      <!-- end top navigation container -->\r\n\r\n    </td>\r\n  </tr>\r\n   <!--END TOP NAVIGATION ?LAYOUT-->\r\n\r\n   \r\n <!-- START LAYOUT 11 --> \r\n<tr>\r\n <td align=\"center\" valign=\"top\" class=\"fix-box\">\r\n  <table width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\">\r\n    <tbody><tr>\r\n      <td valign=\"top\">\r\n        \r\n\r\n      \r\n\r\n   <!-- start layout-11 container width 600px --> \r\n   <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"container\" bgcolor=\"#ffffff\" style=\"background-color: #ffffff; \">\r\n\r\n\r\n     <tbody><tr>\r\n       <td valign=\"top\">\r\n\r\n         <!-- start layout-11 container width 560px --> \r\n         <table width=\"560\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\" bgcolor=\"#ffffff\" style=\"background-color: #ffffff;\">\r\n\r\n\r\n           <!-- start image content --> \r\n           <tbody><tr>\r\n             <td valign=\"top\" width=\"100%\">\r\n\r\n\r\n\r\n\r\n              <!-- start content left -->                      \r\n              <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"left\" class=\"full-width\">\r\n\r\n               <!--start space height --> \r\n               <tbody><tr>\r\n                 <td height=\"20\"></td>\r\n               </tr>\r\n               <!--end space height --> \r\n\r\n                \r\n\r\n                <!--start space height -->                      \r\n                <tr>\r\n                  <td height=\"20\"></td>\r\n                </tr>\r\n                <!--end space height -->                      \r\n\r\n                <tr>\r\n                  <td valign=\"top\">\r\n\r\n                    <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"left\">\r\n                      <tbody><tr>\r\n\r\n                        <!-- space width -->                      \r\n                        <td valign=\"top\">\r\n                          <table width=\"20\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"left\">\r\n                            <tbody><tr>\r\n                              <td valign=\"top\"></td>\r\n                            </tr>\r\n                          </tbody></table>\r\n                        </td>\r\n                        <!-- space width -->                      \r\n\r\n                         <!-- start text content --> \r\n                         <td valign=\"top\">\r\n                           <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"left\" class=\"width-small\">\r\n                            \r\n                             <tbody><tr>\r\n                               <td style=\"text-align: left;\"><font color=\"#a3a2a2\" face=\"Arial, Tahoma, Helvetica, sans-serif\"><span style=\"line-height: 22px;\">\r\n                                   From: [FROM]</span></font><br><font color=\"#a3a2a2\" face=\"Arial, Tahoma, Helvetica, sans-serif\"><span style=\"line-height: 22px;\"> \r\n								   To: [TO]</span></font><br><font color=\"#a3a2a2\" face=\"Arial, Tahoma, Helvetica, sans-serif\"><span style=\"line-height: 22px;\">\r\n                                  REF: </span></font><b style=\"color: rgb(163, 162, 162); font-family: Arial, Tahoma, Helvetica, sans-serif; font-size: 13px; font-weight: normal; line-height: 22px; text-decoration: underline;\">[SUBJECT]<br></b><font color=\"#a3a2a2\" face=\"Arial, Tahoma, Helvetica, sans-serif\"><span style=\"line-height: 22px;\">Meeting Title: [MEETING TITLE]<br>Start Date: [DATE FROM]</span></font><br><font color=\"#a3a2a2\" face=\"Arial, Tahoma, Helvetica, sans-serif\"><span style=\"line-height: 22px;\">End Date: [DATE TO]</span></font><br><font color=\"#a3a2a2\" face=\"Arial, Tahoma, Helvetica, sans-serif\"><span style=\"line-height: 22px;\">Venue: [VENUE]</span></font><br><font color=\"#a3a2a2\" face=\"Arial, Tahoma, Helvetica, sans-serif\"><span style=\"line-height: 22px;\">Importance: [IMPORTANCE]</span></font><br><font color=\"#a3a2a2\" face=\"Arial, Tahoma, Helvetica, sans-serif\"><span style=\"line-height: 22px;\">\r\n								 \r\n								 \r\n                                  [DESCRIPTION]\r\n                                 \r\n\r\n                               </span></font></td>\r\n                             </tr> \r\n                             <!-- start height -->\r\n                             <tr>\r\n                               <td valign=\"top\" height=\"10\"></td>\r\n                             </tr>\r\n                              <!-- end height -->\r\n\r\n                             <tr>\r\n                               <td style=\"font-size: 13px; line-height: 22px; font-family:Arial,Tahoma, Helvetica, sans-serif; color:#a3a2a2; font-weight:normal; text-align:left; \">\r\n\r\n                                   <span style=\"color: #2f9bbe;\">www.smartshule.com</span> : for more details. \r\n\r\n                               </td>\r\n                             </tr>                               \r\n                           </tbody></table>\r\n                         </td>\r\n                         <!-- end text content --> \r\n\r\n                      </tr>\r\n                    </tbody></table>\r\n\r\n                  </td>\r\n                </tr>\r\n\r\n                <!--start space height -->                      \r\n                <tr>\r\n                  <td height=\"20\"></td>\r\n                </tr>\r\n                <!--end space height --> \r\n              </tbody></table>\r\n              <!-- end content left --> \r\n\r\n             </td>\r\n           </tr>\r\n           <!-- end image content --> \r\n\r\n         </tbody></table>\r\n         <!-- end layout-11 container width 560px --> \r\n       </td>\r\n     </tr>\r\n   </tbody></table>\r\n   <!-- end layout-11 container width 600px --> \r\n    </td>\r\n    </tr>\r\n\r\n  </tbody></table>\r\n </td>\r\n</tr>\r\n\r\n\r\n <!-- END LAYOUT 11 --> \r\n\r\n\r\n\r\n  <!-- start bottom angle finish layout-->\r\n    <tr>\r\n      <td valign=\"top\" class=\"fix-box\">\r\n        <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\">\r\n          <tbody><tr>\r\n            <td valign=\"top\" width=\"20\">\r\n              <table width=\"20\" align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                <tbody><tr>\r\n\r\n                  <td valign=\"top\" align=\"left\">\r\n                    <a href=\"#\">\r\n                      <img src=\"http://localhost/sikul/assets/themes/admin/img/email/Angle-top-left.png\" width=\"20\" alt=\"Angle-top-left\" style=\"display:block; max-width:20px; \" border=\"0\" hspace=\"0\" vspace=\"0\">            \r\n                    </a>\r\n                  </td>\r\n\r\n                </tr>\r\n              </tbody></table>\r\n            </td>\r\n\r\n            <td valign=\"top\">\r\n             <table width=\"560\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\" bgcolor=\"#b4b3b3\" style=\"background-color: #b4b3b3; \">\r\n               <tbody><tr>\r\n\r\n                 <td valign=\"top\" align=\"center\" height=\"20\" bgcolor=\"#b4b3b3\" style=\"background-color: #b4b3b3; \"></td>\r\n\r\n               </tr>\r\n             </tbody></table>\r\n            </td>\r\n\r\n          <td valign=\"top\" width=\"20\">\r\n              <table width=\"20\" align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                <tbody><tr>\r\n\r\n                  <td valign=\"top\" align=\"left\">\r\n                    <a href=\"#\">\r\n                      <img src=\"http://localhost/sikul/assets/themes/admin/img/email/Angle-top-right.png\" width=\"20\" alt=\"Angle-top-left\" style=\"display:block; max-width:20px; \" border=\"0\" hspace=\"0\" vspace=\"0\">            \r\n                    </a>\r\n                  </td>\r\n\r\n                </tr>\r\n              </tbody></table>\r\n            </td>\r\n\r\n          </tr>\r\n        </tbody></table>\r\n      </td>\r\n    </tr>\r\n    <!-- end bottom angle finish layout-->\r\n\r\n\r\n<!-- START FOOTER layout-->\r\n  <tr>\r\n    <td align=\"center\" valign=\"top\" bgcolor=\"#ffffff\" style=\"background-color: #ffffff; \">\r\n\r\n      <!-- start top navigation container -->  \r\n      <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"container\" bgcolor=\"#ffffff\">\r\n        <tbody><tr>\r\n          <td valign=\"top\">\r\n\r\n            <table width=\"560\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\" bgcolor=\"#ffffff\">\r\n              <!--start space height -->                      \r\n              <tbody><tr>\r\n                <td height=\"10\"></td>\r\n              </tr>\r\n              <!--end space height --> \r\n              <tr>\r\n                <td valign=\"top\">\r\n\r\n\r\n                  <!-- start logo footer and address -->  \r\n                  <table width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                    <tbody><tr>\r\n                      <td valign=\"top\">\r\n\r\n                        <table width=\"300\" align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\">\r\n                          <tbody><tr>\r\n                            <td>\r\n                              <table align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\">\r\n\r\n                                <tbody><tr>\r\n                                  <td align=\"center\" valign=\"middle\">\r\n                                    <a href=\"#\">\r\n                                      <img src=\"http://localhost/sikul/assets/themes/admin/img/logo-sm.png\" width=\"124\" style=\"max-width:124px;\" alt=\"Logo\" border=\"0\" hspace=\"0\" vspace=\"0\">                        \r\n                                    </a>\r\n                                  </td>\r\n                                </tr>\r\n\r\n                              </tbody></table>\r\n                            </td>\r\n                          </tr>\r\n\r\n                          <tr>\r\n                            <td valign=\"top\" align=\"center\" style=\"font-size: 13px; line-height: 22px; font-family: Helvetica, sans-serif,Arial,Tahoma; color:#6d6d6d; font-weight:normal; text-align:left;\" class=\"text-center\">\r\n                              \r\n                                Company Name : <span style=\"color: #6d6d6d; font-weight: normal;\">Smart shule</span> <br>                 \r\n                                Mail Us : <span style=\"color: #2f9bbe; font-weight: normal;\"><a href=\"#\" style=\"text-decoration: none; color: #2f9bbe; font-weight: normal;\">info@smartshule.com</a> </span><br>\r\n                               Call Us : (254) 721 341 214\r\n\r\n                            </td>\r\n                          </tr>\r\n\r\n                        </tbody></table>\r\n\r\n                        <!--start icon socail navigation -->  \r\n                        <table border=\"0\" align=\"right\" cellpadding=\"0\" cellspacing=\"0\" class=\"container\">\r\n\r\n                           <!--start space height -->                      \r\n                          <tbody><tr>\r\n                            <td height=\"20\"></td>\r\n                          </tr>\r\n                          <!--end space height --> \r\n\r\n                           <tr>\r\n                            <td style=\"font-size: 22px; line-height: 24px; font-family: Arial,Tahoma,Helvetica, sans-serif; color:#555555; font-weight:normal; text-align:left; \" class=\"text-center\"><span style=\"color: #555555; font-weight: normal;\">Smart<a href=\"#\" style=\"text-decoration: none; color: #555555; font-weight: normal;\">&nbsp;<span style=\"color:#2f9bbe;\">Shule</span><br> \r\n                                    <span style=\"color:#a3a2a2; font-size:12px; line-height: 16px; font-weight: normal;\">FOLLOW US ON SOCAIL</span>\r\n                                 \r\n                                </a>\r\n                              </span>\r\n                            </td>\r\n                          </tr>\r\n\r\n                          <tr>\r\n                            <td valign=\"top\" align=\"left\">\r\n\r\n                              <table border=\"0\" align=\"left\" cellpadding=\"0\" cellspacing=\"0\" class=\"container\">\r\n                                <tbody><tr>\r\n                                  <td height=\"50\" align=\"center\" valign=\"middle\" class=\"clear-padding\">\r\n                                    <a href=\"#\">\r\n                                      <img src=\"http://localhost/sikul/assets/themes/admin/img/email/icon-facebook.jpg\" width=\"30\" alt=\"icon-facebook\" style=\"max-width:33px;\" border=\"0\" hspace=\"0\" vspace=\"0\">  \r\n                                    </a>\r\n                                  </td>\r\n                                  <td style=\"padding-left:5px; \" height=\"50\" align=\"center\" valign=\"middle\" class=\"clear-padding\">\r\n                                    <a href=\"#\">\r\n                                      <img src=\"http://localhost/sikul/assets/themes/admin/img/email/icon-twitter.jpg\" width=\"30\" alt=\"icon-twitter\" style=\"max-width:30px;\" border=\"0\" hspace=\"0\" vspace=\"0\">  \r\n                                    </a>\r\n                                  </td>\r\n                                  <td style=\"padding-left:5px; \" height=\"50\" align=\"center\" valign=\"middle\" class=\"clear-padding\">\r\n                                    <a href=\"#\">\r\n                                      <img src=\"http://localhost/sikul/assets/themes/admin/img/email/icon-googleplus.jpg\" width=\"30\" alt=\"icon-googleplus\" style=\"max-width:30px;\" border=\"0\" hspace=\"0\" vspace=\"0\">  \r\n                                    </a>\r\n                                  </td>\r\n                                  <td style=\"padding-left:5px;\" height=\"50\" align=\"center\" valign=\"middle\" class=\"clear-padding\">\r\n                                    <a href=\"#\">\r\n                                      <img src=\"http://localhost/sikul/assets/themes/admin/img/email/icon-rss.jpg\" width=\"30\" alt=\"icon-rss\" style=\"max-width:30px;\" border=\"0\" hspace=\"0\" vspace=\"0\">  \r\n                                    </a>\r\n                                  </td>\r\n                                  <td style=\"padding-left:5px;\" height=\"50\" align=\"center\" valign=\"middle\" class=\"clear-padding\">\r\n                                    <a href=\"#\">\r\n                                      </a></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table>','live',3,1402070442,NULL,NULL),(2,'General','general','This is General Email template','<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\r\n<meta name=\"viewport\" content=\"initial-scale=1.0\"> \r\n<meta name=\"format-detection\" content=\"telephone=no\">\r\n<title>Church Email</title>\r\n<style type=\"text/css\">\r\n\r\n/* Resets: see reset.css for details */\r\n.ReadMsgBody { width: 100%; background-color: #ffffff;}\r\n.ExternalClass {width: 100%; background-color: #ffffff;}\r\n.ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {line-height:100%;}\r\nhtml{width: 100%; }\r\nbody {-webkit-text-size-adjust:none; -ms-text-size-adjust:none; }\r\nbody {margin:0; padding:0;}\r\ntable {border-spacing:0;}\r\nimg{display:block !important;}\r\n\r\ntable td {border-collapse:collapse;}\r\n.yshortcuts a {border-bottom: none !important;}\r\n\r\n\r\n/* \r\n\r\nmain color = #2f9bbe\r\n\r\nother color = #186e8a\r\n\r\n\r\n*/\r\n\r\n\r\nimg{height:auto !important;}\r\n\r\n\r\n@media only screen and (max-width: 640px){\r\n  body{\r\n    width:auto!important;\r\n  }\r\n\r\n  table[class=\"container\"]{\r\n    width: 100%!important;\r\n    padding-left: 20px!important; \r\n    padding-right: 20px!important; \r\n  }\r\n\r\n  img[class=\"image-100-percent\"]{\r\n    width:100% !important;\r\n    height:auto !important;\r\n    max-width:100% !important;\r\n  }\r\n\r\n  img[class=\"small-image-100-percent\"]{\r\n    width:100% !important;\r\n    height:auto !important;\r\n  }\r\n\r\n  table[class=\"full-width\"]{\r\n    width:100% !important;\r\n  }\r\n\r\n  table[class=\"full-width-text\"]{\r\n    width:100% !important;\r\n     background-color:#186e8a;\r\n     padding-left:20px !important;\r\n     padding-right:20px !important;\r\n  }\r\n\r\n  table[class=\"full-width-text2\"]{\r\n    width:100% !important;\r\n     background-color:#f3f3f3;\r\n     padding-left:20px !important;\r\n     padding-right:20px !important; \r\n  }\r\n\r\n  table[class=\"col-2-3img\"]{\r\n    width:50% !important;\r\n    margin-right: 20px !important;\r\n  }\r\n    table[class=\"col-2-3img-last\"]{\r\n    width:50% !important;\r\n  }\r\n\r\n  table[class=\"col-2\"]{\r\n    width:47% !important;\r\n    margin-right:20px !important;\r\n  }\r\n\r\n  table[class=\"col-2-last\"]{\r\n    width:47% !important;\r\n  }\r\n\r\n  table[class=\"col-3\"]{\r\n    width:29% !important;\r\n    margin-right:20px !important;\r\n  }\r\n\r\n  table[class=\"col-3-last\"]{\r\n    width:29% !important;\r\n  }\r\n\r\n  table[class=\"row-2\"]{\r\n    width:50% !important;\r\n  }\r\n\r\n  td[class=\"text-center\"]{\r\n     text-align: center !important;\r\n   }\r\n\r\n  /* start clear and remove*/\r\n  table[class=\"remove\"]{\r\n    display:none !important;\r\n  }\r\n\r\n  td[class=\"remove\"]{\r\n    display:none !important;\r\n  }\r\n  /* end clear and remove*/\r\n\r\n  table[class=\"fix-box\"]{\r\n    padding-left:20px !important;\r\n    padding-right:20px !important;\r\n  }\r\n  td[class=\"fix-box\"]{\r\n    padding-left:20px !important;\r\n    padding-right:20px !important;\r\n  }\r\n\r\n  td[class=\"font-resize\"]{\r\n    font-size: 18px !important;\r\n    line-height: 22px !important;\r\n  }\r\n\r\n\r\n}\r\n\r\n\r\n\r\n@media only screen and (max-width: 479px){\r\n  body{\r\n    font-size:10px !important;\r\n  }\r\n\r\n   table[class=\"container2\"]{\r\n    width: 100%!important; \r\n    float:none !important;\r\n  }\r\n\r\n  img[class=\"image-100-percent\"]{\r\n    width:100% !important;\r\n    height:auto !important;\r\n    max-width:100% !important;\r\n    min-width:124px !important;\r\n  }\r\n    img[class=\"small-image-100-percent\"]{\r\n    width:100% !important;\r\n    height:auto !important;\r\n    max-width:100% !important;\r\n    min-width:124px !important;\r\n  }\r\n\r\n  table[class=\"full-width\"]{\r\n    width:100% !important;\r\n  }\r\n\r\n  table[class=\"full-width-text\"]{\r\n    width:100% !important;\r\n     background-color:#186e8a;\r\n     padding-left:20px !important;\r\n     padding-right:20px !important;\r\n  }\r\n\r\n  table[class=\"full-width-text2\"]{\r\n    width:100% !important;\r\n     background-color:#f3f3f3;\r\n     padding-left:20px !important;\r\n     padding-right:20px !important;\r\n  }\r\n\r\n\r\n\r\n  table[class=\"col-2\"]{\r\n    width:100% !important;\r\n    margin-right:0px !important;\r\n  }\r\n\r\n  table[class=\"col-2-last\"]{\r\n    width:100% !important;\r\n   \r\n  }\r\n\r\n  table[class=\"col-3\"]{\r\n    width:100% !important;\r\n    margin-right:0px !important;\r\n  }\r\n\r\n  table[class=\"col-3-last\"]{\r\n    width:100% !important;\r\n   \r\n  }\r\n\r\n    table[class=\"row-2\"]{\r\n    width:100% !important;\r\n  }\r\n\r\n\r\n  table[id=\"col-underline\"]{\r\n    float: none !important;\r\n    width: 100% !important;\r\n    border-bottom: 1px solid #eee;\r\n  }\r\n\r\n  td[id=\"col-underline\"]{\r\n    float: none !important;\r\n    width: 100% !important;\r\n    border-bottom: 1px solid #eee;\r\n  }\r\n\r\n  td[class=\"col-underline\"]{\r\n    float: none !important;\r\n    width: 100% !important;\r\n    border-bottom: 1px solid #eee;\r\n  }\r\n\r\n\r\n\r\n   /*start text center*/\r\n  td[class=\"text-center\"]{\r\n    text-align: center !important;\r\n\r\n  }\r\n\r\n  div[class=\"text-center\"]{\r\n    text-align: center !important;\r\n  }\r\n   /*end text center*/\r\n\r\n\r\n\r\n  /* start  clear and remove */\r\n\r\n  table[id=\"clear-padding\"]{\r\n    padding:0 !important;\r\n  }\r\n  td[id=\"clear-padding\"]{\r\n    padding:0 !important;\r\n  }\r\n  td[class=\"clear-padding\"]{\r\n    padding:0 !important;\r\n  }\r\n  table[class=\"remove-479\"]{\r\n    display:none !important;\r\n  }\r\n  td[class=\"remove-479\"]{\r\n    display:none !important;\r\n  }\r\n  table[class=\"clear-align\"]{\r\n    float:none !important;\r\n  }\r\n  /* end  clear and remove */\r\n\r\n  table[class=\"width-small\"]{\r\n    width:100% !important;\r\n  }\r\n\r\n  table[class=\"fix-box\"]{\r\n    padding-left:0px !important;\r\n    padding-right:0px !important;\r\n  }\r\n  td[class=\"fix-box\"]{\r\n    padding-left:0px !important;\r\n    padding-right:0px !important;\r\n  }\r\n    td[class=\"font-resize\"]{\r\n    font-size: 14px !important;\r\n  }\r\n\r\n}\r\n@media only screen and (max-width: 320px){\r\n  table[class=\"width-small\"]{\r\n    width:125px !important;\r\n  }\r\n  img[class=\"image-100-percent\"]{\r\n    width:100% !important;\r\n    height:auto !important;\r\n    max-width:100% !important;\r\n    min-width:124px !important;\r\n  }\r\n\r\n}\r\n</style>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<!--start 100% wrapper (white background) -->\r\n<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"background-color:#ececec;\">\r\n\r\n  <!-- START TAB TOP -->\r\n    <tbody><tr>\r\n      <td valign=\"top\">\r\n        <table width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"height:6px; background-color:#2f9bbe;\">\r\n          <tbody><tr>\r\n            <td valign=\"top\" height=\"6\">\r\n              <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\" style=\"height:6px;\">\r\n                <tbody><tr>\r\n                  <td valign=\"top\" align=\"center\"> \r\n                    <table width=\"150\" align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"clear-align\" style=\"height:6px; background-color:#186e8a;\">\r\n                      <tbody><tr>\r\n                        <td valign=\"top\" height=\"6\"></td>\r\n                      </tr>\r\n                    </tbody></table>\r\n                  </td>\r\n                </tr>\r\n              </tbody></table>\r\n            </td>\r\n          </tr>\r\n        </tbody></table>\r\n      </td>\r\n    </tr>\r\n  <!-- END TAB TOP -->\r\n\r\n  <!--START TOP NAVIGATION ?LAYOUT-->\r\n  <tr>\r\n    <td align=\"center\" valign=\"top\" class=\"fix-box\">\r\n      \r\n      <!-- start top navigation container -->\r\n      <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"container\" bgcolor=\"#ffffff\" style=\"background-color:#ffffff;\">\r\n      \r\n        <tbody><tr>\r\n          <td valign=\"top\">\r\n              \r\n\r\n            <!-- start top navigaton -->\r\n            <table width=\"560\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\">\r\n              <tbody><tr>\r\n                <td valign=\"top\">\r\n                \r\n                <table align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"container2\">\r\n                 \r\n                  <tbody><tr>\r\n                    <td align=\"center\" valign=\"middle\">\r\n                       <a href=\"#\"><img src=\"http://localhost/kanisa/assets/themes/admin/img/logo.png\" width=\"124\" style=\"max-width:124px;\" alt=\"Logo\" border=\"0\" hspace=\"0\" vspace=\"0\"></a>\r\n                    </td>\r\n                  </tr>\r\n\r\n                </tbody></table>\r\n\r\n                <!--start content nav -->\r\n                <table border=\"0\" align=\"right\" cellpadding=\"0\" cellspacing=\"0\" class=\"container2\">\r\n\r\n                   <tbody><tr>\r\n                    <td height=\"20\" valign=\"top\" class=\"remove-479\"></td>\r\n                  </tr>\r\n\r\n                   <!--start call us -->\r\n                  <tr>\r\n                     <td valign=\"top\" align=\"center\">\r\n                    \r\n                    <table align=\"right\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"clear-align\">\r\n                      <tbody><tr>\r\n                      \r\n\r\n                        <td style=\"font-size: 13px;  line-height: 18px; color: #555555;  font-weight:normal; text-align: center; font-family:Arail,Tahoma, Helvetica, Arial, sans-serif;\">\r\n\r\n                          <span style=\"color: #2f9bbe;\">CALL US</span>\r\n                          +254 721 341 214\r\n                        </td>\r\n                      </tr>\r\n\r\n                    </tbody></table>\r\n                    </td>\r\n                  </tr>\r\n                  <!--end call us -->\r\n\r\n                  <!-- start space height -->\r\n                   <tr>\r\n                    <td height=\"10\" valign=\"top\"></td>\r\n                  </tr>\r\n                  <!-- start space height -->\r\n\r\n\r\n                  <!--start view online -->\r\n                  <tr>\r\n                    <td valign=\"top\" align=\"center\">\r\n                    \r\n                    <table align=\"right\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"clear-align\">\r\n\r\n                      <tbody><tr>\r\n                      \r\n                        <td align=\"center\" style=\"font-size: 13px;  line-height: 18px; color: #555555;  font-weight:normal; text-align: center; font-family:Arail,Tahoma, Helvetica, Arial, sans-serif;\">\r\n\r\n                          <span style=\"color: #2f9bbe;\">View online</span>\r\n                          \r\n                        </td>\r\n                      </tr>\r\n\r\n                    </tbody></table>\r\n                    </td>\r\n                  </tr>\r\n                  <!--end view online -->\r\n                  \r\n                \r\n                   <tr>\r\n                    <td height=\"20\" valign=\"top\"></td>\r\n                  </tr>\r\n\r\n                </tbody></table>\r\n                <!--end content nav -->\r\n\r\n               </td>\r\n             </tr>\r\n			 <tr>\r\n		   <td align=\"center\" valign=\"top\" class=\"fix-box\">\r\n			 <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"container\" style=\"background-color:#ffffff;\">\r\n			   <tbody>\r\n			   <tr>\r\n				 <td valign=\"top\" align=\"center\" style=\"background-color:#ffffff;\">\r\n				   <a href=\"#\">\r\n					 <img class=\"image-100-percent\" src=\"http://localhost/church/assets/themes/admin/img/email/Divider.png\" height=\"9\" alt=\"Divider\" style=\"display:block; max-height:9px; \" border=\"0\" hspace=\"0\" vspace=\"0\"> \r\n				   </a>\r\n				 </td>\r\n               </tr>\r\n     </tbody></table>\r\n   </td>\r\n </tr>\r\n           </tbody></table>\r\n           <!-- end top navigaton -->\r\n          </td>\r\n        </tr>\r\n      </tbody></table>\r\n      <!-- end top navigation container -->\r\n\r\n    </td>\r\n  </tr>\r\n   <!--END TOP NAVIGATION ?LAYOUT-->\r\n\r\n   \r\n <!-- START LAYOUT 11 --> \r\n<tr>\r\n <td align=\"center\" valign=\"top\" class=\"fix-box\">\r\n  <table width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\">\r\n    <tbody><tr>\r\n      <td valign=\"top\">\r\n        \r\n\r\n      \r\n\r\n   <!-- start layout-11 container width 600px --> \r\n   <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"container\" bgcolor=\"#ffffff\" style=\"background-color: #ffffff; \">\r\n\r\n\r\n     <tbody><tr>\r\n       <td valign=\"top\">\r\n\r\n         <!-- start layout-11 container width 560px --> \r\n         <table width=\"560\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\" bgcolor=\"#ffffff\" style=\"background-color: #ffffff;\">\r\n\r\n\r\n           <!-- start image content --> \r\n           <tbody><tr>\r\n             <td valign=\"top\" width=\"100%\">\r\n\r\n\r\n\r\n\r\n              <!-- start content left -->                      \r\n              <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"left\" class=\"full-width\">\r\n\r\n               <!--start space height --> \r\n               <tbody><tr>\r\n                 <td height=\"20\"></td>\r\n               </tr>\r\n               <!--end space height --> \r\n\r\n                \r\n\r\n                <!--start space height -->                      \r\n                <tr>\r\n                  <td height=\"20\"></td>\r\n                </tr>\r\n                <!--end space height -->                      \r\n\r\n                <tr>\r\n                  <td valign=\"top\">\r\n\r\n                    <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"left\">\r\n                      <tbody><tr>\r\n\r\n                        <!-- space width -->                      \r\n                        <td valign=\"top\">\r\n                          <table width=\"20\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"left\">\r\n                            <tbody><tr>\r\n                              <td valign=\"top\"></td>\r\n                            </tr>\r\n                          </tbody></table>\r\n                        </td>\r\n                        <!-- space width -->                      \r\n\r\n                         <!-- start text content --> \r\n                         <td valign=\"top\">\r\n                           <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"left\" class=\"width-small\">\r\n                            \r\n                             <tbody><tr>\r\n                               <td style=\"font-size: 13px; line-height: 22px; font-family:Arial,Tahoma, Helvetica, sans-serif; color:#a3a2a2; font-weight:normal; text-align:left; \">\r\n                                   From: [FROM]<br> \r\n								   To: [TO]<br>\r\n                                  REF: <b style=\"text-decoration:underline\">[SUBJECT]</b><br>\r\n								 \r\n								 \r\n                                  [DESCRIPTION]\r\n                                 \r\n\r\n                               </td>\r\n                             </tr> \r\n                             <!-- start height -->\r\n                             <tr>\r\n                               <td valign=\"top\" height=\"10\"></td>\r\n                             </tr>\r\n                              <!-- end height -->\r\n\r\n                             <tr>\r\n                               <td style=\"font-size: 13px; line-height: 22px; font-family:Arial,Tahoma, Helvetica, sans-serif; color:#a3a2a2; font-weight:normal; text-align:left; \">\r\n\r\n                                   <span style=\"color: #2f9bbe;\">www.smartchurch.com</span> : for more details. \r\n\r\n                               </td>\r\n                             </tr>                               \r\n                           </tbody></table>\r\n                         </td>\r\n                         <!-- end text content --> \r\n\r\n                      </tr>\r\n                    </tbody></table>\r\n\r\n                  </td>\r\n                </tr>\r\n\r\n                <!--start space height -->                      \r\n                <tr>\r\n                  <td height=\"20\"></td>\r\n                </tr>\r\n                <!--end space height --> \r\n              </tbody></table>\r\n              <!-- end content left --> \r\n\r\n             </td>\r\n           </tr>\r\n           <!-- end image content --> \r\n\r\n         </tbody></table>\r\n         <!-- end layout-11 container width 560px --> \r\n       </td>\r\n     </tr>\r\n   </tbody></table>\r\n   <!-- end layout-11 container width 600px --> \r\n    </td>\r\n    </tr>\r\n\r\n  </tbody></table>\r\n </td>\r\n</tr>\r\n\r\n\r\n <!-- END LAYOUT 11 --> \r\n\r\n\r\n\r\n  <!-- start bottom angle finish layout-->\r\n    <tr>\r\n      <td valign=\"top\" class=\"fix-box\">\r\n        <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\">\r\n          <tbody><tr>\r\n            <td valign=\"top\" width=\"20\">\r\n              <table width=\"20\" align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                <tbody><tr>\r\n\r\n                  <td valign=\"top\" align=\"left\">\r\n                    <a href=\"#\">\r\n                      <img src=\"http://localhost/church/assets/themes/admin/img/email/Angle-top-left.png\" width=\"20\" alt=\"Angle-top-left\" style=\"display:block; max-width:20px; \" border=\"0\" hspace=\"0\" vspace=\"0\">            \r\n                    </a>\r\n                  </td>\r\n\r\n                </tr>\r\n              </tbody></table>\r\n            </td>\r\n\r\n            <td valign=\"top\">\r\n             <table width=\"560\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\" bgcolor=\"#b4b3b3\" style=\"background-color: #b4b3b3; \">\r\n               <tbody><tr>\r\n\r\n                 <td valign=\"top\" align=\"center\" height=\"20\" bgcolor=\"#b4b3b3\" style=\"background-color: #b4b3b3; \"></td>\r\n\r\n               </tr>\r\n             </tbody></table>\r\n            </td>\r\n\r\n          <td valign=\"top\" width=\"20\">\r\n              <table width=\"20\" align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                <tbody><tr>\r\n\r\n                  <td valign=\"top\" align=\"left\">\r\n                    <a href=\"#\">\r\n                      <img src=\"http://localhost/church/assets/themes/admin/img/email/Angle-top-right.png\" width=\"20\" alt=\"Angle-top-left\" style=\"display:block; max-width:20px; \" border=\"0\" hspace=\"0\" vspace=\"0\">            \r\n                    </a>\r\n                  </td>\r\n\r\n                </tr>\r\n              </tbody></table>\r\n            </td>\r\n\r\n          </tr>\r\n        </tbody></table>\r\n      </td>\r\n    </tr>\r\n    <!-- end bottom angle finish layout-->\r\n\r\n\r\n<!-- START FOOTER layout-->\r\n  <tr>\r\n    <td align=\"center\" valign=\"top\" bgcolor=\"#ffffff\" style=\"background-color: #ffffff; \">\r\n\r\n      <!-- start top navigation container -->  \r\n      <table width=\"600\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"container\" bgcolor=\"#ffffff\">\r\n        <tbody><tr>\r\n          <td valign=\"top\">\r\n\r\n            <table width=\"560\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\" bgcolor=\"#ffffff\">\r\n              <!--start space height -->                      \r\n              <tbody><tr>\r\n                <td height=\"10\"></td>\r\n              </tr>\r\n              <!--end space height --> \r\n              <tr>\r\n                <td valign=\"top\">\r\n\r\n\r\n                  <!-- start logo footer and address -->  \r\n                  <table width=\"100%\" align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                    <tbody><tr>\r\n                      <td valign=\"top\">\r\n\r\n                        <table width=\"300\" align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\">\r\n                          <tbody><tr>\r\n                            <td>\r\n                              <table align=\"left\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"full-width\">\r\n\r\n                                <tbody><tr>\r\n                                  <td align=\"center\" valign=\"middle\">\r\n                                    <a href=\"#\">\r\n                                      <img src=\"http://localhost/kanisa/assets/themes/admin/img/logo.png\" width=\"124\" style=\"max-width:124px;\" alt=\"Logo\" border=\"0\" hspace=\"0\" vspace=\"0\">                        \r\n                                    </a>\r\n                                  </td>\r\n                                </tr>\r\n\r\n                              </tbody></table>\r\n                            </td>\r\n                          </tr>\r\n\r\n                          <tr>\r\n                            <td valign=\"top\" align=\"center\" style=\"font-size: 13px; line-height: 22px; font-family: Helvetica, sans-serif,Arial,Tahoma; color:#6d6d6d; font-weight:normal; text-align:left;\" class=\"text-center\">\r\n                              \r\n                                Company Name : <span style=\"color: #6d6d6d; font-weight: normal;\">Smart church</span> <br>                 \r\n                                Mail Us : <span style=\"color: #2f9bbe; font-weight: normal;\"><a href=\"#\" style=\"text-decoration: none; color: #2f9bbe; font-weight: normal;\">info@smartchurch.com</a> </span><br>\r\n                               Call Us : (254) 721 341 214\r\n\r\n                            </td>\r\n                          </tr>\r\n\r\n                        </tbody></table>\r\n\r\n                        <!--start icon socail navigation -->  \r\n                        <table border=\"0\" align=\"right\" cellpadding=\"0\" cellspacing=\"0\" class=\"container\">\r\n\r\n                           <!--start space height -->                      \r\n                          <tbody><tr>\r\n                            <td height=\"20\"></td>\r\n                          </tr>\r\n                          <!--end space height --> \r\n\r\n                           <tr>\r\n                            <td style=\"font-size: 22px; line-height: 24px; font-family: Arial,Tahoma,Helvetica, sans-serif; color:#555555; font-weight:normal; text-align:left; \" class=\"text-center\"><span style=\"color: #555555; font-weight: normal;\">Smart<a href=\"#\" style=\"text-decoration: none; color: #555555; font-weight: normal;\">&nbsp;<span style=\"color:#2f9bbe;\">Church</span><br> \r\n                                    <span style=\"color:#a3a2a2; font-size:12px; line-height: 16px; font-weight: normal;\">FOLLOW US ON SOCAIL</span>\r\n                                 \r\n                                </a>\r\n                              </span>\r\n                            </td>\r\n                          </tr>\r\n\r\n                          <tr>\r\n                            <td valign=\"top\" align=\"left\">\r\n\r\n                              <table border=\"0\" align=\"left\" cellpadding=\"0\" cellspacing=\"0\" class=\"container\">\r\n                                <tbody><tr>\r\n                                  <td height=\"50\" align=\"center\" valign=\"middle\" class=\"clear-padding\">\r\n                                    <a href=\"#\">\r\n                                      <img src=\"http://localhost/church/assets/themes/admin/img/email/icon-facebook.jpg\" width=\"30\" alt=\"icon-facebook\" style=\"max-width:33px;\" border=\"0\" hspace=\"0\" vspace=\"0\">  \r\n                                    </a>\r\n                                  </td>\r\n                                  <td style=\"padding-left:5px; \" height=\"50\" align=\"center\" valign=\"middle\" class=\"clear-padding\">\r\n                                    <a href=\"#\">\r\n                                      <img src=\"http://localhost/church/assets/themes/admin/img/email/icon-twitter.jpg\" width=\"30\" alt=\"icon-twitter\" style=\"max-width:30px;\" border=\"0\" hspace=\"0\" vspace=\"0\">  \r\n                                    </a>\r\n                                  </td>\r\n                                  <td style=\"padding-left:5px; \" height=\"50\" align=\"center\" valign=\"middle\" class=\"clear-padding\">\r\n                                    <a href=\"#\">\r\n                                      <img src=\"http://localhost/church/assets/themes/admin/img/email/icon-googleplus.jpg\" width=\"30\" alt=\"icon-googleplus\" style=\"max-width:30px;\" border=\"0\" hspace=\"0\" vspace=\"0\">  \r\n                                    </a>\r\n                                  </td>\r\n                                  <td style=\"padding-left:5px;\" height=\"50\" align=\"center\" valign=\"middle\" class=\"clear-padding\">\r\n                                    <a href=\"#\">\r\n                                      <img src=\"http://localhost/church/assets/themes/admin/img/email/icon-rss.jpg\" width=\"30\" alt=\"icon-rss\" style=\"max-width:30px;\" border=\"0\" hspace=\"0\" vspace=\"0\">  \r\n                                    </a>\r\n                                  </td>\r\n                                  <td style=\"padding-left:5px;\" height=\"50\" align=\"center\" valign=\"middle\" class=\"clear-padding\">\r\n                                    <a href=\"#\">\r\n                                      </a></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table>','live',3,1402070603,NULL,NULL);
/*!40000 ALTER TABLE `email_templates` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `emails`
DROP TABLE IF EXISTS `emails`;
CREATE TABLE `emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` blob,
  `sent_to` blob,
  `recipient` blob,
  `cc` blob,
  `description` blob,
  `attachment` blob,
  `type` blob,
  `status` blob,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- Dumping data for table `emails`
LOCK TABLES `emails` WRITE;
/*!40000 ALTER TABLE `emails` DISABLE KEYS */;
INSERT INTO `emails` VALUES (1,0xbb0a1c853427bd6291bf0bf9df925c58,0xa545acd59a5c75d85e429545b1b87e8a,NULL,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xb05a943501c5354e3f188d87705d5409,0xe4c3830448357bb7a322a7e432a4b307,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xe90f37fead107605a19ebc8e88485d87,NULL),(2,0xbb0a1c853427bd6291bf0bf9df925c58,0xa545acd59a5c75d85e429545b1b87e8a,NULL,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x197411a37e748ee53788b100d2dc22c7,0xe4c3830448357bb7a322a7e432a4b307,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x8d7d4d0c2db93bc1ebe9285a4d38e90a,NULL),(3,0xbb0a1c853427bd6291bf0bf9df925c58,0xa545acd59a5c75d85e429545b1b87e8a,NULL,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xcfb732c7927cb296269952aa76040149,0xe4c3830448357bb7a322a7e432a4b307,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x6bf11d5e9b50dd43dd57b9c66a21182b,NULL),(4,0xbb0a1c853427bd6291bf0bf9df925c58,0xa545acd59a5c75d85e429545b1b87e8a,NULL,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xfe96bf146fadced14ee31ce3e7c3b686,0xe4c3830448357bb7a322a7e432a4b307,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xb9b2ed3ee8171f817a0a8aa0918a7f0d,NULL),(5,0xbb0a1c853427bd6291bf0bf9df925c58,0xa545acd59a5c75d85e429545b1b87e8a,NULL,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xb59fe4f437182267926a9ff73399e0dc,0xe4c3830448357bb7a322a7e432a4b307,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x7d22261aa27adf5e3e2d0ea232fb78d6,NULL),(6,0x47722aa3f7a32c86a3db19b0270801351942025fb8998a1c560ff7b8e6903ef5,0xa545acd59a5c75d85e429545b1b87e8a,NULL,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x63c0d6520ced475825ef3aef3ec724ca,0xe4c3830448357bb7a322a7e432a4b307,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x94b4e69fe9b75b8df861f83be9416519,NULL),(9,0x47722aa3f7a32c86a3db19b0270801351942025fb8998a1c560ff7b8e6903ef5,0xa545acd59a5c75d85e429545b1b87e8a,NULL,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0xf38ef9c236d7b977c4104eddd1fd2856,0xe4c3830448357bb7a322a7e432a4b307,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x1258705f8e7b54bff4617be5f2a7552c,NULL);
/*!40000 ALTER TABLE `emails` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `employee_allowances`
DROP TABLE IF EXISTS `employee_allowances`;
CREATE TABLE `employee_allowances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_id` int(11) DEFAULT NULL,
  `allowance_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Dumping data for table `employee_allowances`
LOCK TABLES `employee_allowances` WRITE;
/*!40000 ALTER TABLE `employee_allowances` DISABLE KEYS */;
INSERT INTO `employee_allowances` VALUES (1,3,2,1,NULL,1422368378,NULL),(2,1,2,1,NULL,1422441243,NULL),(3,1,2,1,NULL,1422441255,NULL);
/*!40000 ALTER TABLE `employee_allowances` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `employee_deductions`
DROP TABLE IF EXISTS `employee_deductions`;
CREATE TABLE `employee_deductions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_id` int(11) DEFAULT NULL,
  `deduction_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- Dumping data for table `employee_deductions`
LOCK TABLES `employee_deductions` WRITE;
/*!40000 ALTER TABLE `employee_deductions` DISABLE KEYS */;
INSERT INTO `employee_deductions` VALUES (1,2,2,1,NULL,1422367839,NULL),(2,2,1,1,NULL,1422367839,NULL),(3,3,2,1,NULL,1422368378,NULL),(4,3,3,1,NULL,1422368378,NULL),(5,3,1,1,NULL,1422368378,NULL),(6,1,2,1,NULL,1422441243,NULL),(7,1,3,1,NULL,1422441243,NULL),(8,1,1,1,NULL,1422441243,NULL),(9,1,2,1,NULL,1422441255,NULL),(10,1,1,1,NULL,1422441255,NULL);
/*!40000 ALTER TABLE `employee_deductions` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `events`
DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL DEFAULT '',
  `start_date` int(11) DEFAULT NULL,
  `end_date` int(11) DEFAULT NULL,
  `venue` varchar(256) NOT NULL DEFAULT '',
  `file` varchar(256) NOT NULL DEFAULT '',
  `status` varchar(32) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Dumping data for table `events`
LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (1,'Free Medical',1424034000,1424725200,'Kaloleni','','1','This is a new event',1,NULL,1422885994,NULL),(2,'Sunday School Event',1428354000,1424638800,'Church Hall','dancan.png','1','This is sunday school event',1,1,1422887258,1423333837),(3,'Women Meeting',1422738000,1422997200,'Church Hall','','1','All women to meet in church next week for briefing',1,NULL,1423224357,NULL),(4,'Sports Day',1422824400,1422997200,'Jericho Sports ground','','1','this is sports description',1,NULL,1423230441,NULL),(5,'Mission',1461013200,1461272400,'Nairobi','','1','Mission details',1,NULL,1461075994,NULL),(6,'Sunday Sch out',1459803600,1460754000,'Naivasha','','1','Event at Naivasha',1,NULL,1461077596,NULL);
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `expenses`
DROP TABLE IF EXISTS `expenses`;
CREATE TABLE `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `item` int(11) DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `person_responsible` varchar(32) NOT NULL DEFAULT '',
  `file` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- Dumping data for table `expenses`
LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
INSERT INTO `expenses` VALUES (1,1421096400,4,1,1,2000,'2','write_up.doc','Power was paid',1,NULL,1421242672,NULL),(2,1421010000,2,2,1,5000,'3','','Rice Bought',1,1,1421243234,1421243745),(3,1420923600,2,2,1,5000,'1','','test',1,NULL,1421306542,NULL),(4,1423515600,4,1,1,2500,'3','','This is paid',1,NULL,1423131284,NULL),(5,1424206800,5,3,1,5000,'2','','Collection paid',1,NULL,1423131323,NULL),(6,1424725200,6,4,1,4500,'3','','Carpet Cleaning',1,NULL,1423131400,NULL),(7,1432587600,7,2,1,2600,'2','','This was paid to client',1,NULL,1432641913,NULL),(8,1432414800,4,1,1,4580,'2','','Was paid by M-pesa',1,NULL,1432641941,NULL),(9,1433624400,4,1,1,2500,'2','','paid',1,NULL,1433834294,NULL),(10,1433797200,5,3,1,1500,'3','','',1,NULL,1433834317,NULL),(11,1461013200,7,4,1,2500,'3','','Given',1,NULL,1461075651,NULL),(12,1461013200,4,1,1,8500,'3','','',1,NULL,1461075676,NULL);
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `expenses_category`
DROP TABLE IF EXISTS `expenses_category`;
CREATE TABLE `expenses_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Dumping data for table `expenses_category`
LOCK TABLES `expenses_category` WRITE;
/*!40000 ALTER TABLE `expenses_category` DISABLE KEYS */;
INSERT INTO `expenses_category` VALUES (1,'Electricity','0',1,NULL,1421242519,NULL),(2,'Kitchen','0',1,NULL,1421243203,NULL),(3,'Water','0',1,NULL,1423131305,NULL),(4,'Cleaning','0',1,NULL,1423131365,NULL);
/*!40000 ALTER TABLE `expenses_category` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `expenses_items`
DROP TABLE IF EXISTS `expenses_items`;
CREATE TABLE `expenses_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- Dumping data for table `expenses_items`
LOCK TABLES `expenses_items` WRITE;
/*!40000 ALTER TABLE `expenses_items` DISABLE KEYS */;
INSERT INTO `expenses_items` VALUES (1,'test','',1,NULL,1421169935,NULL),(2,'Rice','0',1,NULL,1421170331,NULL),(3,'Mangose','0',1,NULL,1421170377,NULL),(4,'Electricity','0',1,NULL,1421242276,NULL),(5,'Water','0',1,NULL,1421848704,NULL),(6,'Carpet','0',1,NULL,1423131374,NULL),(7,'Soap','0',1,NULL,1432634684,NULL);
/*!40000 ALTER TABLE `expenses_items` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `files`
DROP TABLE IF EXISTS `files`;
CREATE TABLE `files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL DEFAULT '',
  `type` varchar(32) NOT NULL DEFAULT '',
  `file` varchar(256) NOT NULL DEFAULT '',
  `fpath` varchar(256) NOT NULL DEFAULT '',
  `Column 6` varchar(256) NOT NULL DEFAULT '',
  `filesize` varchar(256) NOT NULL DEFAULT '',
  `folder` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table `files`
LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
INSERT INTO `files` VALUES (1,'old constitution','pdf','SMS_to_be_sent.pdf','Constitutions/2015/','','79.17',6,1,NULL,1433155678,NULL),(2,'New constitution','word','mshamba_template.doc','Constitutions/2015/','','81',6,1,NULL,1433155958,NULL),(3,'Payslip','pdf','carlile_inv1.pdf','Payrolls/2015/','','80.69',5,1,NULL,1433156138,NULL),(4,'Jan Payslips','csv','hbcs.csv','Payrolls/2015/','','0.18',5,1,NULL,1433231790,NULL),(5,'Revised Const.','csv','hbcs.csv','Constitutions/2015/','','0.18',6,1,NULL,1433231957,NULL),(6,'New Cost.','pdf','carlile_inv1.pdf','Constitutions/2015/','','80.69',6,1,NULL,1433239423,NULL),(7,'New doc','word','carlile_inv1.doc','Constitutions/2015/','','84.5',6,1,NULL,1433240024,NULL),(8,'Sample','pdf','sample-pdf.pdf','Constitution/2016/','','48.4',6,1,NULL,1471351624,NULL);
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `files_old`
DROP TABLE IF EXISTS `files_old`;
CREATE TABLE `files_old` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL DEFAULT '',
  `type` varchar(32) NOT NULL DEFAULT '',
  `file` varchar(256) NOT NULL DEFAULT '',
  `fpath` varchar(256) NOT NULL DEFAULT '',
  `Column 6` varchar(256) NOT NULL DEFAULT '',
  `filesize` varchar(256) NOT NULL DEFAULT '',
  `folder` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `files_old`
LOCK TABLES `files_old` WRITE;
/*!40000 ALTER TABLE `files_old` DISABLE KEYS */;
/*!40000 ALTER TABLE `files_old` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `folders`
DROP TABLE IF EXISTS `folders`;
CREATE TABLE `folders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Dumping data for table `folders`
LOCK TABLES `folders` WRITE;
/*!40000 ALTER TABLE `folders` DISABLE KEYS */;
INSERT INTO `folders` VALUES (1,'Sample','new folder',1,1,1432883373,1433679929),(2,'Listings','Members Listing',1,1,1432887269,1433231180),(3,'Sermons Folder','Sermon File',1,1,1432887649,1432887658),(4,'Budgets Folder','Church Budgets Foldet',1,1,1432887682,1433153595),(5,'Payrolls Folder','Payrolls Folder',1,1,1432887767,1433153508),(6,'Constitutions','Church Constitution',1,1,1433153403,1433153482);
/*!40000 ALTER TABLE `folders` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `group_permissions`
DROP TABLE IF EXISTS `group_permissions`;
CREATE TABLE `group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `resource_id` int(11) NOT NULL,
  `campus_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table `group_permissions`
LOCK TABLES `group_permissions` WRITE;
/*!40000 ALTER TABLE `group_permissions` DISABLE KEYS */;
INSERT INTO `group_permissions` VALUES (1,4,1,NULL,1,1,1431426075,1431599246),(2,4,2,NULL,1,1,1431426211,1431599246),(3,4,5,NULL,1,NULL,1431426211,NULL),(4,4,10,NULL,1,NULL,1431426211,NULL),(5,4,11,NULL,1,NULL,1431426211,NULL),(6,4,15,NULL,1,NULL,1431426211,NULL),(7,4,16,NULL,1,NULL,1431426212,NULL),(8,4,19,NULL,1,NULL,1431426212,NULL),(9,4,21,NULL,1,NULL,1431426212,NULL),(10,4,27,NULL,1,NULL,1431426212,NULL),(11,4,28,NULL,1,NULL,1431426212,NULL),(12,4,29,NULL,1,NULL,1431426212,NULL),(13,4,30,NULL,1,NULL,1431426212,NULL),(14,4,31,NULL,1,NULL,1431426212,NULL),(15,4,32,NULL,1,NULL,1431426212,NULL),(16,4,33,NULL,1,NULL,1431426212,NULL),(17,4,39,NULL,1,NULL,1431426212,NULL),(18,4,42,NULL,1,NULL,1431426212,NULL),(19,4,47,NULL,1,NULL,1431426212,NULL),(20,4,3,NULL,1,NULL,1431599246,NULL);
/*!40000 ALTER TABLE `group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `groups`
DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table `groups`
LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES (1,'admin','Administrator',NULL,NULL,NULL,NULL),(2,'members','General Users',NULL,1,NULL,1379858359),(3,'committee','Committee Members',1,1,1379858307,1422967213),(4,'pastor','Church Pastors',1,1,1422970174,1422970198);
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `hbc_meetings`
DROP TABLE IF EXISTS `hbc_meetings`;
CREATE TABLE `hbc_meetings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `hbc` varchar(32) NOT NULL DEFAULT '',
  `host` varchar(256) NOT NULL DEFAULT '',
  `hosts_phone_no` varchar(256) NOT NULL DEFAULT '',
  `house_number` varchar(256) NOT NULL DEFAULT '',
  `service_leader` varchar(32) NOT NULL DEFAULT '',
  `preacher` varchar(256) NOT NULL DEFAULT '',
  `brief_description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Dumping data for table `hbc_meetings`
LOCK TABLES `hbc_meetings` WRITE;
/*!40000 ALTER TABLE `hbc_meetings` DISABLE KEYS */;
INSERT INTO `hbc_meetings` VALUES (1,1423602000,'1','5','(072) 154-8858','Umoja B30','19','24','Come all',1,1,1423058964,1423060619),(2,1423602000,'3','6','(012) 458-8877','Buru Phase3 Dr32','20','25','No new message',1,1,1423060364,1423060642);
/*!40000 ALTER TABLE `hbc_meetings` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `hbcs`
DROP TABLE IF EXISTS `hbcs`;
CREATE TABLE `hbcs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `estate` varchar(256) NOT NULL DEFAULT '',
  `meeting_day` varchar(32) NOT NULL DEFAULT '',
  `meeting_time` varchar(50) DEFAULT NULL,
  `overall_leader` varchar(32) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Dumping data for table `hbcs`
LOCK TABLES `hbcs` WRITE;
/*!40000 ALTER TABLE `hbcs` DISABLE KEYS */;
INSERT INTO `hbcs` VALUES (1,'Isreal','Buruburu','monday','05:00 PM','17','The israel',1,1,1420885799,1420886468),(2,'Jericho','Umoja','tuesday','07:30 AM','16','',1,NULL,1420886505,NULL),(3,'Golgotha','Bahati','sunday','06:30 PM','20','',1,NULL,1420886547,NULL),(4,'Umoja One','Umoja','tuesday','01:15 PM','16','This is HBC',1,NULL,1424946211,NULL);
/*!40000 ALTER TABLE `hbcs` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `hymns_manager`
DROP TABLE IF EXISTS `hymns_manager`;
CREATE TABLE `hymns_manager` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hymn_title` varchar(256) NOT NULL DEFAULT '',
  `composer` varchar(256) NOT NULL DEFAULT '',
  `category` varchar(32) NOT NULL DEFAULT '',
  `lyrics` text,
  `file` varchar(256) NOT NULL DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `hymns_manager`
LOCK TABLES `hymns_manager` WRITE;
/*!40000 ALTER TABLE `hymns_manager` DISABLE KEYS */;
/*!40000 ALTER TABLE `hymns_manager` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `meetings`
DROP TABLE IF EXISTS `meetings`;
CREATE TABLE `meetings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL DEFAULT '',
  `start_date` int(11) DEFAULT NULL,
  `end_date` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `venue` varchar(256) NOT NULL DEFAULT '',
  `others` varchar(256) DEFAULT NULL,
  `importance` varchar(256) NOT NULL DEFAULT '',
  `guests` varchar(32) NOT NULL DEFAULT '',
  `sms_alert` varchar(32) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Dumping data for table `meetings`
LOCK TABLES `meetings` WRITE;
/*!40000 ALTER TABLE `meetings` DISABLE KEYS */;
INSERT INTO `meetings` VALUES (1,'Members Meeting',1424725200,1424898000,1,'Assembly Hall','','Medium','all members','1','We shall be having meeting next week please come',1,NULL,1422883208,NULL),(2,'Mens meeting',1424638800,1424898000,1,'Assembly Hall','Men Ministry','High','ministry','0','We shall be having meeting on the said dates',1,NULL,1422883889,NULL),(3,'Quick Shopping',1461013200,1461272400,1,'Nairobi','0','Medium','all members','0','All members',1,NULL,1461076148,NULL);
/*!40000 ALTER TABLE `meetings` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `member_groups`
DROP TABLE IF EXISTS `member_groups`;
CREATE TABLE `member_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Dumping data for table `member_groups`
LOCK TABLES `member_groups` WRITE;
/*!40000 ALTER TABLE `member_groups` DISABLE KEYS */;
INSERT INTO `member_groups` VALUES (1,28,3,NULL,1,NULL,1424772418),(2,28,2,NULL,1,NULL,1424772418),(3,30,4,NULL,1,NULL,1433246304),(4,27,2,NULL,1,NULL,1433246342);
/*!40000 ALTER TABLE `member_groups` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `member_ministries`
DROP TABLE IF EXISTS `member_ministries`;
CREATE TABLE `member_ministries` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` varchar(20) NOT NULL,
  `ministry_id` varchar(100) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table `member_ministries`
LOCK TABLES `member_ministries` WRITE;
/*!40000 ALTER TABLE `member_ministries` DISABLE KEYS */;
INSERT INTO `member_ministries` VALUES (5,'22','2',1,NULL,1420892294,NULL),(6,'24','3',1,NULL,1420892488,NULL),(7,'24','2',1,NULL,1420892488,NULL),(8,'24','4',1,NULL,1420895295,NULL),(10,'23','3',1,NULL,1420895852,NULL),(11,'22','1',1,NULL,1421762373,NULL),(14,'22','3',1,NULL,1421998728,NULL),(15,'25','3',1,NULL,1422891424,NULL),(16,'25','2',1,NULL,1422891424,NULL),(17,'19','3',1,NULL,1423124189,NULL),(18,'19','1',1,NULL,1423124189,NULL),(19,'19','2',1,NULL,1423124189,NULL),(20,'16','3',1,NULL,1423124340,NULL),(21,'16','1',1,NULL,1423124340,NULL),(22,'16','2',1,NULL,1423124340,NULL),(23,'18','3',1,NULL,1423124937,NULL),(24,'18','1',1,NULL,1423124937,NULL),(25,'18','2',1,NULL,1423124937,NULL),(26,'5','1',1,NULL,1423125074,NULL),(27,'5','4',1,NULL,1423125074,NULL),(28,'23','3',1,NULL,1423127751,NULL),(29,'23','2',1,NULL,1423127751,NULL),(30,'26','1',1,NULL,1424677668,NULL),(31,'26','2',1,NULL,1424677668,NULL),(32,'26','4',1,NULL,1424677668,NULL),(33,'27','3',1,NULL,1424680361,NULL),(34,'27','2',1,NULL,1424680361,NULL),(35,'28','2',1,NULL,1424680641,NULL),(36,'20','1',1,NULL,1424681601,NULL),(37,'20','2',1,NULL,1424681601,NULL),(38,'17','1',1,NULL,1424681935,NULL),(39,'17','2',1,NULL,1424681935,NULL),(40,'7','2',1,NULL,1424682172,NULL),(41,'6','1',1,NULL,1424682285,NULL),(42,'30','2',1,NULL,1433238996,NULL),(43,'31','2',1,NULL,1461077795,NULL),(44,'32','2',1,NULL,1475049262,NULL),(45,'33','2',1,NULL,1475049401,NULL);
/*!40000 ALTER TABLE `member_ministries` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `members`
DROP TABLE IF EXISTS `members`;
CREATE TABLE `members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_joined` blob,
  `hbc_id` blob,
  `title` blob NOT NULL,
  `member_code` blob NOT NULL,
  `first_name` blob NOT NULL,
  `last_name` blob NOT NULL,
  `gender` blob NOT NULL,
  `dob` blob,
  `phone1` blob NOT NULL,
  `phone2` blob NOT NULL,
  `email` blob NOT NULL,
  `country` blob NOT NULL,
  `county` blob NOT NULL,
  `location` blob NOT NULL,
  `address` blob,
  `marital_status` blob NOT NULL,
  `member_status` blob NOT NULL,
  `status` blob NOT NULL,
  `passport` blob NOT NULL,
  `occupation` blob NOT NULL,
  `employer` blob NOT NULL,
  `how_joined` blob NOT NULL,
  `baptised` blob NOT NULL,
  `confirmed` blob NOT NULL,
  `description` blob,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

-- Dumping data for table `members`
LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES (5,0xc5ccffbf053bb1043269672140a6832e,0x90065fe9ea51973a4989393c1f3a44af,0x69b40c77e26ea173d2df5b8ab08cfe75,0x4e4d4c57432d3031,0xf99c342935391953c33b63c8e840bdba,0x323f0ceab4db232f29e7be56390ecfe0,0xc0e427adbbef8f701a2ed487e9ed94e6,0xca66dcafc8b3c317cd4cd25427c72fee,0x9833ba881c4ec01e0d747c21f7c0aeb5,0xa545acd59a5c75d85e429545b1b87e8a,0x7b362fdeb1597dee830789da0fa23585a545acd59a5c75d85e429545b1b87e8a,0x76e4dbe5a2b803976381eb015866edea,0xdb038a954c03609fb9877befe686ee74,0xd9abb3be52408c29e2c3f6502305e60f,0xae2dd1956940110b06ad4eb84f86de5b,0x1c4bab466ee5d99888d9d3cb2cc4c464,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x784138eb819c2b6c40eb62d2cd92b80e,0x4249fc17ce1a513d733029ce82378dee,0x3d32226690d9049de49c689ca46a9f6d,0xd5b48dec692930d9516dbc64455c9b8a,0xd5b48dec692930d9516dbc64455c9b8a,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343230373131393035,0x6ecf00f2d6a6c70d0b1e1c51c22734b2),(6,0x20bfbac382eb2123b1c5d427436fc1b4,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0x4e4d4c57432d3032,0xc385032f63e316545650348534d53345,0x2938adfeedb02502564f79e82c07fd27,0xf68f4736ee0732d51d036bf82f77824c,0x5daff46985835d6e0245e575a7f300da,0x9833ba881c4ec01e0d747c21f7c0aeb5,0xa545acd59a5c75d85e429545b1b87e8a,0xc48b06a5b952f9b194c9207835070122,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x84ff8dcb237fc5380b74395f46edd016,0x0a080b0d602116244cb8cf8ae34df1c9,0xb001bf3bfbdef6f7bae0a2c16982a2f4,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0x29d3d96054ee62b9a7d9482809856c9672ce467cb2dc6809394c89dc16afbbef5666cd5ec9dc91eef7448c62acc766c2,0xd40b8143089d75cb39e90662d6255aa8,0x3874d7ab0af130768799a0693a178fad,0x7fcf09e9dc6ca34febad78f0f6faf1b6,0xd5b48dec692930d9516dbc64455c9b8a,0xd5b48dec692930d9516dbc64455c9b8a,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343230373132343037,0xbd1cb93c681d7b208088f5c48af4a443),(7,0xc5ccffbf053bb1043269672140a6832e,0x90065fe9ea51973a4989393c1f3a44af,0x69b40c77e26ea173d2df5b8ab08cfe75,0x4e4d4c57432d3033,0xdffede470e3a268b0327621e4c85734a,0x422c24b9e84f7eccadff17fcd218b609,0xc0e427adbbef8f701a2ed487e9ed94e6,0x4272bb8ef08d52745a5ac2f8bb3be5a7,0x9833ba881c4ec01e0d747c21f7c0aeb5,0xa545acd59a5c75d85e429545b1b87e8a,0x177c0bc5e0723eca89856f8460521c0b,0xd1a5a4489b90aa717eb2567f278759c8,0x15f9b3c2feb78f040406fd9a552077f2,0xe32c5ac4d1d6daba04edbd89d68b3e3c,0x715bfe64538908df1e6696370d5c4e6d,0x3e486c53b828470be88ef1839c02b9e3,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa1ca3d7d8bc4d815349959aba96ef7f6,0xde9aeb62529e7a566aa3bdc65c777ed6,0x7fcf09e9dc6ca34febad78f0f6faf1b6,0xd5b48dec692930d9516dbc64455c9b8a,0xd5b48dec692930d9516dbc64455c9b8a,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343230373238333439,0xd363cb5eb82467b55f55ea31a258f0b0),(16,0x37c20a3e3cb285424a8fd726ba2ca3c0,0xcfa10a53ac284db808f6bedd952eb03d,0x11450daafe9c9d319b69367444d6e356,0x4e4d4c57432d3034,0x4c0275f58031e7f4343accb2da246046,0x79f237e520d39d30dd2a09220f9b62dc,0xf68f4736ee0732d51d036bf82f77824c,0xf7cb36fa1a4ca2d38f5e4627cfa83269,0x9833ba881c4ec01e0d747c21f7c0aeb5,0xa545acd59a5c75d85e429545b1b87e8a,0x7e50d9772c0b8cd9bc5b1d92971b7121,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xc06fc3781b6b651da1ba77da701d7f2d,0xae7d398fd22bef00e4c1d28e51b6959a,0x072c73096db88563e1bee916f811c348,0x654db6612825636ca0c87e62741265f1,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x4b5177a9e4ccf4b7e74b3f04648fde08,0x9125921c6141f7a55c1f6dfa72cf28cc,0xfd3f3a7e94a9075e272fd4b6e3ed6c900f5c29add856eda25c204fb7373e0b9a,0xd5b48dec692930d9516dbc64455c9b8a,0xd5b48dec692930d9516dbc64455c9b8a,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343230373939353634,0x0741600d7833ff780688d8f2f56d4ab7),(17,0x987d80fb3a03902df0eeaed7e4e03c9a,0x90065fe9ea51973a4989393c1f3a44af,0x11450daafe9c9d319b69367444d6e356,0x4e4d4c57432d3035,0xbd47e9434eb9f7cdc8364f71ab0ecd45,0xd2df44319e441439919e0b23b3043ae8,0xf68f4736ee0732d51d036bf82f77824c,0xe939f8a7cfae3ead289c7b0e7731762e,0x9833ba881c4ec01e0d747c21f7c0aeb5,0xa545acd59a5c75d85e429545b1b87e8a,0x891e9739704cc97c369129111b0a626a,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x15f9b3c2feb78f040406fd9a552077f2,0x972b35be1be80929c26e1f5fa8b13f68,0x03750817ab218896fb6ff2557d47a365,0xc0a4e43be125d405b68217e678faa5c1,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x784138eb819c2b6c40eb62d2cd92b80e,0xa545acd59a5c75d85e429545b1b87e8a,0x6fbd10d8c906cc9e508b1be528c2e18f,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343230383030303232,0x51c6c2565b3b8e494ce6202ca029a387),(18,0x29e76b68aa6f94ed299c1f6faadb32cb,0xcfa10a53ac284db808f6bedd952eb03d,0x9efe82a740c9e77885b3f3bfed9ce10e,0x4e4d4c57432d3036,0x9c4344a8191808d292fef7532b0a1338,0x45e4af9035223d4eeda6525204413ad9,0xc0e427adbbef8f701a2ed487e9ed94e6,0x19a26ff5be182c77afaf8973b75eaab4,0x9833ba881c4ec01e0d747c21f7c0aeb5,0xa545acd59a5c75d85e429545b1b87e8a,0xd7efa9fb656058d0ccf1648e0b9d01081e0619411b601867bc043ca67b3f2fbc,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xeff50b4bf919682fffc9e64884157918,0xd9abb3be52408c29e2c3f6502305e60f,0x18ae1195c56aea9a08e886dc1c4ddfb5,0xd0b8483951cd9a3f5a7eceeaaa618830,0x0176233f8d42dc081df27c0556fe4849,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa1ca3d7d8bc4d815349959aba96ef7f6,0xa545acd59a5c75d85e429545b1b87e8a,0x3d32226690d9049de49c689ca46a9f6d,0xd5b48dec692930d9516dbc64455c9b8a,0xd5b48dec692930d9516dbc64455c9b8a,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343230383030323837,0xd2fd50818368b60f5b6fa12413ababa5),(19,0x54669a2a16c1584f045775376879e07d,0xcfa10a53ac284db808f6bedd952eb03d,0x69b40c77e26ea173d2df5b8ab08cfe75,0x4e4d4c57432d3037,0x9e82e79033aaa80b11d9a4ceaf40ab4a,0xa3ff6570bd7c1174055951ab26a95376,0x90f0a9667f48a5afe740e085116ebce8,0xa40da57a80fa943aa90220544c41068a,0x9833ba881c4ec01e0d747c21f7c0aeb5,0xa545acd59a5c75d85e429545b1b87e8a,0x4abd42af270460fe73c1f78812d87627,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x3ec6c5aadbd950d2b29d1be6a52c4f88,0x972b35be1be80929c26e1f5fa8b13f68,0x1be77700b5dc5e4ecbe3e7886f9191cc,0x8350a365576c6ea8fe9547d83d1b65b7,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xa6959c87cfbc42a61becf2dbd2ec788c,0xa545acd59a5c75d85e429545b1b87e8a,0x3d32226690d9049de49c689ca46a9f6d,0xd5b48dec692930d9516dbc64455c9b8a,0xd5b48dec692930d9516dbc64455c9b8a,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343230383038313633,0x425991e14bf345d59a09c2844814fd7a),(20,0x54669a2a16c1584f045775376879e07d,0x90065fe9ea51973a4989393c1f3a44af,0x9efe82a740c9e77885b3f3bfed9ce10e,0x4e4d4c57432d3038,0xb5dbe8372ff6370ba303e363bfb5a6c4,0xffbd7523b4e7c87d962ff94bbccb83ba,0xc0e427adbbef8f701a2ed487e9ed94e6,0x8f91af4b79844b3f762bf4835e9f4195,0x9833ba881c4ec01e0d747c21f7c0aeb5,0xa545acd59a5c75d85e429545b1b87e8a,0x14c107be802d833ad753cb7c28844573,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x278262e727070b8d39b8940ed7f2913a,0xae7d398fd22bef00e4c1d28e51b6959a,0x4790bc6b458eaec5d25862943e05bef9,0xd0b8483951cd9a3f5a7eceeaaa618830,0x7f822463ef171414dac93c36597e09c8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xd40b8143089d75cb39e90662d6255aa8,0xb6fae1ede5b6ee7ee832e832dfc4ca9b,0x6fbd10d8c906cc9e508b1be528c2e18f,0xd5b48dec692930d9516dbc64455c9b8a,0xd5b48dec692930d9516dbc64455c9b8a,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343230383038323436,0x83fa0626b5e9549f8a7fcf7e0c258f81),(21,0xc5ccffbf053bb1043269672140a6832e,0xcfa10a53ac284db808f6bedd952eb03d,0x11450daafe9c9d319b69367444d6e356,0x4e4d4c57432d3039,0x626278e914e27d6c3608af921882ddab,0xaeebf2d0c9f72d070f1f09c175080f3c,0xf68f4736ee0732d51d036bf82f77824c,0x6c964e15c3be19b4b8d657d0ac4f7c53,0x9833ba881c4ec01e0d747c21f7c0aeb5,0xa545acd59a5c75d85e429545b1b87e8a,0x89fe2003a17495f2eabd5e9b80845c58,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xeff50b4bf919682fffc9e64884157918,0x0a080b0d602116244cb8cf8ae34df1c9,0xe81014d513291ecd6b56a5a21189d413,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0xd9e8cb1b7c3745c6fe8ec062e5d70b15,0xd0c6e2fee7789737f115a667eca40d00,0x7fcf09e9dc6ca34febad78f0f6faf1b6,0xd5b48dec692930d9516dbc64455c9b8a,0xd5b48dec692930d9516dbc64455c9b8a,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343230383134313932,0xe6e3c63acf8180e601e3130fff6ba34f),(22,0x341b889cb0d1b79192c7923cb086673b,0xcfa10a53ac284db808f6bedd952eb03d,0x11450daafe9c9d319b69367444d6e356,0x4e4d4c57432d303130,0x236d8a9fba39b5d440d28c6db857e449,0x8706ca291ee078aa55046982b53d4276,0xf68f4736ee0732d51d036bf82f77824c,0x66184d75dad6c3ae3a9463f80c875176,0x9833ba881c4ec01e0d747c21f7c0aeb5,0xa545acd59a5c75d85e429545b1b87e8a,0xfb8e045df977a2749f2ce0ee82dcae3c7033b3feeaf31bf7b01fae798ff6dc9d,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xc06fc3781b6b651da1ba77da701d7f2d,0x972b35be1be80929c26e1f5fa8b13f68,0x4790bc6b458eaec5d25862943e05bef9,0xd0b8483951cd9a3f5a7eceeaaa618830,0x0176233f8d42dc081df27c0556fe4849,'',0xa545acd59a5c75d85e429545b1b87e8a,0x7608757f3492a817a8ab98b0edf103e8,0x014681add2d0efaba0cffa705e129c42,0xfd3f3a7e94a9075e272fd4b6e3ed6c900f5c29add856eda25c204fb7373e0b9a,0xd5b48dec692930d9516dbc64455c9b8a,0xd5b48dec692930d9516dbc64455c9b8a,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343230383139313735,0x5ec7d39f78e5c324a8e73848cdd1fd8a),(23,0x7f39c945b03a93ece0a900daf62e3fc2,0xcfa10a53ac284db808f6bedd952eb03d,0x69b40c77e26ea173d2df5b8ab08cfe75,0x4e4d4c57432d303131,0xb8a3991301e0793d8616c842128e8da6,0x04ca69f4971b8b7cecfd70111d6309a8,0xc0e427adbbef8f701a2ed487e9ed94e6,0x4d75b2445de5af5a469c53b170d8ae30,0x9833ba881c4ec01e0d747c21f7c0aeb5,0xa545acd59a5c75d85e429545b1b87e8a,0x98671d6d03df0bf13858ff32dbe9556a1b56b341c6bd7ab25e25918917d62697,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x84ff8dcb237fc5380b74395f46edd016,0x0a080b0d602116244cb8cf8ae34df1c9,0x55769102441eb5f95bdd8a0a34bfe050,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xa545acd59a5c75d85e429545b1b87e8a,0x784138eb819c2b6c40eb62d2cd92b80e,0x862a8793e807a2adca1a5e110cc580c4,0x3d32226690d9049de49c689ca46a9f6d,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343230383931393432,0xc817fdad31b6df26a5783fb03d83802c),(24,0xc5ccffbf053bb1043269672140a6832e,0xcfa10a53ac284db808f6bedd952eb03d,0x69b40c77e26ea173d2df5b8ab08cfe75,0x4e4d4c57432d303132,0xafb9a75c10f29d424565e6f0e1768801,0x8b2d09e8246808eb27ce5deaff092295,0xc0e427adbbef8f701a2ed487e9ed94e6,0x5ee95ae51f8df953af6fb0d23197d823,0x9833ba881c4ec01e0d747c21f7c0aeb5,0xa545acd59a5c75d85e429545b1b87e8a,0xf28caed49e3fd761e1fd440e6298173e,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x17251e5270f2b6ed6042240ad12a917c,0xd9abb3be52408c29e2c3f6502305e60f,0x4790bc6b458eaec5d25862943e05bef9,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0x0dda885ddb311e98f31081686773c22c,0xde5a0b396228d6b2d7e3723945d9cdad,0xdfed609c8e0a3b8921a8c038937cd950,0x3d32226690d9049de49c689ca46a9f6d,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343230383932343838,0x28cd037f8ff81ae430cd9f6091376773),(25,0x85a70faaf08eb29f72d33a7c55585c80,0xcfa10a53ac284db808f6bedd952eb03d,0x11450daafe9c9d319b69367444d6e356,0x4e4d4c57432d303133,0xeb3e171d00a46dcec09e4d98345b4d2a,0xcc2a3cc24f04553ae669e4c49daff8ae,0xf68f4736ee0732d51d036bf82f77824c,0x45d4f566c01990e4a7dac816df3a4ad7,0x9833ba881c4ec01e0d747c21f7c0aeb5,0xa545acd59a5c75d85e429545b1b87e8a,0x1a85642695797c8772fb17a7e6b9d4d4,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xa2cbe5dfb60db4199ddd737a3a0337ce,0x972b35be1be80929c26e1f5fa8b13f68,0x4790bc6b458eaec5d25862943e05bef9,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0x9ca3b07de3c39546c6fc944274d45e2a,0xa1ca3d7d8bc4d815349959aba96ef7f6,0xa545acd59a5c75d85e429545b1b87e8a,0x3d32226690d9049de49c689ca46a9f6d,0xd5b48dec692930d9516dbc64455c9b8a,0xe3fd5c1151fd6ed0cfac3c58d96c54c6,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343232383931343233,0x4c39e0de962b0fdcec635eda49252ebf),(26,0xd0b5426cd8a78128adf866909e0d49e1,0x90065fe9ea51973a4989393c1f3a44af,0x11450daafe9c9d319b69367444d6e356,'',0x5c74887e8e522ca52b4e7d15330475db,0x960f84d87596207752a55e92e2cae139,0xc0e427adbbef8f701a2ed487e9ed94e6,0xcfbdd10cfe59f12d46ef29c5518c5c9a,0x9833ba881c4ec01e0d747c21f7c0aeb5,0xa545acd59a5c75d85e429545b1b87e8a,0xf2601194a885286eb81e143c75af4d90,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xc06fc3781b6b651da1ba77da701d7f2d,0x0a080b0d602116244cb8cf8ae34df1c9,0x09abefa84be7048c9f0da29b40df9220,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0x692a27b352e4a98f5b2a053c00a23a53,0x4b5177a9e4ccf4b7e74b3f04648fde08,0xacc199f5deb59056b7000998b39dd188,0x3d32226690d9049de49c689ca46a9f6d,0xd5b48dec692930d9516dbc64455c9b8a,0xd5b48dec692930d9516dbc64455c9b8a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xb1f4e6f24da0c5d21181c7e252397a35,NULL),(27,0x7b0d3fdbdb3bc63de5355b325814ad94,0x90065fe9ea51973a4989393c1f3a44af,0x11450daafe9c9d319b69367444d6e356,0x33bf5c6e5c1d13b57f59854a14dffd74,0x824055568aedbace2163f0014ffd4bc7,0xa147fdf1542796afa609819f8b15ae53,0xf68f4736ee0732d51d036bf82f77824c,0xa9f9152805ca23a8d569a4e20296e781,0x9833ba881c4ec01e0d747c21f7c0aeb5,0xa545acd59a5c75d85e429545b1b87e8a,0x5f300c0ba4821c651d13afc7d77cf739,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xc9a0f348b1a476d0bbd37d9b88fda7f8,0xae7d398fd22bef00e4c1d28e51b6959a,0x4790bc6b458eaec5d25862943e05bef9,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0x7c0cc2eb7aaa3974b40e94ed769f45a0,0xd9e8cb1b7c3745c6fe8ec062e5d70b15,0xa2009451d4b3c3ade8b9ae577653352f,0x3d32226690d9049de49c689ca46a9f6d,0xd5b48dec692930d9516dbc64455c9b8a,0xd5b48dec692930d9516dbc64455c9b8a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x626f89d0c1647a811741e97d9c40a0ec,0x881eb7d5a480b583a0d7cdbc27f28562),(28,0xd642d5137f6bc17fb66114a0d29a9c00,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0x839ff09c2f5dc9c3a514b0859a283379,0xf99c342935391953c33b63c8e840bdba,0x45e204da5cf3c46bc1cc2e7118e1acd9,0xf68f4736ee0732d51d036bf82f77824c,0xa9f9152805ca23a8d569a4e20296e781,0x9833ba881c4ec01e0d747c21f7c0aeb5,0xa545acd59a5c75d85e429545b1b87e8a,0x27a6d3f6a66a5300b2c4047cdde663bb,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xc9a0f348b1a476d0bbd37d9b88fda7f8,0xae7d398fd22bef00e4c1d28e51b6959a,0x4790bc6b458eaec5d25862943e05bef9,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0x7d11b13614153395a3bb7e9b41ae8e4d,0xd9e8cb1b7c3745c6fe8ec062e5d70b15,0xa2009451d4b3c3ade8b9ae577653352f,0x3d32226690d9049de49c689ca46a9f6d,0xd5b48dec692930d9516dbc64455c9b8a,0xd5b48dec692930d9516dbc64455c9b8a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xdf9db0492b849c7b1e8e90cd87f1921a,0xfd27917b93dc95ba4254a62e0d48e69f),(29,0xc34dca4d51ead2c80af17de0dc6a9683,0xcdf3a1cb3f3ee08d0e0c63e679397c3a,0x11450daafe9c9d319b69367444d6e356,0x64e704cb5212c4c163274a2b00c224fa,0x227cd3fcb2298f2c78696d8145c26ad7,0xbf67b138e81d42579eee4a7e9e52f136,0xf68f4736ee0732d51d036bf82f77824c,0x1ce047b67ca029c77b8392b8e98f5dc1,0x9833ba881c4ec01e0d747c21f7c0aeb5,0xa545acd59a5c75d85e429545b1b87e8a,0x4f72cdf52ecea96cb974417c4d61f821,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x278262e727070b8d39b8940ed7f2913a,0x4249fc17ce1a513d733029ce82378dee,0x4790bc6b458eaec5d25862943e05bef9,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0x12f784f1b183b7ceebe2efd326269729,0xa1ca3d7d8bc4d815349959aba96ef7f6,0xebbf908c7221546a454af572d926fe61,0x3d32226690d9049de49c689ca46a9f6d,0xd5b48dec692930d9516dbc64455c9b8a,0xd5b48dec692930d9516dbc64455c9b8a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x48c722fc5eae1e0a0a259409eac24fd1,0x25eacee77a8746ded6ffe4f208c22d33),(30,0xf8f12444f298c0fe854d9ffb58f6a7ad,0xcdf3a1cb3f3ee08d0e0c63e679397c3a,0x11450daafe9c9d319b69367444d6e356,0xaad07224d83c5a757d7ab29ae973576c,0xb11cede91dbfc6a99357f347e7c469c0,0xc26c75ed25e0e3e3f9288f5b4911da82,0xf68f4736ee0732d51d036bf82f77824c,0x1109a473fd654a960ad5fc15398c5689,0xf35ce5037f0c16c7a2d028d11dac196c,0xa545acd59a5c75d85e429545b1b87e8a,0x0d50fed3a42a17caed653e88a80dede0,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x17251e5270f2b6ed6042240ad12a917c,0x0a080b0d602116244cb8cf8ae34df1c9,0xfc40751c4483960f671b395a5cfe2740,0xd0b8483951cd9a3f5a7eceeaaa618830,0x5e523e54615ea8769b98c641a51446e8,'',0xc0df3aaad363bf71d7dd93d02ca2c327,0xd9e8cb1b7c3745c6fe8ec062e5d70b15,0xa8382e0cd9f0955e3992885b676825bc,0x3d32226690d9049de49c689ca46a9f6d,0xd5b48dec692930d9516dbc64455c9b8a,0xd5b48dec692930d9516dbc64455c9b8a,0xa545acd59a5c75d85e429545b1b87e8a,0xcdf3a1cb3f3ee08d0e0c63e679397c3a,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xbc522691e6c9fbe9c83126e88d8821dc,0xf7e508a32549c1043dc034c9deaedd0e),(31,0x0910ccf2bcff6562f681b763730ad4a2,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x11450daafe9c9d319b69367444d6e356,0xfd015bc0c138ec45a96779848bdd5f7b,0x22886686b0a940c46deda51721fe6f0f,0xd7e6e8e23b53ab241bc971028dd5486e,0xf68f4736ee0732d51d036bf82f77824c,0xc0b646440d79f556afc5a9a985c0ff34,0x9833ba881c4ec01e0d747c21f7c0aeb5,0xa545acd59a5c75d85e429545b1b87e8a,0x7e48ad559d0294a78dcf763a3bc8978fa545acd59a5c75d85e429545b1b87e8a,0x6b15e4ce6e6db76e7b666628b28bbb9e,0x278262e727070b8d39b8940ed7f2913a,0x2fbec5fe104d38f16b16194d741c53f8,0x1320633a488e9c91edc6ecb2fcd1a562,0xd0b8483951cd9a3f5a7eceeaaa618830,0x7f822463ef171414dac93c36597e09c8,'',0x6ba09d64fcee55d20903cc17509aaf41,0x4b5177a9e4ccf4b7e74b3f04648fde08,0x3874d7ab0af130768799a0693a178fad,0xfd3f3a7e94a9075e272fd4b6e3ed6c900f5c29add856eda25c204fb7373e0b9a,0xd5b48dec692930d9516dbc64455c9b8a,0xd5b48dec692930d9516dbc64455c9b8a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x349985791607acc62340c1664e298e67,0x4a0f7fa460f340a70aed865d7fa11665),(32,0x0ca2df5aba8bde92ff1f7a63d8e6b517,0xcdf3a1cb3f3ee08d0e0c63e679397c3a,0x11450daafe9c9d319b69367444d6e356,0x2d8c81fdac318cd731ef83c2a922e37d,0xb11075e544d1534499ee5fe7289b3581,0x868ec973b245249dccfb911a133409cd,0xf68f4736ee0732d51d036bf82f77824c,0x944445b8d4ce0dbef6d463034e732e5a,0x38c7175bf1da11973e50375c81150e54,0x7702fd27cf75e0f74365eeca1ec087a5,0xc1a8a2ee0ee9d3f1d4e549c5c9d27598,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xdb038a954c03609fb9877befe686ee74,0x52bda674b451ffe1d2970395fc7cc4e5,0xcf088c67b3c0edea27a84c1ae9bfb241,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0x77574ead042fa5f327bc8c73f8867d77,0xd9e8cb1b7c3745c6fe8ec062e5d70b15,0x96d78a0932ed04100e448bb9e9163e46,0xfd3f3a7e94a9075e272fd4b6e3ed6c900f5c29add856eda25c204fb7373e0b9a,0xd5b48dec692930d9516dbc64455c9b8a,0xd5b48dec692930d9516dbc64455c9b8a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x1d5a3f8bba9d4b97a4a0815355d569d8,NULL),(33,0x0ca2df5aba8bde92ff1f7a63d8e6b517,0xcdf3a1cb3f3ee08d0e0c63e679397c3a,0x11450daafe9c9d319b69367444d6e356,0xb5ad70e9b884f49788de45387a9f8989,0xb11075e544d1534499ee5fe7289b3581,0x868ec973b245249dccfb911a133409cd,0xf68f4736ee0732d51d036bf82f77824c,0x944445b8d4ce0dbef6d463034e732e5a,0x38c7175bf1da11973e50375c81150e54,0xa545acd59a5c75d85e429545b1b87e8a,0xc1a8a2ee0ee9d3f1d4e549c5c9d27598,0x6b15e4ce6e6db76e7b666628b28bbb9e,0xdb038a954c03609fb9877befe686ee74,0x52bda674b451ffe1d2970395fc7cc4e5,0xcf088c67b3c0edea27a84c1ae9bfb241,0xffcea4e2b02df605beabccfec47fc18a,0x5e523e54615ea8769b98c641a51446e8,'',0xdc3638dd6a4399082194aa479e2e958d,0xd9e8cb1b7c3745c6fe8ec062e5d70b15,0x96d78a0932ed04100e448bb9e9163e46,0xfd3f3a7e94a9075e272fd4b6e3ed6c900f5c29add856eda25c204fb7373e0b9a,0xd5b48dec692930d9516dbc64455c9b8a,0xd5b48dec692930d9516dbc64455c9b8a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x380e3086bcb764c77cfa596561675eda,NULL);
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `members_ministry_support`
DROP TABLE IF EXISTS `members_ministry_support`;
CREATE TABLE `members_ministry_support` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `tithe_id` int(11) DEFAULT NULL,
  `type` varchar(256) NOT NULL DEFAULT '',
  `amount` float DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

-- Dumping data for table `members_ministry_support`
LOCK TABLES `members_ministry_support` WRITE;
/*!40000 ALTER TABLE `members_ministry_support` DISABLE KEYS */;
INSERT INTO `members_ministry_support` VALUES (1,5,1,'Cash',5000,1,0,1,1421660004,1421660013),(2,24,1,'Cash',6300,1,1,NULL,1421660004,NULL),(3,22,1,'Cash',7800,1,1,NULL,1421660004,NULL),(4,7,2,'Cash',5000,1,0,1,1422953287,1422953930),(5,25,2,'Cash',6500,1,1,NULL,1422953287,NULL),(6,22,3,'Cash',1500,1,1,NULL,1422959313,NULL),(7,25,3,'Cash',2000,1,1,NULL,1422959313,NULL),(8,7,4,'Cash',5000,1,1,NULL,1423122543,NULL),(9,18,4,'Cash',5000,1,1,NULL,1423122543,NULL),(10,16,4,'Cash',1500,1,1,NULL,1423122543,NULL),(11,19,4,'Cash',1000,1,1,NULL,1423122543,NULL),(12,24,4,'Cash',2000,1,1,NULL,1423122543,NULL),(13,25,4,'Cash',5000,1,1,NULL,1423122543,NULL),(14,27,5,'Cheque',458,1,1,NULL,1426595655,NULL),(15,29,5,'M-Pesa',5000,1,1,NULL,1426595655,NULL),(16,29,6,'Cash',4700,1,1,NULL,1432009847,NULL),(17,6,6,'Cash',2500,1,1,NULL,1432009847,NULL),(18,5,7,'Cash',45000,1,1,NULL,1432010006,NULL),(19,29,7,'Cash',25000,1,1,NULL,1432010006,NULL),(20,29,8,'Cash',18000,1,1,NULL,1432010048,NULL),(21,18,8,'Cash',15800,1,1,NULL,1432010048,NULL),(22,20,8,'Cash',12500,1,1,NULL,1432010048,NULL),(23,29,9,'Cash',48000,1,1,NULL,1432010092,NULL),(24,18,9,'Cash',12000,1,1,NULL,1432010092,NULL),(25,5,10,'Cash',98000,1,1,NULL,1433679291,NULL),(26,29,11,'Cash',58000,1,1,NULL,1438065233,NULL),(27,29,12,'M-Pesa',12000,1,1,NULL,1447151754,NULL),(28,5,13,'Cash',40000,1,1,NULL,1461075364,NULL),(29,19,13,'Bank Slip',11000,1,1,NULL,1461075364,NULL),(30,18,14,'M-Pesa',39000,1,1,NULL,1461077068,NULL);
/*!40000 ALTER TABLE `members_ministry_support` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `members_other_contributions`
DROP TABLE IF EXISTS `members_other_contributions`;
CREATE TABLE `members_other_contributions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `tithe_id` int(11) DEFAULT NULL,
  `type` varchar(256) NOT NULL DEFAULT '',
  `amount` float DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

-- Dumping data for table `members_other_contributions`
LOCK TABLES `members_other_contributions` WRITE;
/*!40000 ALTER TABLE `members_other_contributions` DISABLE KEYS */;
INSERT INTO `members_other_contributions` VALUES (1,6,1,'Cash',5000,1,1,NULL,1421676547,NULL),(2,22,1,'Cash',8000,1,1,NULL,1421676547,NULL),(3,22,1,'Cash',2000,1,1,NULL,1421676547,NULL),(4,22,1,'Cash',3500,1,1,NULL,1421676548,NULL),(5,23,1,'Cash',7500,1,0,1,1421676548,1421676746),(6,7,2,'Cash',5000,1,1,NULL,1421681876,NULL),(7,23,2,'Cash',2000,1,1,NULL,1421681876,NULL),(8,22,2,'Cash',5500,1,1,NULL,1421681876,NULL),(9,22,3,'Cash',1500,1,1,NULL,1421681994,NULL),(10,22,3,'Cash',2000,1,1,NULL,1421681994,NULL),(11,22,4,'Cash',2000,1,1,NULL,1422958157,NULL),(12,24,4,'Cash',5000,1,1,NULL,1422958158,NULL),(13,7,4,'Cash',1500,1,1,NULL,1422958158,NULL),(14,16,5,'Cash',5000,1,1,NULL,1422959841,NULL),(15,25,5,'Cash',1000,1,1,NULL,1422959841,NULL),(16,21,5,'Cash',2000,1,1,NULL,1422959841,NULL),(17,22,5,'Cash',1500,1,1,NULL,1422959841,NULL),(18,18,6,'Cash',5000,1,1,NULL,1423122805,NULL),(19,20,6,'Cash',1500,1,1,NULL,1423122805,NULL),(20,5,6,'Cash',5000,1,1,NULL,1423122805,NULL),(21,17,6,'Cash',6500,1,1,NULL,1423122805,NULL),(22,16,7,'Cash',5000,1,1,NULL,1423248379,NULL),(23,23,7,'Cheque',2000,1,1,NULL,1423248379,NULL),(24,25,7,'Bank Slip',6500,1,1,NULL,1423248379,NULL),(25,22,7,'M-Pesa',1000,1,1,NULL,1423248379,NULL),(26,27,8,'M-Pesa',1500,1,1,NULL,1426595705,NULL),(27,29,9,'Cash',55000,1,1,NULL,1432010208,NULL),(28,18,9,'Cash',10500,1,1,NULL,1432010209,NULL),(29,17,9,'Cash',12500,1,1,NULL,1432010209,NULL),(30,29,10,'Cash',15000,1,1,NULL,1432010259,NULL),(31,19,10,'Cheque',12000,1,1,NULL,1432010259,NULL),(32,19,10,'Cash',14500,1,1,NULL,1432010259,NULL),(33,29,11,'Cash',12500,1,1,NULL,1432010321,NULL),(34,18,11,'Cash',45000,1,1,NULL,1432010321,NULL),(35,19,11,'Cash',4500,1,1,NULL,1432010321,NULL),(36,29,12,'Cash',78000,1,1,NULL,1438065552,NULL),(37,5,13,'Cash',5000,1,1,NULL,1461075448,NULL),(38,6,13,'M-Pesa',11000,1,1,NULL,1461075449,NULL),(39,18,13,'Bank Slip',5000,1,1,NULL,1461075449,NULL),(40,6,14,'Cash',55000,1,1,NULL,1461077140,NULL),(41,6,15,'M-Pesa',1000,1,1,NULL,1468847516,NULL);
/*!40000 ALTER TABLE `members_other_contributions` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `members_seed_planting`
DROP TABLE IF EXISTS `members_seed_planting`;
CREATE TABLE `members_seed_planting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `tithe_id` int(11) DEFAULT NULL,
  `type` varchar(256) NOT NULL DEFAULT '',
  `amount` float DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

-- Dumping data for table `members_seed_planting`
LOCK TABLES `members_seed_planting` WRITE;
/*!40000 ALTER TABLE `members_seed_planting` DISABLE KEYS */;
INSERT INTO `members_seed_planting` VALUES (1,22,1,'',5000,1,1,NULL,1421662154,NULL),(2,22,1,'',4550,1,1,NULL,1421662154,NULL),(3,22,1,'',3500,1,0,1,1421662154,1421662164),(4,22,2,'',45000,1,1,NULL,1421841563,NULL),(5,23,2,'',5000,1,1,NULL,1421841563,NULL),(6,21,2,'',5200,1,1,NULL,1421841563,NULL),(7,20,2,'',2000,1,1,NULL,1421841563,NULL),(8,16,2,'',5500,1,1,NULL,1421841563,NULL),(9,22,3,'',5000,1,1,NULL,1421841614,NULL),(10,23,3,'',5000,1,1,NULL,1421841614,NULL),(11,20,3,'',45000,1,1,NULL,1421841614,NULL),(12,19,3,'',5200,1,1,NULL,1421841614,NULL),(13,6,3,'',1500,1,1,NULL,1421841614,NULL),(14,22,4,'',5000,1,1,NULL,1422955978,NULL),(15,25,4,'',1500,1,1,NULL,1422955978,NULL),(16,23,4,'',5000,1,1,NULL,1422955978,NULL),(17,17,4,'',1500,1,1,NULL,1422955978,NULL),(18,6,4,'',2000,1,1,NULL,1422955979,NULL),(19,24,4,'',1500,1,1,NULL,1422955979,NULL),(20,7,5,'',1500,1,1,NULL,1422959687,NULL),(21,21,5,'',1500,1,1,NULL,1422959687,NULL),(22,20,5,'',6500,1,1,NULL,1422959687,NULL),(23,22,6,'',5000,1,1,NULL,1423122215,NULL),(24,6,6,'',1500,1,1,NULL,1423122215,NULL),(25,24,6,'',6500,1,1,NULL,1423122215,NULL),(26,5,7,'Cash',5000,1,1,NULL,1423246759,NULL),(27,22,7,'Cheque',2000,1,1,NULL,1423246759,NULL),(28,24,7,'M-Pesa',1500,1,1,NULL,1423246759,NULL),(29,18,7,'Bank Slip',6500,1,1,NULL,1423246759,NULL),(30,27,8,'Cheque',5200,1,1,NULL,1426595676,NULL),(31,29,9,'Cash',65000,1,1,NULL,1432010164,NULL),(32,18,9,'Cash',22000,1,1,NULL,1432010164,NULL),(33,19,9,'Cash',14000,1,1,NULL,1432010165,NULL),(34,29,10,'Cash',45000,1,1,NULL,1432010626,NULL),(35,18,10,'Cash',12000,1,1,NULL,1432010626,NULL),(36,20,10,'Cash',15000,1,1,NULL,1432010627,NULL),(37,29,11,'Cash',12500,1,1,NULL,1432010671,NULL),(38,7,11,'Cash',14200,1,1,NULL,1432010671,NULL),(39,17,11,'Cash',25000,1,1,NULL,1432010671,NULL),(40,17,12,'Cash',68000,1,1,NULL,1433679329,NULL),(41,6,13,'Bank Slip',11000,1,1,NULL,1461075401,NULL),(42,28,13,'Bank Slip',25000,1,1,NULL,1461075402,NULL),(43,7,14,'Cash',48000,1,1,NULL,1461077109,NULL),(44,18,15,'Cash',38000,1,1,NULL,1461077303,NULL);
/*!40000 ALTER TABLE `members_seed_planting` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `members_thanks_giving`
DROP TABLE IF EXISTS `members_thanks_giving`;
CREATE TABLE `members_thanks_giving` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `tithe_id` varchar(256) NOT NULL DEFAULT '',
  `type` varchar(256) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table `members_thanks_giving`
LOCK TABLES `members_thanks_giving` WRITE;
/*!40000 ALTER TABLE `members_thanks_giving` DISABLE KEYS */;
INSERT INTO `members_thanks_giving` VALUES (1,5,'1','',5000,1,1,NULL,1421658508,NULL),(2,24,'1','',8000,1,0,1,1421658508,1421658522),(3,22,'1','',6000,1,1,NULL,1421658508,NULL),(4,22,'1','',4500,1,1,NULL,1421658508,NULL),(5,22,'2','',5000,1,1,NULL,1421841342,NULL),(6,23,'2','',2000,1,1,NULL,1421841342,NULL),(7,22,'2','',1500,1,1,NULL,1421841342,NULL),(8,24,'2','',2000,1,1,NULL,1421841342,NULL),(9,22,'3','',2000,1,1,NULL,1421845925,NULL),(10,23,'3','',5000,1,1,NULL,1421845925,NULL),(11,7,'4','',6500,1,1,NULL,1422942394,NULL),(12,7,'5','',6500,1,1,NULL,1422942423,NULL),(13,6,'6','',5000,1,1,NULL,1422942886,NULL),(14,24,'6','',6500,1,1,NULL,1422942886,NULL),(15,25,'6','',6800,1,1,NULL,1422942886,NULL),(16,22,'7','',2000,1,1,NULL,1422959214,NULL),(17,25,'7','',6500,1,1,NULL,1422959215,NULL),(18,17,'8','',5000,1,1,NULL,1423121640,NULL),(19,25,'8','',6500,1,1,NULL,1423121640,NULL),(20,24,'8','',2000,1,1,NULL,1423121640,NULL),(21,20,'9','Cash',5000,1,1,NULL,1423245721,NULL),(22,25,'9','Cheque',2000,1,1,NULL,1423245721,NULL),(23,23,'9','Bank Slip',1500,1,1,NULL,1423245721,NULL),(24,18,'9','M-Pesa',6500,1,1,NULL,1423245721,NULL),(25,16,'10','Cash',5000,1,1,NULL,1423246359,NULL),(26,19,'10','Cheque',2000,1,1,NULL,1423246359,NULL),(27,25,'10','Bank Slip',1500,1,1,NULL,1423246359,NULL),(28,18,'10','M-Pesa',1000,1,1,NULL,1423246359,NULL),(29,27,'11','M-Pesa',8500,1,0,1,1426595422,1426595567),(30,27,'12','M-Pesa',8500,1,1,NULL,1426595539,NULL),(31,26,'12','Cash',480,1,1,NULL,1426595539,NULL),(32,29,'13','Cash',45000,1,1,NULL,1432009806,NULL),(33,6,'13','Cash',2500,1,1,NULL,1432009806,NULL),(34,16,'14','Cash',5800,1,1,NULL,1432009912,NULL),(35,29,'14','Cash',56000,1,1,NULL,1432009912,NULL),(36,29,'15','Cash',22000,1,1,NULL,1432009965,NULL),(37,19,'15','Cash',12000,1,1,NULL,1432009965,NULL),(38,17,'15','Cash',5000,1,1,NULL,1432009965,NULL),(39,6,'15','Cash',25000,1,1,NULL,1432009965,NULL),(40,6,'16','Cash',45800,1,1,NULL,1433679148,NULL),(41,19,'16','Cash',67000,1,1,NULL,1433679148,NULL),(42,6,'17','Cash',78000,1,1,NULL,1433679258,NULL),(43,29,'18','M-Pesa',55000,1,1,NULL,1438065608,NULL),(44,29,'19','Cash',5200,1,1,NULL,1447151726,NULL),(45,7,'20','Cheque',50000,1,1,NULL,1461075322,NULL),(46,6,'20','M-Pesa',8000,1,1,NULL,1461075323,NULL),(47,17,'21','Bank Slip',45000,1,1,NULL,1461077041,NULL),(48,16,'22','Cash',44000,1,1,NULL,1461077387,NULL);
/*!40000 ALTER TABLE `members_thanks_giving` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `members_tithe`
DROP TABLE IF EXISTS `members_tithe`;
CREATE TABLE `members_tithe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` varchar(256) NOT NULL DEFAULT '',
  `tithe_id` varchar(256) NOT NULL DEFAULT '',
  `type` varchar(256) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8;

-- Dumping data for table `members_tithe`
LOCK TABLES `members_tithe` WRITE;
/*!40000 ALTER TABLE `members_tithe` DISABLE KEYS */;
INSERT INTO `members_tithe` VALUES (1,'5','1','Cash',10000,1,1,NULL,1421314871,NULL),(2,'6','1','Cash',5000,1,0,1,1421314871,1421325062),(3,'17','1','Cash',8000,1,0,1,1421314871,1421324715),(4,'22','1','Cash',1500,1,0,1,1421314871,1421325074),(5,'5','2','Cash',10000,1,1,NULL,1421315395,NULL),(6,'16','2','Cash',8000,1,1,1,1421315395,1421322917),(7,'19','2','Cash',1500,1,0,1,1421315395,1421324703),(8,'20','3','Cash',10000,1,1,NULL,1421324982,NULL),(9,'22','3','Cash',8000,1,1,NULL,1421324982,NULL),(10,'19','3','Cash',5200,1,1,NULL,1421324982,NULL),(11,'24','3','Cash',5680,1,1,NULL,1421324982,NULL),(12,'6','3','Cash',2500,1,1,NULL,1421324982,NULL),(13,'5','3','Cash',12500,1,1,NULL,1421324982,NULL),(14,'22','4','Cash',5200,1,1,NULL,1421839710,NULL),(15,'21','4','Cash',4500,1,1,NULL,1421839710,NULL),(16,'20','4','Cash',7800,1,1,NULL,1421839710,NULL),(17,'7','4','Cash',4587,1,1,NULL,1421839710,NULL),(18,'22','4','Cash',9000,1,1,NULL,1421839710,NULL),(19,'22','4','Cash',7500,1,1,NULL,1421839710,NULL),(20,'22','5','Cash',2000,1,0,1,1421845647,1422941615),(21,'23','5','Cash',5500,1,1,NULL,1421845647,NULL),(22,'5','6','Cash',5000,1,1,NULL,1422894808,NULL),(23,'5','7','Cash',5000,1,1,NULL,1422894849,NULL),(24,'5','8','Cash',5000,1,1,NULL,1422894935,NULL),(25,'7','9','Cash',5000,1,1,NULL,1422895205,NULL),(26,'24','9','Cash',15000,1,1,NULL,1422895206,NULL),(27,'22','10','Cash',5000,1,1,NULL,1422959021,NULL),(28,'22','11','Bank slip',5000,1,1,NULL,1422959055,NULL),(29,'22','12','Cash',2000,1,1,NULL,1423119025,NULL),(30,'23','12','Cash',5000,1,1,NULL,1423119025,NULL),(31,'24','12','Cash',2000,1,1,NULL,1423119025,NULL),(32,'20','12','Cash',6500,1,1,NULL,1423119025,NULL),(33,'6','12','Cash',1000,1,1,NULL,1423119025,NULL),(34,'16','13','M-Pesa',2000,1,1,NULL,1423248122,NULL),(35,'19','13','Cash',1500,1,1,NULL,1423248122,NULL),(36,'25','13','Cash',6500,1,1,NULL,1423248122,NULL),(37,'16','14','Cash',2000,1,1,NULL,1423248243,NULL),(38,'24','14','Cash',5000,1,1,NULL,1423248243,NULL),(39,'23','14','Cash',2000,1,1,NULL,1423248243,NULL),(40,'22','14','Cash',6500,1,1,NULL,1423248243,NULL),(41,'20','14','Cash',5000,1,1,NULL,1423248243,NULL),(42,'5','15','Cash',5800,1,1,NULL,1424702383,NULL),(43,'16','15','Bank Slip',2500,1,1,NULL,1424702383,NULL),(44,'23','15','Cash',1800,1,1,NULL,1424702383,NULL),(45,'28','16','Cheque',22500,1,1,NULL,1424702723,NULL),(46,'27','17','Cash',5200,1,1,NULL,1426595362,NULL),(47,'26','17','Cheque',4582,1,1,NULL,1426595364,NULL),(48,'25','17','Bank Slip',8522,1,1,NULL,1426595365,NULL),(49,'25','17','Cash',8500,1,1,NULL,1426595366,NULL),(50,'27','18','M-Pesa',1000,1,1,NULL,1426595772,NULL),(51,'29','19','Cash',5200,1,1,NULL,1431670724,NULL),(52,'29','20','Cash',2500,1,1,NULL,1432009620,NULL),(53,'5','21','Cash',1250,1,1,NULL,1432009728,NULL),(54,'6','21','M-Pesa',4500,1,1,NULL,1432009728,NULL),(55,'7','21','Cheque',5000,1,1,NULL,1432009728,NULL),(56,'18','21','Cheque',18000,1,1,NULL,1432009728,NULL),(57,'17','21','Cash',4580,1,1,NULL,1432009729,NULL),(58,'19','21','Cash',8000,1,1,NULL,1432009729,NULL),(59,'22','21','Cash',45,1,1,NULL,1432009729,NULL),(60,'5','22','Cash',8500,1,1,NULL,1433678888,NULL),(61,'18','22','Cash',4500,1,1,NULL,1433678888,NULL),(62,'16','22','Cheque',25000,1,1,NULL,1433678888,NULL),(63,'20','22','Cash',45000,1,1,NULL,1433678889,NULL),(64,'17','22','M-Pesa',22000,1,1,NULL,1433678889,NULL),(65,'6','23','Cash',45800,1,1,NULL,1433678958,NULL),(66,'19','23','Cheque',78000,1,1,NULL,1433678958,NULL),(67,'19','23','Cash',15000,1,1,NULL,1433678958,NULL),(68,'7','24','Cash',45000,1,1,NULL,1433678996,NULL),(69,'20','24','Cheque',25000,1,1,NULL,1433678996,NULL),(70,'7','25','Cash',47000,1,1,NULL,1433679030,NULL),(71,'18','25','Cash',55000,1,1,NULL,1433679030,NULL),(72,'29','26','Cheque',8500,1,1,NULL,1433681933,NULL),(73,'17','26','Cash',45888,1,1,NULL,1433681934,NULL),(74,'29','27','Cash',78000,1,1,NULL,1436444817,NULL),(75,'16','28','Cash',5000,1,1,NULL,1437549377,NULL),(76,'6','29','Cash',15000,1,1,NULL,1437549412,NULL),(77,'29','30','M-Pesa',5000,1,1,NULL,1437549708,NULL),(78,'29','31','M-Pesa',5200,1,1,NULL,1437573721,NULL),(79,'29','32','Cash',4500,1,1,NULL,1437574056,NULL),(80,'29','33','Cash',4500,1,0,1,1437574144,1447151602),(81,'29','34','Cash',5200,1,1,NULL,1437574297,NULL),(82,'29','35','M-Pesa',5000,1,1,NULL,1437576199,NULL),(83,'29','36','M-Pesa',15000,1,1,NULL,1437577207,NULL),(84,'29','37','M-Pesa',1500,1,1,NULL,1437577346,NULL),(85,'29','31','M-Pesa',4500,1,1,NULL,1437635274,NULL),(86,'29','32','Bank Slip',15000,1,1,NULL,1437638320,NULL),(87,'5','33','Bank Slip',5200,1,0,1,1447151568,1447151621),(88,'29','34','M-Pesa',78000,1,1,NULL,1447151661,NULL),(89,'29','35','M-Pesa',12000,1,1,NULL,1447151701,NULL),(90,'29','36','Cash',5000,1,1,NULL,1447159639,NULL),(91,'29','37','M-Pesa',5000,1,1,NULL,1448520634,NULL),(92,'29','38','Cheque',8500,1,1,NULL,1448979626,NULL),(93,'5','39','Cash',5000,1,1,NULL,1461075239,NULL),(94,'6','39','M-Pesa',4000,1,1,NULL,1461075240,NULL),(95,'18','39','Bank Slip',11000,1,1,NULL,1461075241,NULL),(96,'7','39','Cheque',8000,1,1,NULL,1461075241,NULL),(97,'6','40','Cash',5000,1,1,NULL,1461076990,NULL),(98,'18','40','M-Pesa',8000,1,1,NULL,1461076990,NULL),(99,'18','40','Bank Slip',60000,1,1,NULL,1461076990,NULL),(100,'17','41','Cash',22000,1,1,NULL,1461077013,NULL),(101,'7','42','Cash',43000,1,1,NULL,1461077261,NULL),(102,'6','43','Cash',22000,1,0,1,1461137287,1461137552),(103,'31','44','Cash',21000,1,0,1,1461137376,1461137568),(104,'31','45','Cash',71000,1,1,NULL,1461137462,NULL),(105,'31','46','Cash',71000,1,1,NULL,1461137498,NULL),(106,'6','47','M-Pesa',5000,1,0,1,1468848059,1473922352),(107,'33','48','Cheque',5000,1,1,NULL,1475049599,NULL);
/*!40000 ALTER TABLE `members_tithe` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `ministries`
DROP TABLE IF EXISTS `ministries`;
CREATE TABLE `ministries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(256) NOT NULL DEFAULT '',
  `name` varchar(256) NOT NULL DEFAULT '',
  `leader` varchar(32) NOT NULL DEFAULT '',
  `telephone` varchar(256) NOT NULL DEFAULT '',
  `mobile` varchar(256) NOT NULL DEFAULT '',
  `email` varchar(256) NOT NULL DEFAULT '',
  `congregation_size` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Dumping data for table `ministries`
LOCK TABLES `ministries` WRITE;
/*!40000 ALTER TABLE `ministries` DISABLE KEYS */;
INSERT INTO `ministries` VALUES (1,'MIN-001','Praise and Worship','5','125485569','(012) 548-8888','vandax22@gmail.com','50','This is the congregation',1,1,1420888792,1420888867),(2,'MIN-002','Ushering','6','2445858','(120) 258-8888','x22@gmail.com','100','This is another ministry',1,NULL,1420889182,NULL),(3,'MIN-0003','Men Ministry','7','254825882','(125) 485-2588','admin2@admin.com','500','This is Men Ministry',1,NULL,1420889277,NULL),(4,'MIN-004','Women Ministry','18','255885558','(212) 585-2558','vand@gmail.com','100','Men Ministry',1,1,1420889328,1420890823);
/*!40000 ALTER TABLE `ministries` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `ministry_support`
DROP TABLE IF EXISTS `ministry_support`;
CREATE TABLE `ministry_support` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` blob,
  `totals` blob,
  `member` blob NOT NULL,
  `amount` blob NOT NULL,
  `bank` blob NOT NULL,
  `treasurer` blob NOT NULL,
  `confirmed_by` blob NOT NULL,
  `description` blob,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- Dumping data for table `ministry_support`
LOCK TABLES `ministry_support` WRITE;
/*!40000 ALTER TABLE `ministry_support` DISABLE KEYS */;
INSERT INTO `ministry_support` VALUES (1,0x85a70faaf08eb29f72d33a7c55585c80,0x83ddf4ea671544fe4117354cf5a2bc23,'','',0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x1c5fd03425cc26ad6d770d46d19ddfd0,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343231363630303033,0xe3d4f67e6d17d33b1b481012082cc5ad),(2,0x2eea5d752f7d897b7f09a2b3c9a175b5,0xcd784de2b7628906c5a82bc50e039f83,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x41a801d238569c8e7c2e2accad35b06e,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343232393533323837,0x74745d7fe0f46e68315c510d12b036eb),(3,0x3a442e7dd341b0ace3aba3e844f05ed2,0xd7a7dab203de0e7c7b891499bec31e5d,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343232393539333133,0x54675afa9a7db4d0cfb423333b4d7820),(4,0xd0b5426cd8a78128adf866909e0d49e1,0xc32cdd8682fd9f82eb96ecd25fd7d407,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xb7d86e45bc1b2ce8d771a79f630d198a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343233313232353432,0xea5eca1c1b6c542709208ccc30f4d745),(5,0x86d1a6c5ab95ead765d47606e7b84db2,0x2d6cbc535ed536b2b0d78114084a927e,'','',0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x6ecdacfed1a049dce2135d374d6f3f2f,NULL),(6,0x2d4835490ad5c9d895034bb3a4c4c0a8,0xfc47ce1ba6daa0ba26add0cb013cb472,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0xcfa10a53ac284db808f6bedd952eb03d,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xe3c94bee0356e8fc2df7c8b30e9db298,NULL),(7,0xe56dccb9bc016e1cbab5fa015764447a,0xe34e7632beaad6a3c4c2514d0d3548b9,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0xcfa10a53ac284db808f6bedd952eb03d,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xfbbdde62f3e021b3fdab04feaf54165a,NULL),(8,0x2d4835490ad5c9d895034bb3a4c4c0a8,0xeb15b7b799204400bdcf27cc34b013ae,'','',0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x158e7f86c82be2e37a9fa1685f806435,NULL),(9,0xebbe82871bc5eae32e56f09db236b6c2,0x536281d9045f3f7836eacebae017a7f7,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xf68e203cc6165bd66b9ba393c98dd1f7,NULL),(10,0xf8f12444f298c0fe854d9ffb58f6a7ad,0x2fe1cd385cca3513a00f11be716f9b57,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x39f7cd9acabbd62e81f0d21866ce8433,NULL),(11,0xce163a5e6e604416437065a5129bb35a,0xc9bdf3e542ef47aa9dfcd7f3942cf607,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x41a801d238569c8e7c2e2accad35b06e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x26bea6c4f7ed398a711f7f491ad74c9c,NULL),(12,0xdfcdeb303296bf331598ee7951bf9d15,0xc4d28a9b93a570db340d3cfc07ecad0d,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x5b581303c0ad955865b7ba1f5e0bc10b,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x19f1c79b949cb1bb1dcfa52e6fe1ef11,NULL),(13,0xdb5d67d3800441b99d351566fe1a9a57,0xe390079e74b26ffb84b8592a971f78ef,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x419480523def815f0efd964a28cf2572,NULL),(14,0x5fe62a94cfdca054c5561904cf0f4522,0x528dffc9a15cda48fa08f7e66c3c2941,'','',0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xc3e7a89b20b746e2dea0bbc1a6ab4e1b,NULL);
/*!40000 ALTER TABLE `ministry_support` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `o_sessions`
DROP TABLE IF EXISTS `o_sessions`;
CREATE TABLE `o_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table `o_sessions`
LOCK TABLES `o_sessions` WRITE;
/*!40000 ALTER TABLE `o_sessions` DISABLE KEYS */;
INSERT INTO `o_sessions` VALUES ('9216179486d1f6bdd1e0fc75d2cf12d7','::1','Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.116 Safari/537.36',1475045276,'a:6:{s:9:\"user_data\";s:0:\"\";s:5:\"email\";s:15:\"super@admin.com\";s:2:\"id\";s:1:\"1\";s:7:\"user_id\";s:1:\"1\";s:8:\"group_id\";s:1:\"1\";s:5:\"group\";s:5:\"admin\";}');
/*!40000 ALTER TABLE `o_sessions` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `offerings`
DROP TABLE IF EXISTS `offerings`;
CREATE TABLE `offerings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` blob,
  `status` blob,
  `amount` blob NOT NULL,
  `treasurer` blob NOT NULL,
  `confirmed_by` blob NOT NULL,
  `bank_deposited` blob NOT NULL,
  `description` blob,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- Dumping data for table `offerings`
LOCK TABLES `offerings` WRITE;
/*!40000 ALTER TABLE `offerings` DISABLE KEYS */;
INSERT INTO `offerings` VALUES (1,0xecc49169c090d8a8ed3d739acd76b3db,0x82a1e878c5ac69376cb8b60f78d0d878,0x1fc6db3531f60552aa4811b1910ce906,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x90065fe9ea51973a4989393c1f3a44af,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343231323439303733,0x306361316b938281746f35a697bce7e5),(2,0x972f5f280cd9f50dad8be597db3522df,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xa284a21b23a0634e5bad9c7279df5f7f,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x90065fe9ea51973a4989393c1f3a44af,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343231323439343238,0x6d25a7a8ff7f65e6300aac4a070dbc9a),(3,0x85a70faaf08eb29f72d33a7c55585c80,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x1291b17c0408d2f5c2d1f424c722e5c1,0x90065fe9ea51973a4989393c1f3a44af,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x18436694a03ae5a110e96ebd835f8201,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343233313230383937,0xfca53977b7fa5799772d2e4d23141dd2),(4,0x2eea5d752f7d897b7f09a2b3c9a175b5,0x82a1e878c5ac69376cb8b60f78d0d878,0x95f644d9e53d9919e8550504bbb57383,0xcfa10a53ac284db808f6bedd952eb03d,0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343233313438373734,0x294b4a5d4545ed009aef00bd975db01f),(5,0x3a442e7dd341b0ace3aba3e844f05ed2,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x3b3d68a9d20bc3d917e91533480f0e53,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343233313438383031,0x4b54715b4b0bc636d48bcdb858986e4f),(6,0x2eea5d752f7d897b7f09a2b3c9a175b5,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x532f665f8b9e27b3edf0594508bcbb08,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x90065fe9ea51973a4989393c1f3a44af,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343233313438383234,0xbc2459c81d56fd907152b0045982cc05),(7,0x3a442e7dd341b0ace3aba3e844f05ed2,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xd3ab0eb5857ea9a53f668468f1abcec2,0xcfa10a53ac284db808f6bedd952eb03d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343233323133303733,0xd7af1605e845906b83a3a740ff172006),(8,0x3a442e7dd341b0ace3aba3e844f05ed2,0x82a1e878c5ac69376cb8b60f78d0d878,0xc9bdf3e542ef47aa9dfcd7f3942cf607,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0x3892c37e33385119b98bb54b2acb2403,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343233323133313335,0x0361804601ab1a926429b515ef869184),(9,0x5af1a736adbb4f953345df160447dde5,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xa284a21b23a0634e5bad9c7279df5f7f,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xb2c259b17c28b3b20797f252a1d5cd372d5f97570fd4692c387e2a4a3cb9a41f,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xf89ceaa84da3660ee25de3d0838f71a8,NULL),(10,0x27adbfe44ee2df162340ad646993de42,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x2e7e539c4ef10c0ee4cca7e89dfbc9e2,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x90065fe9ea51973a4989393c1f3a44af,0x41a801d238569c8e7c2e2accad35b06e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x68f99c67c5c0e96ca5cf9b5d98c91bae,NULL),(11,0x7a183200db6fbd6c14b7caf14fa97c44,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x6672567c942e88b71febb4110da43473,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xd56b5ec073651a40db944b6cc66e0bde,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xfe96c16436cb235abc0d99331e0df403,NULL),(12,0x4074c095f4634e5eaf01dbc732efe5c8,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xa88174fd3e4a55aca4b252b7469f736d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x90065fe9ea51973a4989393c1f3a44af,0x41a801d238569c8e7c2e2accad35b06e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xc1681b1e8459a6d5231cc671045a81fd,NULL),(13,0xef0cc3100dc0774e29a92eb9ee013b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x2e7e539c4ef10c0ee4cca7e89dfbc9e2,0xcfa10a53ac284db808f6bedd952eb03d,0xcfa10a53ac284db808f6bedd952eb03d,0x90065fe9ea51973a4989393c1f3a44af,0x41a801d238569c8e7c2e2accad35b06e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x573f32259f8af5752ec040e0c3e3621b,NULL),(14,0xf1e94fa1c2ac0a5093ab9f6d992ca5aa,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xc0bf9e711138cd0767cba7dc3067add7,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x90065fe9ea51973a4989393c1f3a44af,0x41a801d238569c8e7c2e2accad35b06e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x5192e8dc374a4b47389aceab4f05a222,NULL),(15,0x4ed9884565af45ba96ac38727c9afcb4,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xddc5843b2aa5588f3d3ff7e035fc4644,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xcfa10a53ac284db808f6bedd952eb03d,0x90065fe9ea51973a4989393c1f3a44af,0x41a801d238569c8e7c2e2accad35b06e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x2afe0ac0293f58bbbf7dd0862562ba03,NULL),(16,0x7ba282a1c471f3228d7770cba0e322a4,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x1ee4bbabce80d7958a57b9c454721bd1,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x90065fe9ea51973a4989393c1f3a44af,0x41a801d238569c8e7c2e2accad35b06e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x17cd78fb14351e4b140c1e6bd583c0f3,NULL),(17,0x5761a4285745d9ba7ecc803a7b17f479,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x0fef04ac3a9badaacfd77cceb0011f70,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x90065fe9ea51973a4989393c1f3a44af,0x41a801d238569c8e7c2e2accad35b06e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x9e62f46335dcaf65c7ba4efaeaf60a89,NULL),(18,0xf8f12444f298c0fe854d9ffb58f6a7ad,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xc4d28a9b93a570db340d3cfc07ecad0d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x6b6a7b36339097151467387569ff57b80cfdbc9a1526a10957ab4c475a7d387c,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x36439fdc957ef88edaf100e62d530cf0,NULL),(19,0x030e2b2a5df1c1f5d5adcc5d5c1d9037,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x6672567c942e88b71febb4110da43473,0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x41a801d238569c8e7c2e2accad35b06e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa149b14e48d9986f6377c2f9e79f355b,NULL),(20,0x9f52097902bcbdf99b82cecb544cd8a0,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x968e26ae5674c4eee91a790547525ed0,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x41a801d238569c8e7c2e2accad35b06e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x1cea5e46b67f44f7176b71301398f33e,NULL),(21,0xdfcdeb303296bf331598ee7951bf9d15,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xeace595bd96147bd2683f35ca365291c,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x90065fe9ea51973a4989393c1f3a44af,0x00088b05d8f23bfc698885a93d049414,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xf573da8b209e785cc7d14156832e19eb,NULL),(22,0xbc6964e7256cd5cd184658824d24e999,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xc4d28a9b93a570db340d3cfc07ecad0d,0x90065fe9ea51973a4989393c1f3a44af,0xcdf3a1cb3f3ee08d0e0c63e679397c3a,0x90065fe9ea51973a4989393c1f3a44af,0x00088b05d8f23bfc698885a93d049414,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x464cb2531730be78d3748e65bf3268ad,NULL),(23,0x3684f4b123df223b26e96e4df305690a,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xf423b322ba30314b6004239c0d189936,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x90065fe9ea51973a4989393c1f3a44af,0x5ff9e611d1222f55d71fbb0fc1a117a2,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xc6600e80b0c6ff71d1b33829cfb3eb70,NULL),(24,0xdb5d67d3800441b99d351566fe1a9a57,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x7056e74e1a4b93099f7d6f61e9e93589,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x90065fe9ea51973a4989393c1f3a44af,0x41a801d238569c8e7c2e2accad35b06e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x0fa340db8721735a0d7972ecd44e4b87,NULL),(25,0x5fe62a94cfdca054c5561904cf0f4522,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9385630dffd0eac97bdc227b4d15403d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x90065fe9ea51973a4989393c1f3a44af,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x4071c43be1e4d61fadb6b26e7daf8d83,NULL),(26,0xde354c555151f25cc244e160b8423eb8,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x209a1d42efa12402299ec744d39cd2ae,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x90065fe9ea51973a4989393c1f3a44af,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xf5942f3d5ad6ff294ce68a9f78f84fe1,NULL);
/*!40000 ALTER TABLE `offerings` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `other_contributions`
DROP TABLE IF EXISTS `other_contributions`;
CREATE TABLE `other_contributions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` blob,
  `contribution_type` blob,
  `totals` blob,
  `member` blob NOT NULL,
  `amount` blob NOT NULL,
  `bank` blob NOT NULL,
  `treasurer` blob NOT NULL,
  `confirmed_by` blob NOT NULL,
  `description` blob,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- Dumping data for table `other_contributions`
LOCK TABLES `other_contributions` WRITE;
/*!40000 ALTER TABLE `other_contributions` DISABLE KEYS */;
INSERT INTO `other_contributions` VALUES (1,0xc5ccffbf053bb1043269672140a6832e,0xe1f7f7bd788a5ed3d65a0a992e1f5f52,0x4391077a06145eefb35e8f0326cb35a8,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343231363736353437,0x05b6e5f54283c1048f0894bc057ef4d8),(2,0x341b889cb0d1b79192c7923cb086673b,0xe1f7f7bd788a5ed3d65a0a992e1f5f52,0xcd916a7494848ea581204cb812fa3e5c,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa60855d010f1bf26e4c8f69fb76a9412a545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343231363831383736,0xd870256b300c498c14553708ccf4e491),(3,0x54669a2a16c1584f045775376879e07d,0xe1f7f7bd788a5ed3d65a0a992e1f5f52,0xb01ba61c13cb728124ef025470b5be12,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x41a801d238569c8e7c2e2accad35b06e,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343231363831393934,0xe9f4426f2099740f77fbf6e1f149771d),(4,0x9b0af034020e77f6b96bada54fcb97a3,0xe1f7f7bd788a5ed3d65a0a992e1f5f52,0xa748668db8c908dd27f0f1675be591cf,'','',0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343232393538313537,0x86015f47a1e77607a50c4d00ea393978),(5,0x7f39c945b03a93ece0a900daf62e3fc2,0x6278d03adb36391e12615a9c8a0fe2dd,0x60d55e9a8f73eb796319e9f8dae2e024,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x41a801d238569c8e7c2e2accad35b06e,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343232393539383431,0xc1f60d32339d75bd8345587ea716fda5),(6,0xef8aa73e474fb6da18a9397e96d11a6a,0xe1f7f7bd788a5ed3d65a0a992e1f5f52,0x532f665f8b9e27b3edf0594508bcbb08,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0xcfa10a53ac284db808f6bedd952eb03d,0xcfa10a53ac284db808f6bedd952eb03d,0x0e19b9ef185d1e818ef484ddcfc31cc7,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343233313232383035,0x4547ca084c57561949002cf132c78d81),(7,0x479b76baa01aa28a6928be4a0325e1a6,0xe1f7f7bd788a5ed3d65a0a992e1f5f52,0xa84a0b1d104d93239462538148e3c92b,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x41a801d238569c8e7c2e2accad35b06e,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343233323438333739,0x71961415e0b40cdaa0c93135abf19234),(8,0xb05dec61706fd3a6a66351370951d84d,0x6278d03adb36391e12615a9c8a0fe2dd,0x94cd17a0b7849da8b093dedbc80f43ce,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa8766f702420fc44a1d24b10e4ca34ad,NULL),(9,0x2d4835490ad5c9d895034bb3a4c4c0a8,0xe2a390b58325c1cf93f752183e0090a4,0xd3ab0eb5857ea9a53f668468f1abcec2,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xb98733a10db2c2fefbb847209fe4fb36,NULL),(10,0x2d4835490ad5c9d895034bb3a4c4c0a8,0x6278d03adb36391e12615a9c8a0fe2dd,0x3a356dffd4b436fdb7510736b0f9f5fa,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x4d65709a2944af6707f64f36074b324a,NULL),(11,0xe56dccb9bc016e1cbab5fa015764447a,0xcfa10a53ac284db808f6bedd952eb03d,0x0d8f9b451c1643d327535986d0c61e3b,'','',0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x3b765a2eca823a6d87a331391f1083ef,NULL),(12,0xce163a5e6e604416437065a5129bb35a,0xe2a390b58325c1cf93f752183e0090a4,0xd3ab0eb5857ea9a53f668468f1abcec2,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x41a801d238569c8e7c2e2accad35b06e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa43e297c9f2c8ffdc672577b027290a2,NULL),(13,0xdb5d67d3800441b99d351566fe1a9a57,0x6278d03adb36391e12615a9c8a0fe2dd,0xf74d21723b060cc6519a64085b2af8cc,'','',0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xa292726a935d961f05b5d3bc7781d7e9,NULL),(14,0x0910ccf2bcff6562f681b763730ad4a2,0xe1f7f7bd788a5ed3d65a0a992e1f5f52,0x209a1d42efa12402299ec744d39cd2ae,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0xcfa10a53ac284db808f6bedd952eb03d,0xcdf3a1cb3f3ee08d0e0c63e679397c3a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xd3ba9a7a688c55b03c1b3e33b631ecb6,NULL),(15,0x7424b96f4b6b090ce5aaa44805a172b0,0x4a18b3f049ec94e84aa51826dd939564,0x3a6d666126f2718953e62f1987f4f200,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0xcfa10a53ac284db808f6bedd952eb03d,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x3bff06bc12ac7663980368353afc6bf1,NULL);
/*!40000 ALTER TABLE `other_contributions` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `other_revenues`
DROP TABLE IF EXISTS `other_revenues`;
CREATE TABLE `other_revenues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `project` varchar(32) NOT NULL DEFAULT '',
  `amount` varchar(256) NOT NULL DEFAULT '',
  `collected_by` varchar(32) NOT NULL DEFAULT '',
  `bank` varchar(32) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Dumping data for table `other_revenues`
LOCK TABLES `other_revenues` WRITE;
/*!40000 ALTER TABLE `other_revenues` DISABLE KEYS */;
INSERT INTO `other_revenues` VALUES (1,1433797200,'2','45000','3','2','1st installment',1,NULL,1433840830,NULL),(3,1433624400,'1','780000','3','1','new',1,NULL,1433841311,NULL),(4,1433710800,'3','24500','2','0','Paid',1,NULL,1433842664,NULL),(5,1433797200,'2','78500','3','2','Paid',1,NULL,1433843106,NULL),(6,1461013200,'1','250000','3','2','Banked',1,NULL,1461075507,NULL);
/*!40000 ALTER TABLE `other_revenues` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `paid_pledges`
DROP TABLE IF EXISTS `paid_pledges`;
CREATE TABLE `paid_pledges` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `pledge_id` int(11) DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `bank` int(11) DEFAULT NULL,
  `remarks` text NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `transaction_no` varchar(50) NOT NULL,
  `amount` float DEFAULT NULL,
  `balance` float DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table `paid_pledges`
LOCK TABLES `paid_pledges` WRITE;
/*!40000 ALTER TABLE `paid_pledges` DISABLE KEYS */;
INSERT INTO `paid_pledges` VALUES (6,5,1421481111,1,NULL,'Good payment','Cash','1254852',10000,10000,1,NULL,1421481111,NULL),(7,6,1421841731,1,NULL,'The amount is paid','Cash','12548758',8500,0,1,NULL,1421841731,NULL),(8,7,1421844643,1,NULL,'paid','Cash','254859',700,0,1,NULL,1421844643,NULL),(9,8,1421846555,1,NULL,'Bal 1500','Cash','12548235',1000,1500,1,NULL,1421846555,NULL),(10,5,1422355567,1,1,'Balance of 4000','Cash','04587855',6000,4000,1,NULL,1422355567,NULL),(11,5,1422945230,1,1,'Payment made','Cash','1254878',2000,2000,1,NULL,1422945230,NULL),(12,1,1422945625,1,1,'Paid','Cash','120548758',2000,3000,1,NULL,1422945625,NULL),(13,9,1422945763,1,1,'Paid','Bank Slip','1254852',3000,5500,1,NULL,1422945763,NULL),(14,3,1422945895,1,2,'Paid','M-Pesa','548858',1500,0,1,NULL,1422945895,NULL),(15,9,1422960794,1,1,'New balance','Cash','12548235',700,4800,1,NULL,1422960794,NULL),(16,1,1423122048,1,2,'Balance 1000','Cash','1250248235',2000,1000,1,NULL,1423122048,NULL),(17,13,1432648629,1,1,'Thanks','Cash','125478',7500,0,1,NULL,1432648629,NULL),(18,14,1433682125,1,1,'','Cash','455888855',10000,16000,1,NULL,1433682125,NULL);
/*!40000 ALTER TABLE `paid_pledges` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `permissions`
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `res_id` int(11) NOT NULL,
  `route_id` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table `permissions`
LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `petty_cash`
DROP TABLE IF EXISTS `petty_cash`;
CREATE TABLE `petty_cash` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `item` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `voucher_number` varchar(256) NOT NULL DEFAULT '',
  `amount` varchar(256) NOT NULL DEFAULT '',
  `authorised_by` varchar(32) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- Dumping data for table `petty_cash`
LOCK TABLES `petty_cash` WRITE;
/*!40000 ALTER TABLE `petty_cash` DISABLE KEYS */;
INSERT INTO `petty_cash` VALUES (1,1420491600,1,1,'CD0001','2000','3','Food',1,NULL,1421245262,NULL),(2,1420405200,2,1,'CD0002','5600','1','Another petty cash',1,NULL,1421245856,NULL),(3,1432414800,7,1,'VN-03','2500','2','Soap was bought',1,NULL,1432636509,NULL),(4,1432414800,2,1,'VN-04','2580','3','This was given to mark makau',1,NULL,1432636926,NULL),(5,1432501200,4,1,'VN-05','4500','2','This was paid yesterday',1,NULL,1432637132,NULL),(6,1432501200,6,1,'VN-06','4800','2','Water was paid by Jemo',1,1,1432640260,1433147511),(7,1442955600,6,1,'VN-07','5200','2','New',1,NULL,1443684041,NULL),(8,1461013200,5,1,'VN-08','500','3','Water payment',1,NULL,1461075716,NULL);
/*!40000 ALTER TABLE `petty_cash` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `pledges`
DROP TABLE IF EXISTS `pledges`;
CREATE TABLE `pledges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `title` varchar(256) NOT NULL DEFAULT '',
  `member` varchar(32) NOT NULL DEFAULT '',
  `amount` varchar(256) NOT NULL DEFAULT '',
  `expected_pay_date` int(11) DEFAULT NULL,
  `status` varchar(32) NOT NULL DEFAULT '',
  `remarks` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- Dumping data for table `pledges`
LOCK TABLES `pledges` WRITE;
/*!40000 ALTER TABLE `pledges` DISABLE KEYS */;
INSERT INTO `pledges` VALUES (1,1421096400,'Church Land','6','1000',1422651600,'1','New Pledge',1,1,1421414576,1423122048),(3,1421355600,'Church Land','22','0',1421355600,'2','This is a pledge',1,1,1421415916,1422945895),(4,1420923600,'Team Builing','22','2500',1421701200,'0','This pledge',1,1,1421417955,1421417962),(5,1421787600,'School Building','22','2000',1422306000,'1','This is it',1,1,1421418705,1422945230),(6,1421528400,'Fund Raising','22','0',1421874000,'2','This is the guy',1,1,1421841688,1421841731),(7,1421528400,'Fund Raising','17','0',1421960400,'2','this another one',1,1,1421844624,1421844643),(8,1420405200,'Appreciation','22','1500',1422046800,'1','Not Paid',1,1,1421844701,1421846555),(9,1422997200,'Fund Raising','16','4800',1424379600,'1','Promise to pay any time',1,1,1422945736,1422960794),(10,1423515600,'Church Building','19','15800',1423602000,'1','To be paid',1,NULL,1423127495,NULL),(11,1425934800,'Camp Registration','27','7500',1427230800,'1','Not Paid',1,NULL,1426595750,NULL),(12,1431810000,'church building','17','15000',1432587600,'1','Not Paid',1,NULL,1432010350,NULL),(13,1431810000,'Committee Contribution','29','0',1432242000,'2','Not paid',1,1,1432010399,1432648629),(14,1430600400,'church building','29','16000',1430859600,'1','Not Paid',1,1,1432010436,1433682125),(15,1433624400,'Buying Speakers','7','5000',1434229200,'1','Not Paid',1,NULL,1433768053,NULL),(16,1461013200,'Primary','6','7500',1461013200,'1','Not paid',1,NULL,1461075480,NULL);
/*!40000 ALTER TABLE `pledges` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `prayer_requests`
DROP TABLE IF EXISTS `prayer_requests`;
CREATE TABLE `prayer_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_date` int(11) DEFAULT NULL,
  `phone_number` varchar(256) NOT NULL DEFAULT '',
  `first_name` varchar(256) NOT NULL DEFAULT '',
  `second_name` varchar(256) NOT NULL DEFAULT '',
  `address` varchar(256) NOT NULL DEFAULT '',
  `membership` varchar(32) NOT NULL DEFAULT '',
  `prayer_request` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `prayer_requests`
LOCK TABLES `prayer_requests` WRITE;
/*!40000 ALTER TABLE `prayer_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `prayer_requests` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `purchase_order`
DROP TABLE IF EXISTS `purchase_order`;
CREATE TABLE `purchase_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_date` int(11) DEFAULT NULL,
  `supplier` int(9) NOT NULL,
  `quatity` varchar(256) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `amount` varchar(256) NOT NULL DEFAULT '',
  `vat` varchar(256) NOT NULL DEFAULT '',
  `total` varchar(256) NOT NULL DEFAULT '',
  `comment` text,
  `status` int(11) DEFAULT NULL,
  `balance` float DEFAULT NULL,
  `due_date` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table `purchase_order`
LOCK TABLES `purchase_order` WRITE;
/*!40000 ALTER TABLE `purchase_order` DISABLE KEYS */;
INSERT INTO `purchase_order` VALUES (1,1421010000,1,'','','','1','0','To be paid',0,NULL,1422478800,1,1,1422353962,1422354412),(2,1421701200,1,'','','','1','2000','test',1,NULL,1422651600,1,NULL,1422354243,NULL),(3,1421701200,1,'','','','1','0','treer',0,NULL,1421874000,1,1,1422354350,1422354405),(4,1420923600,1,'','','','1','5760','treer',3,0,1422306000,1,1,1422354399,1423476659);
/*!40000 ALTER TABLE `purchase_order` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `purchase_order_list`
DROP TABLE IF EXISTS `purchase_order_list`;
CREATE TABLE `purchase_order_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(9) NOT NULL,
  `quantity` float NOT NULL,
  `description` text NOT NULL,
  `unit_price` float NOT NULL,
  `totals` double NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table `purchase_order_list`
LOCK TABLES `purchase_order_list` WRITE;
/*!40000 ALTER TABLE `purchase_order_list` DISABLE KEYS */;
INSERT INTO `purchase_order_list` VALUES (1,1,120,'This is an order',120,14400,1,NULL,1422353962,NULL),(2,2,40,'This is an order',50,2000,1,NULL,1422354243,NULL),(3,3,120,'This is an order',50,6000,1,NULL,1422354350,NULL),(4,4,120,'My new order',48,5760,1,NULL,1422354399,NULL);
/*!40000 ALTER TABLE `purchase_order_list` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `purchase_order_payment`
DROP TABLE IF EXISTS `purchase_order_payment`;
CREATE TABLE `purchase_order_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` blob NOT NULL,
  `amount` blob NOT NULL,
  `date` blob NOT NULL,
  `pay_type` blob NOT NULL,
  `account` blob NOT NULL,
  `remarks` blob NOT NULL,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table `purchase_order_payment`
LOCK TABLES `purchase_order_payment` WRITE;
/*!40000 ALTER TABLE `purchase_order_payment` DISABLE KEYS */;
INSERT INTO `purchase_order_payment` VALUES (1,0xcdf3a1cb3f3ee08d0e0c63e679397c3a,0xf082a6d0e7258ca8e38c85d360e10933,0x67f5460fa6c3b743754ffcbeac6ddd20,0x5bb72ddd77363fd2c6e663ac8c7d40d7,0x96c5d80e770c9e374eeea6902aac380b,0xbb0a1c853427bd6291bf0bf9df925c58,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x90fc58236097036398992897ed2e0b40,NULL),(2,0xcdf3a1cb3f3ee08d0e0c63e679397c3a,0x9a9a123654993463f16c964229af0580,0x5af1a736adbb4f953345df160447dde5,0x371109abb874c7852899a30d80e44237,0x96c5d80e770c9e374eeea6902aac380b,0x36321e01b47b68cb195e226e83ac75ea,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x7027817279012d8bf92169adc2989690,NULL);
/*!40000 ALTER TABLE `purchase_order_payment` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `record_salaries`
DROP TABLE IF EXISTS `record_salaries`;
CREATE TABLE `record_salaries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_date` int(11) DEFAULT NULL,
  `employee` int(11) DEFAULT NULL,
  `basic_salary` float DEFAULT NULL,
  `total_deductions` float DEFAULT NULL,
  `total_allowance` float DEFAULT NULL,
  `nhif` float DEFAULT NULL,
  `advance` float DEFAULT NULL,
  `bank_details` text NOT NULL,
  `month` varchar(50) NOT NULL,
  `year` int(11) DEFAULT NULL,
  `deductions` text NOT NULL,
  `allowances` text NOT NULL,
  `nhif_no` varchar(255) NOT NULL,
  `nssf_no` varchar(255) NOT NULL,
  `salary_method` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- Dumping data for table `record_salaries`
LOCK TABLES `record_salaries` WRITE;
/*!40000 ALTER TABLE `record_salaries` DISABLE KEYS */;
INSERT INTO `record_salaries` VALUES (1,1420578000,2,54000,0,0,320,5000,'Bank of Africa<br>12548878','January',2015,'0','0','3258848','325984','Monthly','This is comment',1,NULL,1422346360,NULL),(2,1433624400,3,44000,1500,0,320,0,'<br>1022548878','February',2015,'Loan:1000,SACCO:500','0','0243258848','13785225984','Monthly','This is your salary',1,NULL,1433765499,NULL),(3,1433624400,2,54000,3000,10000,320,5000,'<br>12548878','February',2015,'Loan:1000,Others:1500,SACCO:500','Travelling Allowance:10000','3258848','325984','Monthly','This is your salary',1,NULL,1433765499,NULL),(4,1425934800,3,44000,1500,0,320,0,'<br>1022548878','March',2015,'Loan:1000,SACCO:500','0','0243258848','13785225984','Monthly','Salary',1,NULL,1433765566,NULL),(5,1425934800,2,54000,3000,10000,320,0,'<br>12548878','March',2015,'Loan:1000,Others:1500,SACCO:500','Travelling Allowance:10000','3258848','325984','Monthly','Salary',1,NULL,1433765566,NULL),(6,1433624400,3,44000,1500,0,320,0,'<br>1022548878','April',2015,'Loan:1000,SACCO:500','0','0243258848','13785225984','Monthly','Salary',1,NULL,1433765582,NULL),(7,1433624400,2,54000,3000,10000,320,0,'<br>12548878','April',2015,'Loan:1000,Others:1500,SACCO:500','Travelling Allowance:10000','3258848','325984','Monthly','Salary',1,NULL,1433765583,NULL),(8,1430686800,3,44000,1500,0,320,0,'<br>1022548878','May',2015,'Loan:1000,SACCO:500','0','0243258848','13785225984','Monthly','Salary',1,NULL,1433765602,NULL),(9,1430686800,2,54000,3000,10000,320,0,'<br>12548878','May',2015,'Loan:1000,Others:1500,SACCO:500','Travelling Allowance:10000','3258848','325984','Monthly','Salary',1,NULL,1433765602,NULL),(10,1428958800,3,44000,1500,0,320,0,'<br>1022548878','April',2015,'Loan:1000,SACCO:500','0','0243258848','13785225984','Monthly','salary',1,NULL,1433765730,NULL),(11,1428958800,2,54000,3000,10000,320,0,'<br>12548878','April',2015,'Loan:1000,Others:1500,SACCO:500','Travelling Allowance:10000','3258848','325984','Monthly','salary',1,NULL,1433765730,NULL);
/*!40000 ALTER TABLE `record_salaries` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `relatives`
DROP TABLE IF EXISTS `relatives`;
CREATE TABLE `relatives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL DEFAULT '0',
  `first_name` varchar(256) NOT NULL DEFAULT '',
  `last_name` varchar(256) NOT NULL DEFAULT '',
  `gender` varchar(32) NOT NULL DEFAULT '',
  `type` varchar(32) NOT NULL DEFAULT '',
  `relationship` varchar(32) NOT NULL DEFAULT '',
  `phone` varchar(256) NOT NULL DEFAULT '',
  `location` varchar(256) NOT NULL DEFAULT '',
  `email` varchar(256) NOT NULL DEFAULT '',
  `additionals` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- Dumping data for table `relatives`
LOCK TABLES `relatives` WRITE;
/*!40000 ALTER TABLE `relatives` DISABLE KEYS */;
INSERT INTO `relatives` VALUES (3,21,'Steves','Jukah','Male','spouse','father','(125) 558-8555','Buru','van2@gmail.com','',1,1,1420814192,1420816331),(4,21,'Musa','musau','Male','others','friend','(123) 558-8888','Buru','van22@gmail.com','0',1,NULL,1420818114,NULL),(8,22,'Jenipher','Lopez','Male','others','aunt','(125) 588-8888','Buru','van2@gmail.com','Good person',1,1,1420819175,1422694654),(9,22,'Willis','Agwati','Male','parent','grandparent','(125) 258-8888','Buru','van2@gmail.com','0',1,1,1420819380,1421826480),(11,22,'Lukas','ndwala','Male','guardian','grandparent','(125) 588-8969','Buru','van1222@gmail.com','0',1,NULL,1420819865,NULL),(13,24,'Moses','Lawama','Male','sibling','aunt','(125) 588-8888','Father','vdax22@gmail.com','0',1,NULL,1420892488,NULL),(14,25,'Nyakoe','shindo','Female','spouse','others','(072) 548-7785','Nyamira','nyaks@gmail.com','0',1,NULL,1422891423,NULL),(15,19,'Victor','Nyosa','Male','guardian','mother','(072) 154-8888','Lugari','nyako77@gmail.com','0',1,NULL,1423124189,NULL),(16,16,'Joice','Nyambura','Female','spouse','others','(012) 524-8877','Mumias','joice@jj.com','0',1,NULL,1423124340,NULL),(17,18,'Ruth','Ewaso','Female','spouse','wife','(012) 458-8888','Masimba','ruth22@mail.com','0',1,NULL,1423124937,NULL),(18,5,'Musa','Jachiwo','Male','spouse','husband','(012) 548-8882','wich lum','musa@mm.org','0',1,NULL,1423125074,NULL),(19,23,'Steve','Mikora','Male','friend','friend','(012) 458-7888','Uthiru','mikora@gmail.com','0',1,NULL,1423127751,NULL),(20,26,'Benard','Oloo','Male','spouse','husband','(072) 134-1214','Umoja','be@ben.com','0',1,NULL,1424677667,NULL),(21,27,'Ruda','Polo','Female','spouse','wife','(072) 134-1214','Kisumu','ruda@gmail.com','0',1,NULL,1424680361,NULL),(22,28,'Apolo','Opolo','Male','sibling','others','(072) 134-1214','Kisumu','opolo@gmail.com','0',1,NULL,1424680641,NULL),(23,29,'Brender','Lukenya','Female','spouse','wife','(077) 507-7768','Buru','bbre@gmail.com','0',1,NULL,1426152584,NULL),(24,31,'Victor','Okwaro','Female','guardian','uncle','(072) 131-4101','','','0',1,NULL,1461077795,NULL),(25,32,'Joe','jurra','Female','friend','friend','','','','0',1,NULL,1475049262,NULL),(26,33,'Joe','jurra','Female','friend','friend','','','','0',1,NULL,1475049401,NULL);
/*!40000 ALTER TABLE `relatives` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `reports`
DROP TABLE IF EXISTS `reports`;
CREATE TABLE `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dtae` int(11) DEFAULT NULL,
  `title` varchar(256) NOT NULL DEFAULT '',
  `item_id` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `reports`
LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `resources`
DROP TABLE IF EXISTS `resources`;
CREATE TABLE `resources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resource` varchar(255) NOT NULL,
  `cat` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- Dumping data for table `resources`
LOCK TABLES `resources` WRITE;
/*!40000 ALTER TABLE `resources` DISABLE KEYS */;
/*!40000 ALTER TABLE `resources` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `routes`
DROP TABLE IF EXISTS `routes`;
CREATE TABLE `routes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resource` int(11) NOT NULL,
  `method` varchar(255) NOT NULL,
  `is_menu` tinyint(4) NOT NULL,
  `description` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- Dumping data for table `routes`
LOCK TABLES `routes` WRITE;
/*!40000 ALTER TABLE `routes` DISABLE KEYS */;
/*!40000 ALTER TABLE `routes` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `salaries`
DROP TABLE IF EXISTS `salaries`;
CREATE TABLE `salaries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee` varchar(256) NOT NULL DEFAULT '',
  `salary_method` varchar(256) NOT NULL DEFAULT '',
  `basic_salary` float DEFAULT NULL,
  `nhif` float DEFAULT NULL,
  `bank_account_no` varchar(256) NOT NULL DEFAULT '',
  `bank_name` varchar(256) NOT NULL DEFAULT '',
  `nhif_no` varchar(256) NOT NULL DEFAULT '',
  `nssf_no` varchar(256) NOT NULL DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Dumping data for table `salaries`
LOCK TABLES `salaries` WRITE;
/*!40000 ALTER TABLE `salaries` DISABLE KEYS */;
INSERT INTO `salaries` VALUES (2,'3','Monthly',44000,320,'1022548878','','0243258848','13785225984',1,1,1422367838,1422441255),(3,'2','Monthly',54000,320,'12548878','','3258848','325984',1,1,1422368378,1422441243);
/*!40000 ALTER TABLE `salaries` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `seed_planting`
DROP TABLE IF EXISTS `seed_planting`;
CREATE TABLE `seed_planting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` blob,
  `totals` blob,
  `member` blob NOT NULL,
  `amount` blob NOT NULL,
  `bank` blob NOT NULL,
  `treasurer` blob NOT NULL,
  `confirmed_by` blob NOT NULL,
  `description` blob,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- Dumping data for table `seed_planting`
LOCK TABLES `seed_planting` WRITE;
/*!40000 ALTER TABLE `seed_planting` DISABLE KEYS */;
INSERT INTO `seed_planting` VALUES (1,0x85a70faaf08eb29f72d33a7c55585c80,0xa6ddf86ce9ee5d3ba5bdc60d17e87a96,'','',0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x41a801d238569c8e7c2e2accad35b06e,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343231363632313534,0x0be043662c42b13d7aa3c8ee952d1467),(2,0x341b889cb0d1b79192c7923cb086673b,0xc6f73ff3837058f17dbe980b8178f33a,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x41a801d238569c8e7c2e2accad35b06e,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343231383431353633,0x5416281552adb9089451bbfe010e1fb5),(3,0xc55eea6abd509a5adcbd94da636542c5,0x252ca33f70d195f6ab14bbe848d9aa86,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343231383431363134,0x41ed5f678d65e239f406396b257e8b43),(4,0x54669a2a16c1584f045775376879e07d,0x426522ac9dc19da52d214e320b6d4c17,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343232393535393738,0x0c300bc8237fb1a26f9d96fc70c4f501),(5,0x2ab82f695c1b470f597cb0be24f360d7,0x60d55e9a8f73eb796319e9f8dae2e024,'','',0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343232393539363837,0xb1c01731927f71541691d5686d0914d9),(6,0xa120c472223bb1f6e62a47ccccb10be4,0x140df34bf338c985e14e20fe97e68541,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x1c5fd03425cc26ad6d770d46d19ddfd0,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343233313232323135,0xced40829506a2e8cc26a3bfe2ebc661f),(7,0xd0b5426cd8a78128adf866909e0d49e1,0xd01be0f90632ad9a323133b9a34f030b,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x41a801d238569c8e7c2e2accad35b06e,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343233323436373539,0x51c41ea1330ab8f1d01f8dbdd65e92ed),(8,0x86d1a6c5ab95ead765d47606e7b84db2,0xefcbf255754a35c00561e31e8ae6a563,'','',0x90065fe9ea51973a4989393c1f3a44af,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x08bc9a3b10c83cf873679558f1b3985a,NULL),(9,0xe56dccb9bc016e1cbab5fa015764447a,0xff220be5cd7691151351e20e5caab560,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0xcfa10a53ac284db808f6bedd952eb03d,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x5fb8c5725a0812b43d0d644e6d44ecf4,NULL),(10,0x2d4835490ad5c9d895034bb3a4c4c0a8,0x65977f18de2ebef0e0bc8d1ab1bef3b5,'','',0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x3ce386138e2d1e8b82143338cf4d2fcc,NULL),(11,0xe56dccb9bc016e1cbab5fa015764447a,0xffc65390e378134a88d2cbc4bd737343,'','',0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x41a801d238569c8e7c2e2accad35b06e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x2f395e8021165ee6744e21cea1432440,NULL),(12,0x7ba282a1c471f3228d7770cba0e322a4,0x3345d711cdc31f29917762d11b270496,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0xcfa10a53ac284db808f6bedd952eb03d,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x7ed08e01de1fd264b5be8463377457a3,NULL),(13,0xdb5d67d3800441b99d351566fe1a9a57,0xe4837d83371b4d2ac0b5d4565a467794,'','',0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x2af2cf57e50aa7af9d89462edd68b9f9,NULL),(14,0x0910ccf2bcff6562f681b763730ad4a2,0x6672567c942e88b71febb4110da43473,'','',0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xcdf3a1cb3f3ee08d0e0c63e679397c3a,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xe034d7c9b95ca7c4d083cc706ddf35f4,NULL),(15,0xde354c555151f25cc244e160b8423eb8,0x654ee6bc2cb5d019614e0c3bc4c80d19,'','',0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x2a25d466a42e936810c735775d1f6543,NULL);
/*!40000 ALTER TABLE `seed_planting` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `sermons`
DROP TABLE IF EXISTS `sermons`;
CREATE TABLE `sermons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_date` int(11) DEFAULT NULL,
  `title` varchar(256) NOT NULL DEFAULT '',
  `service_leader` varchar(256) NOT NULL DEFAULT '',
  `first_service` varchar(256) NOT NULL DEFAULT '',
  `second_service` varchar(256) NOT NULL DEFAULT '',
  `pastor_on_duty` varchar(32) NOT NULL DEFAULT '',
  `file` varchar(32) NOT NULL DEFAULT '',
  `sermon_theme` text,
  `description` text,
  `upload_sermon` varchar(256) NOT NULL DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `sermons`
LOCK TABLES `sermons` WRITE;
/*!40000 ALTER TABLE `sermons` DISABLE KEYS */;
/*!40000 ALTER TABLE `sermons` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `servers`
DROP TABLE IF EXISTS `servers`;
CREATE TABLE `servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `license` blob,
  `status` blob NOT NULL,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table `servers`
LOCK TABLES `servers` WRITE;
/*!40000 ALTER TABLE `servers` DISABLE KEYS */;
INSERT INTO `servers` VALUES (1,0xa6dad194194075b7fb69b56ae801a72e9a65057b345e4e232237df245485fc3a4750a64633022949a211ceea53e1f1f0a6dad194194075b7fb69b56ae801a72ea6dad194194075b7fb69b56ae801a72e5f27a34697bd47f2ae9fb620de3bc0388459c565724b0fc65f52e278c21b0d5a9128a1a6e3b7c0d825b599690dd4b63d6257b25d719d96b01594368a13c01d4b0e7a22faeaa8fb778bc388c10fd63da06510a4520e8d5bd6456792da900f04a274777869bb446cf461e88c796b005ff57e92c69ecf17672599f8bdbbbd5469ee897e3a6b24456f88aebc517fa7b53efc24ec2e81bd0cc80450af1da02cc5bbcf780556ea9cc8827e606bb930f06e0956349f2c4f90389d894b1800e144cbf02aef08876bcf863983b9468134d154cd8ab9daadce46df9c3932117292e330fab2328efce3f2318678d1be6399896b654c0256a2511673bc69e9516daf9f55d071868064accbba6460e9f9024024d72dd0eb2da2e2d193421fd5c8fce637a023735bef7e3e3878a654373f38a6d6ff4f8bd3fffeb38cf4da363072dd75041becbc2e5042e757a323ef314cc2d06aadefd655f4bf69cb7b511e77429168e2a1960485e3ea24a1e2b5751cc9f4a9255dfa2662ebf8de9f4eb02da4813e960db28eeb13b39deff1493250ff2c11e11d5b47e84d7cff9bfe2e47ffacd7d81c3d7d02a20ae1241291e6973360c0b180f8153283bb4275a58bca95720d696416889a7b574f7fa3e0a294eb16602a96694ab187956c2a0172b813ec6c3473acca7ce70e6ff3032c89c1bcea89b064bea0443e4b8c24eaa3bbc76f1b020a40b97fc9c6d286616d48c9835d533535f7d8edefb51529840428a4e5a0f6e07b870c3d9d0d6bcea0709d65c48216083167ea9dce188c3aaf0ccf152ebfcd4ffdab8319ab3a180757c025fb28797729254c47a3803f7893babe0aa4776e28b9e36ec9c4e74165f5be9cc1e1798cf45e0a040b3dd8639c0ea648b4f44ab1bb18083dfad15ba278e59f9e5c958a6623b5adf0374d70e4f5b1fba917dbdaf590b6475d056cdd513124d9e8040eb7bafa138ddc35fa41f69fb76a885a9334a14271c1c4dec527a1ad9d1b2c4125834780ffc1d974eac20ea213cf6be0077606e843c3933dda53044ce7547b89fb1b280d4d87aeee87e759f1c7440f5bb47d3efe600722660de884c6a134fed48d2e8f6a51410b51ff016caed31c869ffdcf568062c7350b013e8c84a29da36eb304bf6951023af4e5f232e704a31dc24c29e840a92750091bf887191885308bf43133738f62b44d56728c12f6c6178b36fa1319074a8eed38e1b70ab27c87bdacd01a7b5a8487689eb919a1a2d0f6772514cb4d74bcf083e8a3c1e3c631b27ed37915f9a9ebd9227578c8d34bcf170a83163e703c2cfa6339c76d892ffc0c61a23bf2bfcc06addcd9497a958ac2291f246bd3fd7c110d88f0c582df7331b1f18a2e4c4c313ea9d9ac0fb46cce3354a99eb8c5a8503c6dff1d569b5c6986de6bd4dac3ada01a736a9f0b49bd162f143f7626e3fe11042d705016ebbaf04d0d9e419e702cd1fe41bc488c7a4575cc31dbf6eea06e82e7411f64842085f1e2654b7b88cfb069470ed1396471e28bc8ee2d749b6c2a632d8a0079d7295392ad6e20ba4160e605298cf7fb4c621ceb9d9d3684eefcb6bbf261fe210748e464e0541f64702c6171479161dc3d2188e09e360683bc39a542ebb4d539491a212713b1b7bb53fa573832f533432449a541c45626ef6b508717b49d74df1f95cd51a6dad194194075b7fb69b56ae801a72e9545174a8f68320a8a206374e78c113f663560ef9be9f1b87d04a4790d3143faa6dad194194075b7fb69b56ae801a72e054104c22053e020bffb2e7862886569,0x82a1e878c5ac69376cb8b60f78d0d878,0x9e0c3309c8fb9a2c9e37ecda3339171b,NULL,0x98921d7f2f14db1696e3ea036f2ffc2d,NULL),(2,0xfd4e0185cda7d53c019816624babc1d1dd47ccec68364ff519c0e9a6850deac378eb4505647f2eaef7e764adf5f44bf7fd4e0185cda7d53c019816624babc1d1fd4e0185cda7d53c019816624babc1d194157727f74fd79d5fdaa1adafca86b9d02bb7d6b512814cb8de26479437c6ad3d0dd0f7b69b0d49445202079c46b3028a01ea867bc19bad2dbb6c2cf9a07942838557fa287e17c961c20ceda1473f0cad329c3d8dc8003567c5a6fe221f6b51925da72adcdc58361d2a6193450df3d16337fc1fccc0e26e5154e5857c8622104c6ae9d0822bf6520ed9576c350ae90264876549b5d5b6cfb2668deaaf3c12b7c6a6aa7eb6fbe13bf15305ea49caf04e2554a7bceb5ea2092cdfa161f7fc6ca871596e89b3cd3dd61d125028011709c091da944eade5bfd24bc68a933afcddc070ed59e3d67e98f792d988a85822047e5f3244f6d97938fc98db6be54774f5651d48df3f84abc0bf2911ef50e2d7e4b1de3e353102da9f75ec2c26d751a5aee740fe40ffe7c4825f015e74377ad5f5657af9d3f617bf3839ea1cec0c5f2bd2b7055efae625d4ee4e5fc9fcd04cdae3e9fa56f99a93ae81159c32f68372decca0c2333f3a59456efee523a7918538ea3d3de96cb8bc1e089e4c4d60f80c9d35818bebb392651af88fd56608f63fc5607cc8bc5afcb3c937c64a462545d618755880d02e00ec0c447b5d87e179ae9d58a4be18c1f1e9e985ad798810eaab4308fc69d76cb14ec9531cdbae6ad6e1f315a706f66244ce825d2e7d76204be414f340d6a13ddbe49098d964056f3ab3c08d9e320f60bd19d13e48b00d74e406206aeadd5f32a811aa3cf5c972aedd336ce27dada9a9f394647a783019068320544568d0ae153e426934769fa3ceed8daafabe33bbc73a9d49232d0162dcfae9426769a98fd5a275d988098f03f73c65f57f66c448176bf9dc3e8afb1117bfd1808c07a19d762348c4c5b6b490cc74f0a643e2d633e08b25f61553a071d8e44f60ed5ac1c23524cddb45a141f8c660aa33af8b5c545a4d1b36eec62287c09abef442316ce7b91955b4b2da278223e2fbb01005357f9e077af440347a59021ad7db0f6684ad123509166f7e87fcd8e3c29d6da398c76e6792f74ba26962fbd2eefafef4ffe940c778807cd0b8b00733fbade0cdc0c12d78f2541dee9b72494982615b86b8614452e524d315aee9b5d0eb03ff9f9cd00cd3cbd9018365bf116b3a21a112ad514aacb6fdd5634e6b74e3ba6235c113626434c8558b183059ab234be932aa3f23bb685f2d357445edb2d2d4bffce907f078119eeef2b81079f3d581a68d75df22caddf5b84b487cba678b16ecedaa082e51002418d75fa61b4444a88e71fa7d63b902187188889fe18894c282433ed896a6add0d661dbd33c3b01f35518067dbf246e5dff22b797a0844da86a5f063b363bfc8420681dfa6aa30064c59c5a94b03652337a9e63b4b3cd8be8477fbed0285344ff60d18eecfdaff4a220fa10f4267e0721f7d40f1417eb8cea3c8cf575669046b07ac64a27b8eb5ade65b97d81b28685a28cc54ad94f09cac09afe32ecff917976a63177071810356af3c217bd4c155b978648f82eb51267959e37ef8106fc4a8a43af035e12c751f3230cd3c3ff8f60edb58ff62bcd73f3b81cafee8c22ab0552a50535f1dbb89a1e5ad9304a8c2ce656bb5d775fa73c894cd7cd478d8f4be1d1d7961464f845cfb598ee9ed7b7d2dfc92bc85ca71c3252a6d5324a6f267d973a08255ea8994829b614e2d2235b2e2058bde34ba6aefd0f6b651fc4fd4e0185cda7d53c019816624babc1d1db020f74f4b0b4b4969a870b0c3901bd181945f57436d65f02aaad7fc42ccc8bfd4e0185cda7d53c019816624babc1d19beca2392b2ba10a544bb1362b5e9e18,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x5b61acf23088a2214d164d7524a6193e,NULL);
/*!40000 ALTER TABLE `servers` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `settings`
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `name` varchar(256) NOT NULL DEFAULT '',
  `address` text,
  `county` varchar(256) NOT NULL DEFAULT '',
  `town` varchar(256) NOT NULL DEFAULT '',
  `phone` varchar(256) NOT NULL DEFAULT '',
  `other_phones` varchar(256) NOT NULL DEFAULT '',
  `email` varchar(256) NOT NULL DEFAULT '',
  `sender_id` varchar(256) NOT NULL DEFAULT '',
  `sms_initial` varchar(256) NOT NULL DEFAULT '',
  `member_code_initial` varchar(256) NOT NULL DEFAULT '',
  `file` varchar(256) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table `settings`
LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,1325624400,'Smart Churches','Box 12548','Nairobi','Umoja','(072) 134-1214','0205285243/07213584587','info@smartchurch.com','M-SHAMBA','Hello','MLC','logo31.png',1,1,1422976879,1437552459);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `sms`
DROP TABLE IF EXISTS `sms`;
CREATE TABLE `sms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient` varchar(32) NOT NULL DEFAULT '',
  `status` int(11) DEFAULT NULL,
  `cost` int(11) DEFAULT NULL,
  `group_type` varchar(50) DEFAULT NULL,
  `sent_to` varchar(50) DEFAULT NULL,
  `message` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=278 DEFAULT CHARSET=utf8;

-- Dumping data for table `sms`
LOCK TABLES `sms` WRITE;
/*!40000 ALTER TABLE `sms` DISABLE KEYS */;
INSERT INTO `sms` VALUES (15,'7',1,4,'B7A312A3A/01/15','church member','We are here now come',1,NULL,1422606500,NULL),(16,'1',1,1,'27699BA64/01/15','all staff','To all Staff members message',1,NULL,1422607171,NULL),(17,'2',1,1,'27699BA64/01/15','all staff','To all Staff members message',1,NULL,1422607171,NULL),(18,'3',1,2,'27699BA64/01/15','all staff','To all Staff members message',1,NULL,1422607171,NULL),(19,'2',1,1,'56B96A364/01/15','staff member','This is your SMS',1,NULL,1422608445,NULL),(20,'24',1,2,'5732A6698/01/15','ministry','This is for ministries only',1,NULL,1422613877,NULL),(21,'23',1,2,'5732A6698/01/15','ministry','This is for ministries only',1,NULL,1422613878,NULL),(22,'22',1,2,'5732A6698/01/15','ministry','This is for ministries only',1,NULL,1422613878,NULL),(23,'5',1,2,'6B539787A/01/15','hbc','This was sent to All hbc members',1,NULL,1422618247,NULL),(24,'16',1,1,'6B539787A/01/15','hbc','This was sent to All hbc members',1,NULL,1422618247,NULL),(25,'19',1,1,'6B539787A/01/15','hbc','This was sent to All hbc members',1,NULL,1422618247,NULL),(26,'24',1,1,'6B539787A/01/15','hbc','This was sent to All hbc members',1,NULL,1422618247,NULL),(33,'5',1,1,'9468472B7/01/15','multiple members','This is your message',1,NULL,1422693951,NULL),(34,'6',1,1,'9468472B7/01/15','multiple members','This is your message',1,NULL,1422693951,NULL),(35,'7',1,1,'9468472B7/01/15','multiple members','This is your message',1,NULL,1422693952,NULL),(36,'16',1,1,'9468472B7/01/15','multiple members','This is your message',1,NULL,1422693952,NULL),(37,'17',1,1,'9468472B7/01/15','multiple members','This is your message',1,NULL,1422693952,NULL),(38,'18',1,1,'9468472B7/01/15','multiple members','This is your message',1,NULL,1422693952,NULL),(39,'19',1,1,'9468472B7/01/15','multiple members','This is your message',1,NULL,1422693952,NULL),(40,'20',1,1,'9468472B7/01/15','multiple members','This is your message',1,NULL,1422693953,NULL),(41,'21',1,3,'9468472B7/01/15','multiple members','This is your message',1,NULL,1422693953,NULL),(42,'22',1,3,'9468472B7/01/15','multiple members','This is your message',1,NULL,1422693953,NULL),(43,'23',1,3,'9468472B7/01/15','multiple members','This is your message',1,NULL,1422693953,NULL),(44,'24',1,3,'9468472B7/01/15','multiple members','This is your message',1,NULL,1422693953,NULL),(45,'5',1,2,'831128826/01/15','multiple members','This your mesaage sir',1,NULL,1422712974,NULL),(46,'6',1,1,'831128826/01/15','multiple members','This your mesaage sir',1,NULL,1422712974,NULL),(47,'16',1,2,'831128826/01/15','multiple members','This your mesaage sir',1,NULL,1422712974,NULL),(48,'17',1,1,'831128826/01/15','multiple members','This your mesaage sir',1,NULL,1422712974,NULL),(49,'7',1,1,'17167BABB/01/15','church member','We need you here sir',1,NULL,1422713626,NULL),(63,'5',1,1,'63A4B7861/02/15','all members','We shall be having meeting next week please come',1,NULL,1422883208,NULL),(64,'6',1,1,'63A4B7861/02/15','all members','We shall be having meeting next week please come',1,NULL,1422883208,NULL),(65,'7',1,1,'63A4B7861/02/15','all members','We shall be having meeting next week please come',1,NULL,1422883208,NULL),(66,'16',1,2,'63A4B7861/02/15','all members','We shall be having meeting next week please come',1,NULL,1422883208,NULL),(67,'17',1,3,'63A4B7861/02/15','all members','We shall be having meeting next week please come',1,NULL,1422883208,NULL),(68,'18',1,1,'63A4B7861/02/15','all members','We shall be having meeting next week please come',1,NULL,1422883208,NULL),(69,'19',1,2,'63A4B7861/02/15','all members','We shall be having meeting next week please come',1,NULL,1422883208,NULL),(70,'20',1,1,'63A4B7861/02/15','all members','We shall be having meeting next week please come',1,NULL,1422883208,NULL),(71,'21',1,1,'63A4B7861/02/15','all members','We shall be having meeting next week please come',1,NULL,1422883208,NULL),(72,'22',1,2,'63A4B7861/02/15','all members','We shall be having meeting next week please come',1,NULL,1422883208,NULL),(73,'23',1,1,'63A4B7861/02/15','all members','We shall be having meeting next week please come',1,NULL,1422883208,NULL),(74,'24',1,2,'63A4B7861/02/15','all members','We shall be having meeting next week please come',1,NULL,1422883208,NULL),(75,'5',1,2,'888484744/02/15','all members','We are here',1,NULL,1422887816,NULL),(76,'6',1,1,'888484744/02/15','all members','We are here',1,NULL,1422887816,NULL),(77,'7',1,3,'888484744/02/15','all members','We are here',1,NULL,1422887816,NULL),(78,'16',1,1,'888484744/02/15','all members','We are here',1,NULL,1422887816,NULL),(79,'17',1,2,'888484744/02/15','all members','We are here',1,NULL,1422887816,NULL),(80,'18',1,1,'888484744/02/15','all members','We are here',1,NULL,1422887816,NULL),(81,'19',1,3,'888484744/02/15','all members','We are here',1,NULL,1422887816,NULL),(82,'20',1,1,'888484744/02/15','all members','We are here',1,NULL,1422887816,NULL),(83,'21',1,2,'888484744/02/15','all members','We are here',1,NULL,1422887816,NULL),(84,'22',1,1,'888484744/02/15','all members','We are here',1,NULL,1422887816,NULL),(85,'23',1,2,'888484744/02/15','all members','We are here',1,NULL,1422887816,NULL),(86,'24',1,1,'888484744/02/15','all members','We are here',1,NULL,1422887816,NULL),(87,'25',1,3,'8872B4532/02/15','church member','Hi David, we thank you for choosing to become a member of Miracleland. Your membership code is MLC-0025',1,NULL,1422891426,NULL),(88,'6',1,1,'7B4559718/02/15','church member','Hi Lidia, we thank you for visiting our sanctuary. Be blessed and welcome all the times',1,NULL,1422893451,NULL),(105,'22',1,1,'55173114A/02/15','church member','Hi Mlofa, Confirmed your Tithe 5,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1422959055,NULL),(106,'22',1,3,'698138219/02/15','church member','Hi Mlofa, Confirmed your Thanks Giving 2,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1422959214,NULL),(107,'25',1,1,'53811AA81/02/15','church member','Hi David, Confirmed your Thanks Giving 6,500 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1422959215,NULL),(108,'22',1,1,'532995292/02/15','church member','Hi Mlofa, Confirmed your Ministry Support of 1,500 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1422959313,NULL),(109,'25',1,2,'459274B58/02/15','church member','Hi David, Confirmed your Ministry Support of 2,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1422959313,NULL),(110,'7',1,1,'8166B7A18/02/15','church member','Hi Vandax, Confirmed your Seed of 1,500 has been received. May you be blessed',1,NULL,1422959687,NULL),(111,'21',1,2,'762966A16/02/15','church member','Hi Calvince, Confirmed your Seed of 1,500 has been received. May you be blessed',1,NULL,1422959687,NULL),(112,'22',1,1,'91B7BBA41/02/15','church member','Hi Mlofa, Confirmed your Tithe 2,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1423119025,NULL),(113,'23',1,1,'717964B45/02/15','church member','Hi Admin, Confirmed your Tithe 5,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1423119025,NULL),(114,'24',1,1,'92B48B437/02/15','church member','Hi Lucy, Confirmed your Tithe 2,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1423119025,NULL),(115,'20',1,1,'69A36214A/02/15','church member','Hi Meshack, Confirmed your Tithe 6,500 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1423119025,NULL),(116,'6',1,1,'5B94316BB/02/15','church member','Hi Lukas, Confirmed your Tithe 1,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1423119025,NULL),(117,'17',1,1,'7A67344A3/02/15','church member','Hi Alois, Confirmed your Thanks Giving 5,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1423121640,NULL),(118,'25',1,1,'7B8884B57/02/15','church member','Hi David, Confirmed your Thanks Giving 6,500 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1423121640,NULL),(119,'24',1,2,'3AA256392/02/15','church member','Hi Lucy, Confirmed your Thanks Giving 2,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1423121640,NULL),(120,'6',1,3,'7A2516185/02/15','church member','Hi Lukas, Confirmed your Pledge 2,000 has been received. Balance is 1,000. We thank you for supporting ministry may you be blessed',1,NULL,1423122048,NULL),(121,'22',1,1,'687431364/02/15','church member','Hi Mlofa, Confirmed your Seed of 5,000 has been received. May you be blessed',1,NULL,1423122215,NULL),(126,'5',1,2,'6B5155A26/02/15','church member','This is the message',1,NULL,1423339502,NULL),(127,'5',1,1,'69B6A9928/02/15','church member','This is the message',1,NULL,1423339520,NULL),(132,'7',1,2,'6873A3357/02/15','church member','the is the message',1,NULL,1423343875,NULL),(133,'5',1,1,'6873A3357/02/15','church member','the is the message',1,NULL,1423343875,NULL),(134,'24',1,1,'6873A3357/02/15','church member','the is the message',1,NULL,1423343875,NULL),(135,'21',1,1,'6873A3357/02/15','church member','the is the message',1,NULL,1423343875,NULL),(136,'26',1,1,'94A77B391/02/15','church member','Hi Ruth, we thank you for choosing to become a member of our church. Your membership code is MLC-0026',1,NULL,1424677671,NULL),(137,'27',1,1,'1122A16B1/02/15','church member','Hi Major, we thank you for choosing to become a member of our church. Your Membership Code is -027',1,NULL,1424680362,NULL),(138,'28',1,2,'463B13743/02/15','church member','Hi Blender, we thank you for choosing to become a member of our church. Your Membership Code is MLC-028',1,NULL,1424680643,NULL),(139,'5',1,3,'5B794B786/02/15','church member','Hello there, we thank you for choosing to become a member of our church. Your Membership Code is MLC-028',1,NULL,1424702383,NULL),(141,'28',1,2,'B494627BA/02/15','group','There will be a meeting next week kindly avail yourselves',1,NULL,1424778574,NULL),(142,'28',1,2,'36828A133/02/15','group','There will be a meeting next week kindly avail yourselves',1,NULL,1424778594,NULL),(143,'29',1,2,'2AB7478BA/03/15','church member','Hi Boniface, we thank you for choosing to become a member of our church. Your Membership Code is MLC-029',1,NULL,1426152587,NULL),(144,'27',1,NULL,'251BA2813/03/15','church member','Hi ',1,NULL,1426595364,NULL),(145,'26',1,NULL,'71B717578/03/15','church member','Hi \\t',1,NULL,1426595365,NULL),(146,'25',1,NULL,'947B49262/03/15','church member','Hi ',1,NULL,1426595366,NULL),(147,'25',1,NULL,'118215346/03/15','church member','Hi ',1,NULL,1426595367,NULL),(148,'27',1,NULL,'721B36991/03/15','church member','Hi ',1,NULL,1426595539,NULL),(149,'26',1,NULL,'486945529/03/15','church member','Hi \\t',1,NULL,1426595539,NULL),(150,'27',1,NULL,'8472B7838/03/15','church member','Hi ',1,NULL,1426595655,NULL),(151,'29',1,NULL,'7B8251588/03/15','church member','Hi \"|',1,NULL,1426595655,NULL),(152,'27',1,NULL,'3158449B6/03/15','church member','Hi ',1,NULL,1426595676,NULL),(153,'27',1,NULL,'369914348/03/15','church member','Hi ',1,NULL,1426595706,NULL),(154,'27',1,NULL,'31343A215/03/15','church member','Hi ',1,NULL,1426595773,NULL),(155,'29',1,NULL,'41AB3661A/05/15','church member','Hi Boniface, Confirmed your Tithe 5,200 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1431670727,NULL),(156,'30',1,NULL,'256AB4911/05/15','church member','Hi , we thank you for choosing to become a member of our church. Your Membership Code is -030 Username:  Password: KLVqa',NULL,NULL,1431843961,NULL),(157,'29',1,NULL,'87752A224/05/15','church member','Hi Boniface, Confirmed your Tithe 2,500 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432009622,NULL),(158,'5',1,NULL,'447B23868/05/15','church member','Hi Brender, Confirmed your Tithe 1,250 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432009728,NULL),(159,'6',1,NULL,'757245545/05/15','church member','Hi Don, Confirmed your Tithe 4,500 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432009728,NULL),(160,'7',1,NULL,'69AA6B195/05/15','church member','Hi Linda, Confirmed your Tithe 5,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432009728,NULL),(161,'18',1,NULL,'5534A964A/05/15','church member','Hi Rhoda, Confirmed your Tithe 18,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432009728,NULL),(162,'17',1,NULL,'9B1936535/05/15','church member','Hi Joseph, Confirmed your Tithe 4,580 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432009729,NULL),(163,'19',1,NULL,'357762B59/05/15','church member','Hi Winter, Confirmed your Tithe 8,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432009729,NULL),(164,'22',1,NULL,'B69956A47/05/15','church member','Hi Steve, Confirmed your Tithe 45 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432009729,NULL),(165,'29',1,NULL,'51B47887B/05/15','church member','Hi Boniface, Confirmed your Thanks Giving 45,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432009806,NULL),(166,'6',1,NULL,'957251BA2/05/15','church member','Hi Don, Confirmed your Thanks Giving 2,500 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432009806,NULL),(167,'29',1,NULL,'56BBA3844/05/15','church member','Hi Boniface, Confirmed your Ministry Support of 4,700 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432009847,NULL),(168,'6',1,NULL,'9962B86A6/05/15','church member','Hi Don, Confirmed your Ministry Support of 2,500 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432009847,NULL),(169,'16',1,NULL,'4A8822681/05/15','church member','Hi Kevin, Confirmed your Thanks Giving 5,800 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432009912,NULL),(170,'29',1,NULL,'863762B7A/05/15','church member','Hi Boniface, Confirmed your Thanks Giving 56,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432009912,NULL),(171,'29',1,NULL,'946765567/05/15','church member','Hi Boniface, Confirmed your Thanks Giving 22,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432009965,NULL),(172,'19',1,NULL,'B72927B38/05/15','church member','Hi Winter, Confirmed your Thanks Giving 12,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432009965,NULL),(173,'17',1,NULL,'47BA42443/05/15','church member','Hi Joseph, Confirmed your Thanks Giving 5,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432009965,NULL),(174,'6',1,NULL,'67AA15577/05/15','church member','Hi Don, Confirmed your Thanks Giving 25,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432009965,NULL),(175,'5',1,NULL,'96A369475/05/15','church member','Hi Brender, Confirmed your Ministry Support of 45,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432010006,NULL),(176,'29',1,NULL,'3A16B9439/05/15','church member','Hi Boniface, Confirmed your Ministry Support of 25,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432010006,NULL),(177,'29',1,NULL,'1622293A2/05/15','church member','Hi Boniface, Confirmed your Ministry Support of 18,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432010048,NULL),(178,'18',1,NULL,'B11124499/05/15','church member','Hi Rhoda, Confirmed your Ministry Support of 15,800 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432010048,NULL),(179,'20',1,NULL,'67A627B5A/05/15','church member','Hi Mecy, Confirmed your Ministry Support of 12,500 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432010049,NULL),(180,'29',1,NULL,'9AB866995/05/15','church member','Hi Boniface, Confirmed your Ministry Support of 48,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432010092,NULL),(181,'18',1,NULL,'AA54B5572/05/15','church member','Hi Rhoda, Confirmed your Ministry Support of 12,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1432010092,NULL),(182,'29',1,NULL,'6617B7B63/05/15','church member','Hi Boniface, Confirmed your Seed of 65,000 has been received. May you be blessed',1,NULL,1432010164,NULL),(183,'18',1,NULL,'27586877A/05/15','church member','Hi Rhoda, Confirmed your Seed of 22,000 has been received. May you be blessed',1,NULL,1432010165,NULL),(184,'19',1,NULL,'4344B5476/05/15','church member','Hi Winter, Confirmed your Seed of 14,000 has been received. May you be blessed',1,NULL,1432010165,NULL),(185,'29',1,NULL,'78B672867/05/15','church member','Hi Boniface, Confirmed your Confirmation of 55,000 has been received.We thank you for supporting ministry may you be blessed',1,NULL,1432010209,NULL),(186,'18',1,NULL,'143589917/05/15','church member','Hi Rhoda, Confirmed your Confirmation of 10,500 has been received.We thank you for supporting ministry may you be blessed',1,NULL,1432010209,NULL),(187,'17',1,NULL,'69A36214A/05/15','church member','Hi Joseph, Confirmed your Confirmation of 12,500 has been received.We thank you for supporting ministry may you be blessed',1,NULL,1432010209,NULL),(188,'29',1,NULL,'71B787372/05/15','church member','Hi Boniface, Confirmed your Baptism of 15,000 has been received.We thank you for supporting ministry may you be blessed',1,NULL,1432010259,NULL),(189,'19',1,NULL,'3B2214B95/05/15','church member','Hi Winter, Confirmed your Baptism of 12,000 has been received.We thank you for supporting ministry may you be blessed',1,NULL,1432010259,NULL),(190,'19',1,NULL,'5B3254928/05/15','church member','Hi Winter, Confirmed your Baptism of 14,500 has been received.We thank you for supporting ministry may you be blessed',1,NULL,1432010259,NULL),(191,'29',1,NULL,'A827BB8B8/05/15','church member','Hi Boniface, Confirmed your Christmas Gift of 12,500 has been received.We thank you for supporting ministry may you be blessed',1,NULL,1432010321,NULL),(192,'18',1,NULL,'32B541859/05/15','church member','Hi Rhoda, Confirmed your Christmas Gift of 45,000 has been received.We thank you for supporting ministry may you be blessed',1,NULL,1432010321,NULL),(193,'19',1,NULL,'875378372/05/15','church member','Hi Winter, Confirmed your Christmas Gift of 4,500 has been received.We thank you for supporting ministry may you be blessed',1,NULL,1432010321,NULL),(194,'29',1,NULL,'767142146/05/15','church member','Hi Boniface, Confirmed your Seed of 45,000 has been received. May you be blessed',1,NULL,1432010626,NULL),(195,'18',1,NULL,'1AA45A93A/05/15','church member','Hi Rhoda, Confirmed your Seed of 12,000 has been received. May you be blessed',1,NULL,1432010626,NULL),(196,'29',1,NULL,'7B6246313/05/15','church member','Hi Boniface, Confirmed your Pledge 7,500 has been received. We thank you for supporting  ministry may you be blessed',1,NULL,1432648632,NULL),(197,'5',1,NULL,'34AB472A5/06/15','church member','Hi Brender, Confirmed your Tithe 8,500 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1433678888,NULL),(198,'18',1,NULL,'7B3ABBA75/06/15','church member','Hi Rhoda, Confirmed your Tithe 4,500 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1433678888,NULL),(199,'16',1,NULL,'13261485B/06/15','church member','Hi Kevin, Confirmed your Tithe 25,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1433678888,NULL),(200,'20',1,NULL,'56A58675A/06/15','church member','Hi Mecy, Confirmed your Tithe 45,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1433678889,NULL),(201,'17',1,NULL,'5A12A13B9/06/15','church member','Hi Joseph, Confirmed your Tithe 22,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1433678889,NULL),(202,'6',1,NULL,'33B6B5134/06/15','church member','Hi Don, Confirmed your Tithe 45,800 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1433678958,NULL),(203,'19',1,NULL,'3A95536B1/06/15','church member','Hi Winter, Confirmed your Tithe 78,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1433678958,NULL),(204,'19',1,NULL,'47AA37189/06/15','church member','Hi Winter, Confirmed your Tithe 15,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1433678958,NULL),(205,'7',1,NULL,'887816442/06/15','church member','Hi Linda, Confirmed your Tithe 45,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1433678996,NULL),(206,'20',1,NULL,'5AB976B5A/06/15','church member','Hi Mecy, Confirmed your Tithe 25,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1433678996,NULL),(207,'7',1,NULL,'23316213B/06/15','church member','Hi Linda, Confirmed your Tithe 47,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1433679030,NULL),(208,'18',1,NULL,'193B67337/06/15','church member','Hi Rhoda, Confirmed your Tithe 55,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1433679030,NULL),(209,'6',1,NULL,'61552B159/06/15','church member','Hi Don, Confirmed your Thanks Giving 45,800 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1433679148,NULL),(210,'19',1,NULL,'574325345/06/15','church member','Hi Winter, Confirmed your Thanks Giving 67,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1433679148,NULL),(211,'6',1,NULL,'76B4B9481/06/15','church member','Hi Don, Confirmed your Thanks Giving 78,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1433679258,NULL),(212,'5',1,NULL,'5A1B168B2/06/15','church member','Hi Brender, Confirmed your Ministry Support of 98,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1433679291,NULL),(213,'17',1,NULL,'5B8887946/06/15','church member','Hi Joseph, Confirmed your Seed of 68,000 has been received. May you be blessed',1,NULL,1433679329,NULL),(214,'29',1,NULL,'653BB6231/06/15','church member','Hi Boniface, Confirmed your Tithe 8,500 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1433681934,NULL),(215,'17',1,NULL,'2B7955478/06/15','church member','Hi Joseph, Confirmed your Tithe 45,888 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1433681935,NULL),(216,'29',1,NULL,'9A438262B/07/15','church member','Hi Boniface, Confirmed your Tithe 78,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1436444818,NULL),(217,'29',1,NULL,'A14ABBAB9/07/15','church member','Hi Boniface, Confirmed your Tithe 5,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1437549709,NULL),(218,'29',1,NULL,'6161B69B9/07/15','multiple members','test sms',1,NULL,1437551553,NULL),(219,'29',1,NULL,'A962368B2/07/15','church member','Hi Boniface, Confirmed your Tithe 5,200 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1437573721,NULL),(220,'29',1,NULL,'3583BB891/07/15','church member','Hi Boniface, Confirmed your Tithe 4,500 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1437574056,NULL),(221,'29',1,NULL,'A213547A3/07/15','church member','Hi Boniface, Confirmed your Tithe 4,500 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1437574145,NULL),(222,'29',1,NULL,'A716817B2/07/15','church member','Hi Boniface, Confirmed your Tithe 5,200 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1437574297,NULL),(223,'29',1,NULL,'B7AAA3A63/07/15','church member','Hi Boniface, Confirmed your Tithe 5,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1437576201,NULL),(224,'29',1,NULL,'732A66988/07/15','church member','Hi Boniface, Confirmed your Tithe 15,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1437577207,NULL),(225,'29',1,NULL,'428145B78/07/15','church member','Hi Boniface, Confirmed your Tithe 4,500 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1437635274,NULL),(226,'29',1,NULL,'183A746A1/07/15','multiple members','This is your message',1,NULL,1437638089,NULL),(227,'29',1,NULL,'B96159A87/07/15','church member','Hello Boniface, Confirmed your Tithe 15,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1437638321,NULL),(228,'29',1,NULL,'55136A18B/07/15','church member','Hi Boniface, Confirmed your Ministry Support of 58,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1438065234,NULL),(229,'29',1,NULL,'1116674A6/07/15','church member','Hello Boniface, Confirmed your Confirmation of 78,000 has been received.We thank you for supporting ministry may you be blessed',1,NULL,1438065552,NULL),(230,'29',1,NULL,'399611188/07/15','church member','Hello Boniface, Confirmed your Thanks Giving 55,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1438065609,NULL),(231,'29',1,NULL,'93BA92348/11/15','church member','Hello Boniface, Confirmed your Tithe 78,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1447151662,NULL),(232,'29',1,NULL,'6AB4B18A3/11/15','church member','Hello Boniface, Confirmed your Tithe 12,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1447151701,NULL),(233,'29',1,NULL,'37B2454A8/11/15','church member','Hello Boniface, Confirmed your Thanks Giving 5,200 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1447151726,NULL),(234,'29',1,NULL,'9588AA836/11/15','church member','Hi Boniface, Confirmed your Ministry Support of 12,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1447151754,NULL),(235,'29',1,NULL,'4B4B92A99/11/15','multiple members','This is your messsage',1,NULL,1447151801,NULL),(236,'29',1,NULL,'491284A4B/11/15','church member','Hello Boniface, Confirmed your Tithe 5,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1447159639,NULL),(237,'29',1,NULL,'A9B926397/11/15','multiple members','REST',1,NULL,1447159904,NULL),(238,'29',1,NULL,'186464879/11/15','church member','Hello Boniface, Confirmed your Tithe 5,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1448520635,NULL),(239,'29',1,NULL,'727262572/12/15','church member','This is your message',1,NULL,1448979569,NULL),(240,'29',1,NULL,'7A59978A5/12/15','church member','Hello Boniface, Confirmed your Tithe 8,500 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1448979626,NULL),(241,'29',1,NULL,'917836312/12/15','church member','the message',1,NULL,1448985343,NULL),(242,'5',1,NULL,'A78B746B5/04/16','multiple members','test SMS',1,NULL,1461066610,NULL),(243,'5',1,NULL,'673597394/04/16','church member','Hello Brender, Confirmed your Tithe 5,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1461075240,NULL),(244,'6',1,NULL,'6683649A3/04/16','church member','Hello Don, Confirmed your Tithe 4,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1461075241,NULL),(245,'18',1,NULL,'41A8AA921/04/16','church member','Hello Rhoda, Confirmed your Tithe 11,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1461075241,NULL),(246,'7',1,NULL,'31BB18B5B/04/16','church member','Hello Linda, Confirmed your Tithe 8,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1461075241,NULL),(247,'7',1,NULL,'98A87A722/04/16','church member','Hello Linda, Confirmed your Thanks Giving 50,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1461075322,NULL),(248,'6',1,NULL,'97486A825/04/16','church member','Hello Don, Confirmed your Thanks Giving 8,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1461075323,NULL),(249,'5',1,NULL,'761744169/04/16','church member','Hi Brender, Confirmed your Ministry Support of 40,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1461075364,NULL),(250,'19',1,NULL,'661335AA4/04/16','church member','Hi Winter, Confirmed your Ministry Support of 11,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1461075364,NULL),(251,'6',1,NULL,'A625217BA/04/16','church member','Hello Don, Confirmed your Seed of 11,000 has been received. May you be blessed',1,NULL,1461075402,NULL),(252,'28',1,NULL,'9874A7477/04/16','church member','Hello Brender, Confirmed your Seed of 25,000 has been received. May you be blessed',1,NULL,1461075403,NULL),(253,'5',1,NULL,'5954727BA/04/16','church member','Hello Brender, Confirmed your Baptism of 5,000 has been received.We thank you for supporting ministry may you be blessed',1,NULL,1461075448,NULL),(254,'6',1,NULL,'6B7686739/04/16','church member','Hello Don, Confirmed your Baptism of 11,000 has been received.We thank you for supporting ministry may you be blessed',1,NULL,1461075449,NULL),(255,'18',1,NULL,'19A39829B/04/16','church member','Hello Rhoda, Confirmed your Baptism of 5,000 has been received.We thank you for supporting ministry may you be blessed',1,NULL,1461075449,NULL),(256,'5',1,NULL,'991485379/04/16','church member','Hi Church Smart, Confirmed your Donation has been received. We thank you for supporting ministry may you be blessed',1,NULL,1461075583,NULL),(257,'6',1,NULL,'71357343A/04/16','church member','Hello Don, Confirmed your Tithe 5,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1461076990,NULL),(258,'18',1,NULL,'9554A912B/04/16','church member','Hello Rhoda, Confirmed your Tithe 8,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1461076990,NULL),(259,'18',1,NULL,'859291915/04/16','church member','Hello Rhoda, Confirmed your Tithe 60,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1461076990,NULL),(260,'17',1,NULL,'29BABBB57/04/16','church member','Hello Joseph, Confirmed your Tithe 22,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1461077014,NULL),(261,'17',1,NULL,'255726689/04/16','church member','Hello Joseph, Confirmed your Thanks Giving 45,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1461077042,NULL),(262,'18',1,NULL,'516787296/04/16','church member','Hi Rhoda, Confirmed your Ministry Support of 39,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1461077069,NULL),(263,'7',1,NULL,'1B16A1229/04/16','church member','Hello Linda, Confirmed your Seed of 48,000 has been received. May you be blessed',1,NULL,1461077112,NULL),(264,'6',1,NULL,'658464565/04/16','church member','Hello Don, Confirmed your Pastor Appreciation of 55,000 has been received.We thank you for supporting ministry may you be blessed',1,NULL,1461077141,NULL),(265,'7',1,NULL,'393397498/04/16','church member','Hello Linda, Confirmed your Tithe 43,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1461077261,NULL),(266,'18',1,NULL,'549288995/04/16','church member','Hello Rhoda, Confirmed your Seed of 38,000 has been received. May you be blessed',1,NULL,1461077307,NULL),(267,'16',1,NULL,'59B1AB1A1/04/16','church member','Hello Kevin, Confirmed your Thanks Giving 44,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1461077388,NULL),(268,'31',1,NULL,'1B461AB3A/04/16','church member','Hi Fredrick, we thank you for choosing to become a member of our church. Your Membership Code is MLC-031',1,NULL,1461077796,NULL),(269,'31',1,NULL,'A99328452/04/16','church member','Hello Fredrick, Confirmed your Tithe 71,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1461137499,NULL),(270,'6',1,NULL,'147B371B7/07/16','church member','Hello Don, Confirmed your Window of 1,000 has been received.We thank you for supporting ministry may you be blessed',1,NULL,1468847516,NULL),(271,'6',1,NULL,'973438674/07/16','multiple members','Test SMS',1,NULL,1468847802,NULL),(272,'6',1,NULL,'7366A4181/07/16','multiple members','Test SMS',1,NULL,1468847877,NULL),(273,'6',1,NULL,'B2343819A/07/16','church member','Hello Don, Confirmed your Tithe 5,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1468848060,NULL),(274,'33',1,NULL,'676112A4B/09/16','church member','Hi Jacktone, we thank you for choosing to become a member of our church. Your Membership Code is MLC-033',1,NULL,1475049402,NULL),(275,'33',1,NULL,'573B92195/09/16','church member','Hello Jacktone, Confirmed your Tithe 5,000 has been received. We thank you for supporting ministry may you be blessed',1,NULL,1475049601,NULL),(276,'5',1,NULL,'9A8886981/09/16','church visitor','Hi Joe, we thank you for visiting our sanctuary. Be blessed and welcome all the times',1,NULL,1475049870,NULL),(277,'33',1,NULL,'8A12976B8/09/16','church member','test',1,NULL,1475050321,NULL);
/*!40000 ALTER TABLE `sms` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `sms_counter`
DROP TABLE IF EXISTS `sms_counter`;
CREATE TABLE `sms_counter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` blob,
  `balance` blob,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table `sms_counter`
LOCK TABLES `sms_counter` WRITE;
/*!40000 ALTER TABLE `sms_counter` DISABLE KEYS */;
INSERT INTO `sms_counter` VALUES (1,'',0x5bfcee4ee6d3f77595584de16e221aac,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343231323432353139,0x67c2201d225090f3c9a454f1e19adf2e);
/*!40000 ALTER TABLE `sms_counter` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `sms_subscriptions`
DROP TABLE IF EXISTS `sms_subscriptions`;
CREATE TABLE `sms_subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member` varchar(32) NOT NULL DEFAULT '',
  `bible_quotes` varchar(32) NOT NULL DEFAULT '',
  `daily_inspirations` varchar(32) NOT NULL DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Dumping data for table `sms_subscriptions`
LOCK TABLES `sms_subscriptions` WRITE;
/*!40000 ALTER TABLE `sms_subscriptions` DISABLE KEYS */;
INSERT INTO `sms_subscriptions` VALUES (1,'7','0','1',1,1,NULL,1423290445,NULL),(2,'5','1','1',1,1,1,1423293834,1423333456),(3,'24','0','1',1,1,NULL,1423294105,NULL),(4,'22','1','0',1,1,NULL,1423294105,NULL),(5,'21','0','1',1,1,1,1423294105,1423333441);
/*!40000 ALTER TABLE `sms_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `ss_parents`
DROP TABLE IF EXISTS `ss_parents`;
CREATE TABLE `ss_parents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `child_id` int(11) NOT NULL DEFAULT '0',
  `first_name` varchar(256) NOT NULL DEFAULT '',
  `last_name` varchar(256) NOT NULL DEFAULT '',
  `gender` varchar(256) NOT NULL DEFAULT '',
  `relationship` varchar(256) NOT NULL DEFAULT '',
  `phone1` varchar(256) NOT NULL DEFAULT '',
  `phone2` varchar(256) NOT NULL DEFAULT '',
  `email` varchar(256) NOT NULL DEFAULT '',
  `address` text,
  `county` varchar(256) NOT NULL DEFAULT '',
  `location` varchar(256) NOT NULL DEFAULT '',
  `additionals` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Dumping data for table `ss_parents`
LOCK TABLES `ss_parents` WRITE;
/*!40000 ALTER TABLE `ss_parents` DISABLE KEYS */;
INSERT INTO `ss_parents` VALUES (2,3,'Nicky','Munga','Female','mother','(075) 211-4588','','nic@nic.com','Box 1254877','Baringo','Buru','',1,1,1421076469,1421158965),(4,6,'Beautrice','Nyangueso','Female','mother','(072) 134-1214','','nyash@gmail.com','Box 4558','Embu','Kasarani','No additions',1,NULL,1423039097,NULL);
/*!40000 ALTER TABLE `ss_parents` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `sunday_school`
DROP TABLE IF EXISTS `sunday_school`;
CREATE TABLE `sunday_school` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_joined` int(11) DEFAULT NULL,
  `first_name` varchar(256) NOT NULL DEFAULT '',
  `last_name` varchar(256) NOT NULL DEFAULT '',
  `dob` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `gender` varchar(256) NOT NULL,
  `relationship` varchar(256) NOT NULL,
  `home_phone` varchar(256) NOT NULL,
  `baptised` varchar(256) NOT NULL,
  `confirmed` varchar(256) NOT NULL,
  `how_joined` varchar(256) NOT NULL,
  `residential` varchar(256) NOT NULL,
  `special_interest` text,
  `strengths` text,
  `weaknesses` text,
  `health` text,
  `passport` varchar(256) NOT NULL DEFAULT '',
  `additionals` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Dumping data for table `sunday_school`
LOCK TABLES `sunday_school` WRITE;
/*!40000 ALTER TABLE `sunday_school` DISABLE KEYS */;
INSERT INTO `sunday_school` VALUES (1,1421182800,'Joshua','Mwakazi',1421787600,6,1,'Female','','(072) 134-1214','no','no','others','Umoja','Hockey, Drama','Singing, laughing','Eating, running','Headache always','boy6.jpg','',1,1,1421072551,1423038657),(2,1421182800,'Meshack','Rudoff',1422306000,7,1,'Female','','','','','','','Nothing here','Nothing here','Nothing here','Nothing here','','Nothing here',1,NULL,1421076328,NULL),(3,1421787600,'Lindaa','Nyagothii',1420405200,0,0,'Female','','','','','','','Nothing here','Nothing here','Nothing here','Nothing here','','Nothing here',1,NULL,1421076469,NULL),(5,1422738000,'Jeff','Malova',1207688400,16,1,'Male','father','(072) 134-1214','yes','no','others','Donholm','Hockey and other games','Reading, public speaking','Social','Diabet','','A good boy',1,1,1423034804,1423038087),(6,1424206800,'Maurine','Nyangueso',1309294800,0,0,'Female','mother','(072) 134-1214','yes','yes','baptised','Kaloleni','Gaming, Learning','Eating, idling, laughing','smiling, chating, running','No health record','logo2.jpg','A good girl',1,1,1423039097,1423040450);
/*!40000 ALTER TABLE `sunday_school` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `take_stock`
DROP TABLE IF EXISTS `take_stock`;
CREATE TABLE `take_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) DEFAULT NULL,
  `asset_name` varchar(32) NOT NULL DEFAULT '',
  `remaining_stock` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Dumping data for table `take_stock`
LOCK TABLES `take_stock` WRITE;
/*!40000 ALTER TABLE `take_stock` DISABLE KEYS */;
INSERT INTO `take_stock` VALUES (1,1423515600,'2','1','Only One rem',1,NULL,1423403480,NULL),(2,1426194000,'7','6','Damaged',1,NULL,1426262174,NULL);
/*!40000 ALTER TABLE `take_stock` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `task_manager`
DROP TABLE IF EXISTS `task_manager`;
CREATE TABLE `task_manager` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL DEFAULT '',
  `date` int(11) DEFAULT NULL,
  `status` varchar(32) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Dumping data for table `task_manager`
LOCK TABLES `task_manager` WRITE;
/*!40000 ALTER TABLE `task_manager` DISABLE KEYS */;
INSERT INTO `task_manager` VALUES (1,'Collecting offerings',1424120400,'Ongoing','To collect offerings',1,NULL,1423807625,NULL),(2,'To Bank Cash',1424811600,'Completed','Cash Banking',1,NULL,1423807651,NULL),(3,'Send SMS to all members',1423947600,'Cancelled','Send SMS',1,NULL,1423807674,NULL),(4,'Alert HBC on Event',1423515600,'Stalled','Alert HBCs',1,1,1423807698,1423807723),(5,'Sending SMS to members',1424898000,'Ongoing','Sending SMS to members',1,NULL,1424792105,NULL),(6,'Collecting Tithes',1448485200,'Ongoing','This will be tithe collection',1,NULL,1448521213,NULL);
/*!40000 ALTER TABLE `task_manager` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `tax_config`
DROP TABLE IF EXISTS `tax_config`;
CREATE TABLE `tax_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL DEFAULT '',
  `amount` varchar(256) NOT NULL DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Dumping data for table `tax_config`
LOCK TABLES `tax_config` WRITE;
/*!40000 ALTER TABLE `tax_config` DISABLE KEYS */;
INSERT INTO `tax_config` VALUES (1,'PAYE','16',1,NULL,1422346949,NULL),(2,'VAT','16',1,NULL,1422346949,NULL);
/*!40000 ALTER TABLE `tax_config` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `thanks_giving`
DROP TABLE IF EXISTS `thanks_giving`;
CREATE TABLE `thanks_giving` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` blob,
  `member` blob NOT NULL,
  `amount` blob NOT NULL,
  `bank` blob NOT NULL,
  `totals` blob,
  `treasurer` blob NOT NULL,
  `confirmed_by` blob NOT NULL,
  `description` blob,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- Dumping data for table `thanks_giving`
LOCK TABLES `thanks_giving` WRITE;
/*!40000 ALTER TABLE `thanks_giving` DISABLE KEYS */;
INSERT INTO `thanks_giving` VALUES (1,0x972f5f280cd9f50dad8be597db3522df,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x3200d4d097fc22f9d6219ad027d41418,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x41a801d238569c8e7c2e2accad35b06e,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343231363538353038,0xf1ac900de1e157b028ad448eaa45e225),(2,0xaeb1fa0746062024954aeffae711a50d,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x853ac01fe660710183fff0ec014e62cd,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x41a801d238569c8e7c2e2accad35b06e,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343231383431333431,0x2db7b474624c88481ba5663abbd6839f),(3,0xde004444737705e569a1b2912249109b,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x98c27c83ffc30ae870ffc79fd9627158,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343231383435393234,0x4a0a86463a595100759ef1890fe08a8e),(4,0x987d80fb3a03902df0eeaed7e4e03c9a,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x82a1e878c5ac69376cb8b60f78d0d878,0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343232393432333933,0x0597d2ce288901976de87ee99a0d5a4a),(5,0x679ba441c8849c13b76407971adfb6ce,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0xcd784de2b7628906c5a82bc50e039f83,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343232393432343233,0x2becf388454e72ac018789ca785f4536),(6,0x7b0d3fdbdb3bc63de5355b325814ad94,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x7cc378c15ba9257b08753de52bf79570,0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0x1c5fd03425cc26ad6d770d46d19ddfd0,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343232393432383836,0x2091dfc38b5f27134f27eee50df37cf8),(7,0x85a70faaf08eb29f72d33a7c55585c80,'','',0x90065fe9ea51973a4989393c1f3a44af,0xa748668db8c908dd27f0f1675be591cf,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343232393539323134,0x158b47b464b0177ff2a204ecb4bae142),(8,0x2eea5d752f7d897b7f09a2b3c9a175b5,'','',0x90065fe9ea51973a4989393c1f3a44af,0x81d487dd187f0a4c42f41b5a9cbf06f8,0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0x41a801d238569c8e7c2e2accad35b06e,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343233313231363430,0x351e183b2453bf7dfc00f969c7fa4170),(9,0x3a442e7dd341b0ace3aba3e844f05ed2,'','',0x90065fe9ea51973a4989393c1f3a44af,0xd01be0f90632ad9a323133b9a34f030b,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xcfa10a53ac284db808f6bedd952eb03d,0x1c5fd03425cc26ad6d770d46d19ddfd0,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343233323435373231,0xeccc89d1d8e5cfba16f35f4995259887),(10,0x7b0d3fdbdb3bc63de5355b325814ad94,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x60d55e9a8f73eb796319e9f8dae2e024,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xb7d86e45bc1b2ce8d771a79f630d198a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343233323436333539,0xd2a15e91d4f13c23fa364ffb58f0aab7),(11,0xb40aa907d75c6c593d5b2109a59e3258,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x29e86aad8d705a3c6bb6b838dee83fe3,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x6ff6d5eb3f667bc1d9d90f428ab68a9a,0xe615f63a268cc9200790a05f3fd80887),(12,0xb40aa907d75c6c593d5b2109a59e3258,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x211709c02ae2a4d5c3781d1919c4e94d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xf8e1901467968fa67206476ea9e1a49f,NULL),(13,0xd2685b49757d538d90266d86662993ad,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0xe8e8327d40b4d6980444f213647eacb4,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xdfa7c1d99c65bbd19416f239d762ecbb,NULL),(14,0x7a183200db6fbd6c14b7caf14fa97c44,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0xe99e9df13636b51472b494b6f9c4ff6d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x3b220932fb771f678c5b8eee9f18aca6,NULL),(15,0x2d4835490ad5c9d895034bb3a4c4c0a8,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0xda52cf942d93ae4e0b6f33582b91ca5f,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x3903f1541107ba218a3c37148af66148,NULL),(16,0x7ba282a1c471f3228d7770cba0e322a4,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0xd2f329ec0a3dfab40458acbf6e517b52,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xe53cc952dc1f01c0d7629a17d2fb10f9,NULL),(17,0x5761a4285745d9ba7ecc803a7b17f479,'','',0x90065fe9ea51973a4989393c1f3a44af,0xd3ab0eb5857ea9a53f668468f1abcec2,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x90c5e63412d276353d8a69ea2a93393f,NULL),(18,0xce163a5e6e604416437065a5129bb35a,'','',0x90065fe9ea51973a4989393c1f3a44af,0x209a1d42efa12402299ec744d39cd2ae,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x41a801d238569c8e7c2e2accad35b06e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xcb8229a916310aa33b94848bdd4c59fe,NULL),(19,0xdfcdeb303296bf331598ee7951bf9d15,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0xefcbf255754a35c00561e31e8ae6a563,0xcfa10a53ac284db808f6bedd952eb03d,0xcfa10a53ac284db808f6bedd952eb03d,0x5b581303c0ad955865b7ba1f5e0bc10b,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xc886ff1fed9b3823cc404180e64ca259,NULL),(20,0xdb5d67d3800441b99d351566fe1a9a57,'','',0x90065fe9ea51973a4989393c1f3a44af,0xc9bdf3e542ef47aa9dfcd7f3942cf607,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xfb4c86e4945a6958d0ce8528a838c134,NULL),(21,0x5fe62a94cfdca054c5561904cf0f4522,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x3b3d68a9d20bc3d917e91533480f0e53,0xcfa10a53ac284db808f6bedd952eb03d,0x90065fe9ea51973a4989393c1f3a44af,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x8dc3e7718942424e0ce61552e539ae07,NULL),(22,0xde354c555151f25cc244e160b8423eb8,'','',0x00735f6218fd3e7241f3fcd72e6a3b8d,0x22a6632041a214238e5327aaf3e1abc0,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x0b491e817712e850db83ff8569b76ed0,NULL);
/*!40000 ALTER TABLE `thanks_giving` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `tithes`
DROP TABLE IF EXISTS `tithes`;
CREATE TABLE `tithes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` blob,
  `bank` blob NOT NULL,
  `treasurer` blob NOT NULL,
  `confirmed_by` blob NOT NULL,
  `totals` blob,
  `description` blob,
  `created_by` blob,
  `modified_by` blob,
  `created_on` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

-- Dumping data for table `tithes`
LOCK TABLES `tithes` WRITE;
/*!40000 ALTER TABLE `tithes` DISABLE KEYS */;
INSERT INTO `tithes` VALUES (1,0x871dfa35a9709284f2cd1567e772a206,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x4c02c00ea1483174e99db0176dbc903e,0x18e1b7db93fa4a0b895d0fc1ad444d34,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343231333134383731,0xe53594e747d48c8252f126b2129673d9),(2,0x871dfa35a9709284f2cd1567e772a206,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x532f665f8b9e27b3edf0594508bcbb08,0x41a801d238569c8e7c2e2accad35b06e,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343231333135333935,0xaf94c99b0549cafd5a19efaa6d48a5d8),(3,0xd0b5426cd8a78128adf866909e0d49e1,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x45796299426904c3a8e39ac032357d40,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343231333234393832,0xeb5b9284c009084d21f6499daaeee486),(4,0x3a442e7dd341b0ace3aba3e844f05ed2,0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x33c2f1a8e6bf1dee3a573057172c129b,0x41a801d238569c8e7c2e2accad35b06e,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343231383339373130,0x60e98f0d730845693b450cbdb06501dd),(5,0x2eea5d752f7d897b7f09a2b3c9a175b5,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xd7a7dab203de0e7c7b891499bec31e5d,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343231383435363437,0xf48ef48850b7856366c2d96b122865f0),(9,0x85a70faaf08eb29f72d33a7c55585c80,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x83fbd31963ed0b84089a1693fb875ee5,0x41a801d238569c8e7c2e2accad35b06e,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343232383935323035,0x91786fdc4f9d341c8c8b2c2d495fb8fd),(11,0x7b0d3fdbdb3bc63de5355b325814ad94,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xf082a6d0e7258ca8e38c85d360e10933,0x41a801d238569c8e7c2e2accad35b06e,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343232393539303535,0xd320508afa02cc7346ab48b08d6e1ccb),(12,0x679ba441c8849c13b76407971adfb6ce,0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x426522ac9dc19da52d214e320b6d4c17,0xa545acd59a5c75d85e429545b1b87e8a,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343233313139303235,0xdd58a18e22047e4c6324e53336a441db),(13,0x987d80fb3a03902df0eeaed7e4e03c9a,0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x4c02c00ea1483174e99db0176dbc903e,0xdede230a73e2f5318d3d7958d04e5a08,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343233323438313232,0x5615abbda3df3ec3b157612b792f3120),(14,0xde004444737705e569a1b2912249109b,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0x9d09bd426c25e232a0ef9a2365ff4cb5,0x22420f46a9cd7431b19268cecac383442fe1639287a1549959465c67350171ae,0x31,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x31343233323438323433,0x5085973e5199b386df0721e9f9e3e8a3),(15,0xd0b5426cd8a78128adf866909e0d49e1,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xcdd4837c2482cb51ce2a2a974afd58ea,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x09a88288ec2823ec3cfb849ce1f681c7,NULL),(16,0x479b76baa01aa28a6928be4a0325e1a6,0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x916808310ec41533f6584600479bf87c,0x289adc1d1921dfa2eaf2a8b1018f9d73c166b0a0bfa6587e8d05cb2657f51591,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xd1ad52584e05f28444b6ba607262be84,NULL),(17,0x27adbfe44ee2df162340ad646993de42,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xb1c94cc2798e39e70e3e11395f686f28,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x957f9460e4c1e4c13c46c5ec0f6e73aa,NULL),(18,0xb40aa907d75c6c593d5b2109a59e3258,0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0x3a6d666126f2718953e62f1987f4f200,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x302269217f965602e88094bc70771b58,NULL),(19,0xf1e94fa1c2ac0a5093ab9f6d992ca5aa,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xefcbf255754a35c00561e31e8ae6a563,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x4bbb046e6561e19dfdd5d1597245111d,NULL),(20,0x2d4835490ad5c9d895034bb3a4c4c0a8,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x151d9d6a3578457a437c17defdc0d82f,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xe452f4a9fbe56455d70286920ebe5831,NULL),(21,0x2d4835490ad5c9d895034bb3a4c4c0a8,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xb9e2a0e5fb5fe131dd226acb0cc97e5e,0xa12fe1d1c31ca4909a37ca03ef4a9bb3,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xd6532742ea148efed5fbef08a85719d4,NULL),(22,0xf525bb2a5cc81841b258028eefbdbafa,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa9b8a34b4131e6993cde5f1f1bd31813,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x6803788853256e9797c829b13afbd66a,NULL),(23,0x4ed9884565af45ba96ac38727c9afcb4,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x61db175fa3d78e79ee0703970735f5de,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x33dfac3e5f8b25a7b553930f11156235,NULL),(24,0x73303151d0d569f7215fe4e2f018d7d9,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xcfa10a53ac284db808f6bedd952eb03d,0xcfa10a53ac284db808f6bedd952eb03d,0xe34e7632beaad6a3c4c2514d0d3548b9,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x6e84975c94b15bf759103236b1ea6341,NULL),(25,0xc5d261f3448640ddfe31975a65f95932,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x44f70dd57bf6caa9730313d97b1f4f78,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xc03c03d9bb14dcb9d6d4bcd47dde99b3,NULL),(26,0xf8f12444f298c0fe854d9ffb58f6a7ad,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xda57de7ae0c9adfb0ea4ab18b6d7aeaa,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x4e5220fd793e672487cdb56cb64e04a1,NULL),(27,0x6a76135c3ac566ec045bf921274edc1e,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xd3ab0eb5857ea9a53f668468f1abcec2,0x0b9784fb99ba43c034d239f1b38c7e5c,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xfac25018e25c236012a52cc2cd14014a,NULL),(28,0xd75102b851a8c634b734ad6bfc499cbe,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x41a801d238569c8e7c2e2accad35b06e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x0f9e9c5f537a70a071ec65fcd484b920,NULL),(29,0x030e2b2a5df1c1f5d5adcc5d5c1d9037,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x41a801d238569c8e7c2e2accad35b06e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x14a39154e6b3dbef1212458b60eceece,NULL),(30,0x030e2b2a5df1c1f5d5adcc5d5c1d9037,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xf082a6d0e7258ca8e38c85d360e10933,0x41a801d238569c8e7c2e2accad35b06e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x2b5c6d0bf5c17dae559c8ab4d074b5f4,NULL),(31,0xb71a8b39512ab528a3874bc129050f68,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xcfa10a53ac284db808f6bedd952eb03d,0x90065fe9ea51973a4989393c1f3a44af,0x406dc83653b6a220eb41e20a903b4372,0x41a801d238569c8e7c2e2accad35b06e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x297733f7dc07dee66a674644bce58af6,NULL),(32,0x030e2b2a5df1c1f5d5adcc5d5c1d9037,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xd01be0f90632ad9a323133b9a34f030b,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x8de8021ae7668863ccf03ee0e6df5d7b,NULL),(33,0xdfcdeb303296bf331598ee7951bf9d15,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x33f5a6b4b0c6f94bcb80d857fed16f0a,0xf0fbd9a9c8a3f3b4cf9460dfe97a4725,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x9d59a59be34cf88649a17ec92947411e,0x3b8a6a058df1bf87491768d6e663af98),(34,0xdfcdeb303296bf331598ee7951bf9d15,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xcfa10a53ac284db808f6bedd952eb03d,0xd3ab0eb5857ea9a53f668468f1abcec2,0x5b581303c0ad955865b7ba1f5e0bc10b,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x73d4b7cf510d2c7adbcb30957806ca6b,NULL),(35,0x0121e54266f83559f8f266ad4f66c61b,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xc4d28a9b93a570db340d3cfc07ecad0d,0x5b581303c0ad955865b7ba1f5e0bc10b,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x43f64fd2aad3d2a9d6e5009bcfcdb518,NULL),(36,0xdfcdeb303296bf331598ee7951bf9d15,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xcfa10a53ac284db808f6bedd952eb03d,0xf082a6d0e7258ca8e38c85d360e10933,0x8ba081d8ba317dfff1414882649f20ca,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x3c812eecdf1701b65ed998de8286b223,NULL),(37,0xcbad67f101fe61e269bde99a7b6b06aa,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xf082a6d0e7258ca8e38c85d360e10933,0xa12fe1d1c31ca4909a37ca03ef4a9bb3,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0xce1626f7d2d2c6dfb2de88edb9bfba38,NULL),(38,0x6af1c03ce7159e17303aae3d9fbbb217,0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa748668db8c908dd27f0f1675be591cf,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x21c741e8ae47e2c493fedf11fe241297,NULL),(39,0xdb5d67d3800441b99d351566fe1a9a57,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x6bb340de71b9bccfe7ff805d32b09742,0x41a801d238569c8e7c2e2accad35b06e,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x92e84682e6161268e661dc0156d62270,NULL),(40,0x5fe62a94cfdca054c5561904cf0f4522,0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x09c156679beafe6fd1d853b52392de64,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x5830e627e12119487e7644e6b25d6885,NULL),(41,0x0910ccf2bcff6562f681b763730ad4a2,0x90065fe9ea51973a4989393c1f3a44af,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x135f7885053c846f85d94a93e219e850,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x569810b52bfd7d9fcc9a9f4828be7e8a,NULL),(42,0xde354c555151f25cc244e160b8423eb8,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xcfa10a53ac284db808f6bedd952eb03d,0x817f2bb2ca8877e6e1ca5f0b3beed8de,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x7516dd0f0c2618eb40299e9ff23933eb,NULL),(43,0x0cf684be5c7a80b643d02079e771a8cb,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x0b37e8dd2edb713d2e1c7a10d34d0ee3,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x3f2a6b927c6274f31f3f415e2a3d362a,0x7244e783c2f5c23b5682bf3c99fe1b1d),(44,0x0cf684be5c7a80b643d02079e771a8cb,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0xa515e9961f7a7cc887bc4f8330515009,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xee742375184e6add645f31da61d065bb,0x70a3289f954427f17c87037281d020f5),(45,0x0cf684be5c7a80b643d02079e771a8cb,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,NULL,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x664ccfedfa8e4ea05cad8969eab041e8,NULL),(46,0x0cf684be5c7a80b643d02079e771a8cb,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0xcfa10a53ac284db808f6bedd952eb03d,0x8a99034dec0b03c6c8449155449b0811,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x0a7271fdc7e2c35f50da7479c81d8a71,NULL),(47,0x7424b96f4b6b090ce5aaa44805a172b0,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0x82a1e878c5ac69376cb8b60f78d0d878,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x3328cde749e73237e9e0eeae08c0ed9e,0xdaff3a79b619f13ac6b9cff9579c2c0c),(48,0x0ca2df5aba8bde92ff1f7a63d8e6b517,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x90065fe9ea51973a4989393c1f3a44af,0x00735f6218fd3e7241f3fcd72e6a3b8d,0xf082a6d0e7258ca8e38c85d360e10933,0xa545acd59a5c75d85e429545b1b87e8a,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x99740c11d1346e6484630f17fdb47940,NULL);
/*!40000 ALTER TABLE `tithes` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `users`
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` blob NOT NULL,
  `ip_address` blob NOT NULL,
  `username` blob NOT NULL,
  `password` blob NOT NULL,
  `salt` blob,
  `email` blob NOT NULL,
  `activation_code` blob,
  `first_name` blob,
  `last_name` blob,
  `phone` blob,
  `forgotten_password_code` blob,
  `remember_code` blob,
  `created_on` blob NOT NULL,
  `last_login` blob,
  `active` blob,
  `bio` blob,
  `created_by` blob,
  `modified_by` blob,
  `modified_on` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table `users`
LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x8dae8c71f911eac0f2518c609acbb13d,0xb0c6204d92e820bdd9b382d8f6192146,0x059b467b01ba3fd865e8feb1b2ca42072ad4141ee4f3dce0c84dac22afdc111008fa455c9d750adcf2fffdc05312ee1e,0x71bf490a36d1388798efa45f3873a254,0x0eb8f055b6c50c5edf71649a9f86bab2,0xa545acd59a5c75d85e429545b1b87e8a,0xf50a452dbb53f438439b1b253706ce71,0x9f58d531d84034ba1bb50f1b0aa21762,0x9833ba881c4ec01e0d747c21f7c0aeb5,0xa545acd59a5c75d85e429545b1b87e8a,0xa545acd59a5c75d85e429545b1b87e8a,0x88f2ac67959d408673ab63a7f8c52f58,0x31343735303438383436,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x632373b1cbe3a80f4e1619f3947b75c3),(2,0x90065fe9ea51973a4989393c1f3a44af,0xc1bd6816ef79c1356cc4b0bbfc854dbb,0x8629a24cd97c1d65a5a83a231cb02e39,0x8b70659aa8ceed8c2ccbe5989e224328aa9e81e19f84de5ee9a8568114236ae809e1f026f77e366f588efb76ef24ac68,NULL,0x3b4a47c5142a37811e62169a0c859e82,NULL,0xcb636b55031f4c3018f7ca4575b02a68,0xd9f2b1da7a7a12e073d0f17a0f6e3544,0xd623a851185391639992510f2d3a00b3,NULL,NULL,0x83001a6f31c4d7f2d2d37b23d9d8e1c8,0x31343331343338383130,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x840a763dbf80755b8e274cf14afd990f),(3,0x90065fe9ea51973a4989393c1f3a44af,0xc1bd6816ef79c1356cc4b0bbfc854dbb,0xddcab4581f1eb4a2f02b536fe64d7f79,0x452f6f4f3bd6b8fd5370d2caca2201edec12f1035bc44cadb996b0dc851aa146bba25c205bbc06ddfe954ef5959c1fbf,NULL,0xab20d12201cf113367c690a73bbca206,NULL,0xf3abfa7a76633a5696999bccb966e2ad,0xd9f2b1da7a7a12e073d0f17a0f6e3544,0x0b71b5c0abbc69717e2cca0d71d38d98,NULL,NULL,0x7f4024d92f831b5ccaac4ddcfb8f80c5,0x31343139393336353533,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x3609c9ec305d6885f239a8fd352b0449),(4,0x90065fe9ea51973a4989393c1f3a44af,0x8dae8c71f911eac0f2518c609acbb13d,0xf01ff376ba4fbbe5b2fbafc61d432f74,0x02c5d4b49db5bc5d5d9966c8b1f62b05d468d34fb23e79e1212e2ffe3c416e8ed1319fe6fc7111cc51e844472c6b4690,NULL,0x155fbd3edae4dda9c375cfc2e3576dce,NULL,0x5a67f3de2994745c6cb4c3360f6a1ef0,0xb9bf66345da59b8a0cf2216b3e9994aa,0xe5cc65b19014c41f8496fe5904d8b9e8,NULL,NULL,0xbc522691e6c9fbe9c83126e88d8821dc,0xbc522691e6c9fbe9c83126e88d8821dc,0x00735f6218fd3e7241f3fcd72e6a3b8d,NULL,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x8da3c85600c8c494d025d768beb4b76f);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `users_groups`
DROP TABLE IF EXISTS `users_groups`;
CREATE TABLE `users_groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` blob NOT NULL,
  `group_id` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

-- Dumping data for table `users_groups`
LOCK TABLES `users_groups` WRITE;
/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
INSERT INTO `users_groups` VALUES (10,0x00735f6218fd3e7241f3fcd72e6a3b8d,0x00735f6218fd3e7241f3fcd72e6a3b8d),(13,0xcfa10a53ac284db808f6bedd952eb03d,0xcfa10a53ac284db808f6bedd952eb03d),(14,0xcfa10a53ac284db808f6bedd952eb03d,0x90065fe9ea51973a4989393c1f3a44af),(16,0xcdf3a1cb3f3ee08d0e0c63e679397c3a,0x90065fe9ea51973a4989393c1f3a44af),(17,0x90065fe9ea51973a4989393c1f3a44af,0xcdf3a1cb3f3ee08d0e0c63e679397c3a);
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `video_sermons`
DROP TABLE IF EXISTS `video_sermons`;
CREATE TABLE `video_sermons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL DEFAULT '',
  `value` varchar(256) NOT NULL DEFAULT '',
  `file` varchar(256) NOT NULL DEFAULT '',
  `description` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table `video_sermons`
LOCK TABLES `video_sermons` WRITE;
/*!40000 ALTER TABLE `video_sermons` DISABLE KEYS */;
INSERT INTO `video_sermons` VALUES (1,'When Tough Get Going','Ea8pa0MAItg','','Jesus reminds you again, please arrive at the Bethlehem before 9:30am for the meeting which will last for approximately two hours.We look forward to hearing more about your faith',1,NULL,1431787646,NULL);
/*!40000 ALTER TABLE `video_sermons` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `visitors`
DROP TABLE IF EXISTS `visitors`;
CREATE TABLE `visitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `visit_date` int(11) DEFAULT NULL,
  `first_name` varchar(256) NOT NULL DEFAULT '',
  `last_name` varchar(256) NOT NULL DEFAULT '',
  `gender` varchar(256) NOT NULL DEFAULT '',
  `phone` varchar(256) NOT NULL DEFAULT '',
  `email` varchar(256) NOT NULL DEFAULT '',
  `county` varchar(256) NOT NULL DEFAULT '',
  `location` varchar(256) NOT NULL DEFAULT '',
  `directed_by` varchar(256) NOT NULL DEFAULT '',
  `interested_in_membership` int(1) NOT NULL,
  `saved` int(1) NOT NULL,
  `baptised` int(1) NOT NULL,
  `know_more` int(1) NOT NULL,
  `ministries_interest` int(1) NOT NULL,
  `come_back` int(1) NOT NULL,
  `additionals` text,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Dumping data for table `visitors`
LOCK TABLES `visitors` WRITE;
/*!40000 ALTER TABLE `visitors` DISABLE KEYS */;
INSERT INTO `visitors` VALUES (1,1420059600,'Joshua','kusa','Male','(125) 488-8558','oga@admin.com','Embu','Kawangware','Website',1,1,1,1,1,1,'This a form we filled',1,1,1420961869,1422095135),(2,1421182800,'Maurice','Lusaka','Male','(012) 558-8888','morio@gmail.com','Busia','Nyali','Invited',0,0,0,0,0,0,'This is done',1,1,1420962807,1422095779),(3,1424120400,'Lidia','Jagro','Female','(072) 134-1214','linda@admin.com','Garissa','Bahati','friend',1,1,1,1,1,1,'He is a good person',1,NULL,1422892784,NULL),(4,1424120400,'Lidia','Jagro','Female','(072) 134-1214','linda@admin.com','Garissa','Bahati','friend',1,1,1,1,1,1,'He is a good person',1,NULL,1422893449,NULL),(5,1475010000,'Joe','Omwenga','Male','(072) 080-6453','sema@admin.com','Busia','Riruta','friend',1,0,0,0,0,0,'',1,NULL,1475049868,NULL);
/*!40000 ALTER TABLE `visitors` ENABLE KEYS */;
UNLOCK TABLES;

-- Table structure for table `weddings`
DROP TABLE IF EXISTS `weddings`;
CREATE TABLE `weddings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wedding_date` int(11) DEFAULT NULL,
  `bride` varchar(32) NOT NULL DEFAULT '',
  `bridegroom` varchar(32) NOT NULL DEFAULT '',
  `venue` varchar(256) NOT NULL DEFAULT '',
  `status` varchar(32) NOT NULL DEFAULT '',
  `file` varchar(32) NOT NULL DEFAULT '',
  `brief_description` text,
  `wedding_photo` varchar(256) NOT NULL DEFAULT '',
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `modified_on` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table `weddings`
LOCK TABLES `weddings` WRITE;
/*!40000 ALTER TABLE `weddings` DISABLE KEYS */;
INSERT INTO `weddings` VALUES (1,1442869200,'6','19','Karamojong spashly','0','','They wedded','',1,NULL,1442845202,NULL);
/*!40000 ALTER TABLE `weddings` ENABLE KEYS */;
UNLOCK TABLES;

-- Dump completed on: Wed, 28 Sep 2016 11:23:47 +0300
